#!/bin/sh -
# #############################################################################
#
# NAME
#
#   RUNINSTALLER
#
# DESCRIPTION
#
#   This script belongs to 'SAP RUNINSTALLER'.
#
#   'SAP RUNINSTALLER' consists of 2 scripts: 
#     1. script 'RUNINSTALLER'
#     2. script '<release>install.sh'
#   'SAP RUNINSTALLER' is a wrapper for the Oracle Database Setup Wizard script 'runInstaller'. 
#
#   You can use 'SAP RUNINSTALLER' to install a new Oracle database home
#   in an SAP system according to SAP naming and configuration standards.
#
#   For more information, please see the corresponding SAP Note.
#
# REFERENCES
#
#   SAP Note 2660017
#
# PREREQUISITES
#
#   1) Run this script as Oracle software owner.
#
# USAGE
#
#   To install a new Oracle home, run as
#      $ ./RUNINSTALLER [-ohinstall]
#
#   To verify installation settings, run as
#      $ ./RUNINSTALLER -ohverify
#
#   To extract the Oracle home image file, run as
#      $ ./RUNINSTALLER -ohextract
#
#   To check installation prerequisites, run as
#      $ ./RUNINSTALLER -ohcheck
#
#   To register the new Oracle home, run as
#      $ ./RUNINSTALLER -ohregister
#
#   To configure the new Oracle home for SAP, run as
#      $ ./RUNINSTALLER -ohsapcfg
#
#   For more information, run as 
#      $ ./RUNINSTALLER -help
#
# CHANGE HISTORY
# 
#  -----------+-------------+--------------------------------------------------
#  Date       | Patch Level | Changes
#  -----------+-------------+--------------------------------------------------
#  2019-05-07 | 19-001      | Initial version for release 19.0.0.0.0
# #############################################################################
sap_installer_name="19cinstall.sh"
# #############################################################################
script_name=`basename $0`
script_rel_path=`dirname  $0`
script_abs_path=`(cd ${script_rel_path}; pwd)`
stage_abs_path_1=`(cd ${script_abs_path}    ; pwd)`
stage_abs_path_2=`(cd ${script_abs_path}/.. ; pwd)`
/bin/sh ${script_abs_path}/${sap_installer_name} \
-caller "${script_name}" \
-oracle_stage_1 ${stage_abs_path_1} \
-oracle_stage_2 ${stage_abs_path_2} \
"$@"
