#!/bin/sh -
# #############################################################################
#
# NAME
#
#   19cinstall.sh
#
# DESCRIPTION
#
#   This script belongs to 'SAP RUNINSTALLER'.
#
#   'SAP RUNINSTALLER' consists of 2 scripts: 'RUNINSTALLER' and '19cinstall.sh'. 
#   'SAP RUNINSTALLER' is a wrapper for the Oracle Database Setup Wizard script 'runInstaller'. 
#
#   You can use 'SAP RUNINSTALLER' to install a new Oracle database home
#   in an SAP system according to SAP naming and configuration standards.
#
#   For more information, please see the corresponding SAP Note.
#
# REFERENCES
#
#   SAP Note 2660017
#
# PREREQUISITES
#
#   1) Run this script as Oracle software owner.
#   2) This script supports Oracle Database 19c.
#   3) Environment variable DB_SID      must be set (exception: '-no_db_sid' or '-db_sid').
#   4) Environment variable ORACLE_BASE must be set (exception: '-oracle_base <path>' option)
#   5) Environment variable DISPLAY     must be set (exception: '-silent' option)
#
# USAGE
#
#   For help, call as
#   
#       /bin/sh 19cinstall.sh -help [all]
#
#   For more information, refer to script 'RUNINSTALLER', section 'USAGE'.
#
# CHANGE HISTORY
# 
#  -----------+-------------+--------------------------------------------------
#  Date       | Patch Level | Changes
#  -----------+-------------+--------------------------------------------------
#  2024-07-02 | 19-031      | Retrieving OS version info unix_version (for Linux only)
#  2024-06-21 | 19-030      | Added environment variable CV_ASSUME_DISTID (SAP Note 3296921)
#  2022-09-02 | 19-029      | Root Script Automation improvements for silent mode
#  2022-09-01 | 19-028      | Root Script Automation for silent mode (549766/2022) (-rsa, -rsauser, -rsapass removed, -rsasudopass, -rsarootpass added)
#  2022-07-29 | 19-027      | Added missing option '-rsasudopath <path>' (549766/2022)
#  2020-12-15 | 19-026      | Added new option '-no_empty_dir_check' (lost+found) / flag_empty_dir_check
#  2020-12-14 | 19-025      | Correction: Copying SAP RUNINSTALLER failure changed from ERROR TO WARNING
#  2020-07-21 | 19-024      | Removed '-invPtrLoc': option is not supported by 19c 'runInstaller' (incident 337874 / 2020)
#  2020-04-03 | 19-023      | Added support for '-opatchLocation' and '-skipOpatchVersionCheck'
#  2020-03-31 | 19-022      | Correction for change '-applyRU' / '-applyOneOffs'
#  2020-03-12 | 19-021      | Correction: mkdir -p install_base_dir >/dev/null
#  2020-03-11 | 19-020      | Added support for '-applyRU <path>'
#  2020-03-11 | 19-020      | Added support for '-applyOneOffs <path>'
#  2020-03-11 | 19-019      | Correction '-link_name <name>' default '190' corrected to '19'
#  2020-02-11 | 19-018      | Adding cleanup of root.sh log files OH/install/root_<host>_<date>.log
#  2020-02-10 | 19-017      | Updating '-oracle_stage <path>' for minimal downtime patching
#  2020-02-10 | 19-017      | Adding   '-oracle_image <path>' for minimal downtime patching
#  2019-11-22 | 19-016      | Adding time before/after call to Oracle installer
#  2019-11-20 | 19-015      | Oracle home gold image checksum for Oracle Solaris x86-64
#  2019-08-30 | 19-014      | Internal: inst_session_cleanup() adapted
#  2019-08-30 | 19-014      | Internal: echo_cmd() added to task -ohcheck
#  2019-08-30 | 19-014      | Internal: echo_cmd() args quoted in task -ohregister
#  2019-08-29 | 19-013      | Removing '-skip_rootpre' option
#  2019-08-29 | 19-013      | Updating check for SKIP_ROOTPRE environment var. (SAP Note 2660017)
#  2019-08-29 | 19-013      | Internal: replaced occurrences of function 'echo_std' by 'MSGFREES'
#  2019-08-27 | 19-012      | Adding '-skip_rootpre' option 
#  2019-08-29 | 19-013      | Adding check for SKIP_ROOTPRE environment var. (SAP Note 2660017)
#  2019-05-29 | 19-011      | Adding MSGTASKINFO, platformspecific ORA_GOLD_IMAGE_FILE_CNT
#  2019-05-27 | 19-010      | Adding mark when starting/ending Oracle Database Setup Wizard (STR_OUI_NAME_0)
#  2019-05-24 | 19-009      | Adding mark when starting/ending Oracle Database Setup Wizard
#  2019-05-22 | 19-008      | Default sudo user is Oracle software owner
#  2019-05-22 | 19-007      | Support for Root Script Automation (-rsa, SUDO)
#  2019-05-21 | 19-006      | Support for Root Script Automation (-rsa, oui_rsa_rootun, oui_rsa_sudoun)
#  2019-05-17 | 19-005      | Support for Root Script Automation (-rsa, oui_rsa_option, oui_rsa_method)
#  2019-05-14 | 19-004      | OUI Version 12.2.0.7.0 adapted
#             |             | added oracle.install.db.rootconfig.executeRootScript
#  2019-05-13 | 19-003      | added start date/time for each task
#             |             | improved search algorithm for Oracle home image file
#  2019-05-13 | 19-002      | Oracle home gold image file name
#             |             | Oracle home gold image checksum
#             |             | start date/time for each task
#  2019-05-06 | 19-001      | Initial version for release 19.0.0.0.0 (19c)
#  -----------+-------------+--------------------------------------------------
# 
# CHANGE HISTORY - all versions
#
#  -----------+-------------+--------------------------------------------------
#  2019-11-20 | 19-016      | Current version for release 19.X.0.0.0 (19c)
#  2019-02-08 | 18-021      | Current version for release 18.3.0.0.0 (18c)
#  2017-10-19 | 102         | Current version for release 12.2.0.1.0 (12.2)
#  2015-03-02 | 058         | Current version for release 12.1.0.2   (12.1)
#  2013-09-23 | 043         | Current version for release 11.2.0.4   (11.2)
#  2011-12-02 | 039         | Current version for release 11.2.0.3   (11.2)
#  2011-10-18 | 029         | Current version for release 11.2.0.2.0 (11.2)
#  2010-10-28 |             | Initial version for release 11.2.0.2.0 (11.2)
#  -----------+-------------+--------------------------------------------------
# #############################################################################

# -----------------------------------------------------------------------------
# Boot functions
# -----------------------------------------------------------------------------

# handles an error 
#
#   - Writes the specified error message to STDOUT
#
# Parameters:
#   message
echo_err()
{
    echo "$1" 1>&2
    exit 1
}

echo_err_no_exit()
{
    echo "$1" 1>&2
}

###############################################################################
#                                                                             #
#                                                                             #
#                                                                             #
#                         DEFINITION OF VARIABLES                             #
#                                                                             #
#                                                                             #
#                                                                             #
###############################################################################

# -----------------------------------------------------------------------------
# Directory name and Program name
# -----------------------------------------------------------------------------
PROGNAME="$0"
PROGDIR=`dirname $PROGNAME`
PROGNAME=`basename $PROGNAME`
ORIGDIR=`pwd`
PROGDIR=`cd $PROGDIR && pwd || echo $PROGDIR`

# -----------------------------------------------------------------------------
# Oracle Release / Oracle Version
# -----------------------------------------------------------------------------
# https://docs.oracle.com/en/database/oracle/oracle-database/18/upgrd/oracle-database-release-numbers.html

# Oracle Database Release
ORA_DB_VERS1=19 # release
ORA_DB_VERS2=0  # RU - release update
ORA_DB_VERS3=0  # RUR - release update revision
ORA_DB_VERS4=0  # not used / reserved for future use
ORA_DB_VERS5=0  # not used / reserved for future use

# Oracle Database Release year
ORACLE_RELEASE_YEAR="2019"
# Oracle Database Release name: 19c
ORACLE_RELEASE_NAME="19c"
# Oracle Database Version, format YY.RU.RUR
ORACLE_RELEASE_KURZ="19.0.0"
# Oracle Database Version, format YY.RU.RUR.XX.YY
ORACLE_RELEASE_LONG="19.0.0.0.0"

# -----------------------------------------------------------------------------
# Exit Codes / Return Codes
# -----------------------------------------------------------------------------

###############################################################################
# Return Codes for SAP RUNINSTALLER
# 0: Finished successfully
# 1: Finished successfully with warnings
# 2: Finished with errors
# 5: Finished with errors - prerequisites not met
# 6: Finished with errors - invalid argument
###############################################################################

# Technical Exit codes
RC_SUCC=0                # 0: Installation finished successfully 
RC_WARN=1                # 1: Installation finished with warnings
RC_ERRR=2                # 2: Installation finished with errors  
RC_PREREQ_ERROR=5        # 5: Error - prerequisites not met
RC_INVARG_ERROR=6        # 6: Error - invalid command line argument
RC_INITIAL=127           # not used

# Return Code String
RC_STR_VAL=""

# Reason why post installation tasks are not executed
post_install_skip_reason=""

# -----------------------------------------------------------------------------
# Exit Code Variables
# -----------------------------------------------------------------------------
# Exit Code variable
#RC_RETCODE=$RC_INITIAL

# -----------------------------------------------------------------------------
# Return Code Variable
# -----------------------------------------------------------------------------
rc_cmd=0      # return code of last command
rc_os_cmd=0   # return code of last OS command
rc_oui_cmd=0  # return code of last OUI command
rc_oui_real=0 # real return code of last OUI command
rc_last=0     # last return code

# -----------------------------------------------------------------------------
# Last OS Command Variable
# -----------------------------------------------------------------------------
last_cmd="" # last command string
next_cmd="" # next command string

# -----------------------------------------------------------------------------
# Last Command Output
# -----------------------------------------------------------------------------
last_cmd_out="" # last command output

# -----------------------------------------------------------------------------
# Script information
# -----------------------------------------------------------------------------

# script command line, number of arguments
script_cmdl="$*"                     # command line
script_argn=$#                       # number of arguments
cmdl_arg=""                          # command line option: current argument
cur_arg=""                           # command line option: current argument
script_caller=""                     # Name of calling script (e.g. RUNINSTALLER)

# Prefix, script name, script banner, script copyright
#script_name=`basename $0`
script_pfix="19cinstall"
script_name="${script_pfix}.sh"
script_line="************************************************************"
script_bnnr="Oracle Database ${ORACLE_RELEASE_NAME} Software Installation"
script_copy="Copyright (c) Oracle Corporation ${ORACLE_RELEASE_YEAR}. All Rights Reserved."


# script status, script version, script patchlevel, script release date, script SAP Note
script_stat="production"        # dev, test, validation, production, incident
script_vers="${ORACLE_RELEASE_KURZ}" # version (Oracle Database Version)
script_plvl="19-031"                 # patch level (Script Version and Patch Level)
script_date="2024-07-02"             # release date
script_note="2660017"                # SAPNOTE, SAP Note

# -----------------------------------------------------------------------------
# String Constants
# -----------------------------------------------------------------------------
STR_ENABLED="enabled"
STR_DISABLED="disabled"
STR_YES="yes"
STR_NO="no"
STR_TRUE="TRUE"
STR_FALSE="FALSE"
STR_NOT_SPECIFIED="not specified"
STR_NOT_SET="not set"
STR_DASH="-"

# Names for runInstaller
STR_OUI_NAME_1="Oracle Database ${ORACLE_RELEASE_NAME} Installer"
STR_OUI_NAME_2="Oracle Database ${ORACLE_RELEASE_NAME} Setup Wizard"
STR_OUI_NAME_3="Oracle Database Installer"
STR_OUI_NAME_4="Oracle Database Setup Wizard"
STR_OUI_NAME_5="runInstaller"
STR_OUI_NAME_0="$STR_OUI_NAME_1"
STR_SRI_NAME="SAP RUNINSTALLER"

# -----------------------------------------------------------------------------
# Message String Constants
# -----------------------------------------------------------------------------

STR_SUCC="SUCCESS"           # install_exit()
STR_WARN="WARNING(S)"        # install_exit()
STR_ERRR="ERROR(S)"          # install_exit()
STR_NDEF="UNDEFINED"         # install_exit()

# info warning error
MSG_INFO="(INFO   ) - "      # generic use
MSG_WARN="(WARN   ) - "      # generic use
MSG_ERRR="(ERROR  ) - "      # generic use

MSG_OKOK="(OK     ) - "      # indicates that sth is good / ok
MSG_IERR="(INT.ERR) - "      # internal error
MSG_SUCC="(SUCCESS) - "      # not used
MSG_FAIL="(FAILURE) - "      # not used
MSG_CONT="          - "      #

MSG_EXIT="(EXIT   ) - "      # install_exit()
MSG_VRBM="(VERBOSE) - "      # echo_vrb()
MSG_TRCM="(TRACE  ) - "      # echo_trc()

MSG_STR_INFOS="(INFO   ) - " # info warning error for messages in standard mode
MSG_STR_WARNS="(WARN   ) - " # info warning error for messages in standard mode
MSG_STR_ERRRS="(ERROR  ) - " # info warning error for messages in standard mode
MSG_STR_INFOV="(INFO-V ) - " # info warning error for messages in verbose  mode
MSG_STR_WARNV="(WARN-V ) - " # info warning error for messages in verbose  mode
MSG_STR_ERRRV="(ERROR-V) - " # info warning error for messages in verbose  mode
MSG_STR_INFOT="(INFO-T ) - " # info warning error for messages in trace    mode
MSG_STR_WARNT="(WARN-T ) - " # info warning error for messages in trace    mode
MSG_STR_ERRRT="(ERROR-T) - " # info warning error for messages in trace    mode

# -----------------------------------------------------------------------------
# Unix Command String Constants
# -----------------------------------------------------------------------------
OS_RM="rm"
OS_RMLINK="rm"
OS_RMDIR="rmdir"
OS_CREATELINK="ln -s"
OS_AWK="/bin/awk"
OS_GREP="grep"
OS_SED="sed"
OS_XCLOCK="xclock"
OS_DISKFREE="df"

# -----------------------------------------------------------------------------
# Unix Command unzip
# -----------------------------------------------------------------------------
OS_UNZIP_CMD="unzip" # "/usr/bin/unzip"
OS_UNZIP_OPT=""      # quiet mode (-xquiet): "-q", non-quiet mode: ""

# determine unzip path
OS_UNZIP_PATH=""
if `which unzip 1>/dev/null 2>&1`; then
  OS_UNZIP_PATH=`which unzip`
else
  echo_err_no_exit "Unzip tool not in path."
fi
#echo "OS_UNZIP_PATH=$OS_UNZIP_PATH"

# determine unzip banner
OS_UNZIP_BANNER=""
if `unzip 1>/dev/null 2>&1`; then
  OS_UNZIP_BANNER=`unzip | head -1`
else
  echo_err_no_exit "Unzip tool banner not determined."
fi
#echo "OS_UNZIP_BANNER=$OS_UNZIP_BANNER"

# determine unzip version
# tbd - see below

# -----------------------------------------------------------------------------
# Unix hostname
# -----------------------------------------------------------------------------

# determine hostname
run_host=""
run_host=`hostname | sed "s/\..*$//"`
#run_host=`uname -n | sed 's/\..*$//'`

# -----------------------------------------------------------------------------
# Unix platform
# -----------------------------------------------------------------------------

# determine platform
platform=""
if uname=`uname -s -m`; then
  :
else
  echo_err "Cannot execute \"uname\" to determine platform."
fi
case $uname in
  AIX\ *)             platform="aix" ;;
  HP-UX\ 9000/785)    platform="hp_ux_9000_800" ;;
  SunOS\ sun4[cdmsv]) platform="sunos_sun4u" ;;
  SunOS\ sun4us)      platform="sunos_sun4u" ;;
  *)
    platform=`printf '%s\n' "$uname" |
              tr ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmnopqrstuvwxyz |
              sed 's/[^a-z0-9]/_/g'` ;;
esac

# -----------------------------------------------------------------------------
# Unix Version / OS Version
# -----------------------------------------------------------------------------
unix_version=""
# determine unix version (OS version)
# aix         : oslevel or oslevel -s 
#   Example: oslevel: 7.2.0.0 oslevel -s: 7200-01-05-1845
# hp_ux_ia64  : uname -a or swlist | grep -i oe
#   Example: HP-UX hostname B.11.31 U ia64 1234567890 unlimited-user license
# linux_x86_64: hostnamectl
#   Example: Red Hat Enterprise Linux 9.2 (Plow)
# sunos_i86pc : uname -a
#   Example: SunOS hostname 5.11 11.4.0.15.0 i86pc i386 i86xpv
# sunos_sun4u : uname -a
# Example: SunOS hostname 5.11 11.4.0.15.0 i86pc i386 i86xpv

case $platform in
  aix            ) unix_version=""  ;;
  hp_ux_ia64     ) unix_version=""  ;;
  linux_x86_64   ) unix_version="`hostnamectl | grep "Operating System:" | sed 's/Operating System: //'`"	;;
  sunos_i86pc    ) unix_version=""  ;;
  sunos_sun4u    ) unix_version=""  ;;
  *              ) unix_version=""  ;;
esac

# -----------------------------------------------------------------------------
# Unix Date and Time
# -----------------------------------------------------------------------------

# Date/Time info
run_date=`date "+%Y-%m-%d"`
run_time=`date "+%H-%M-%S"`
log_time=`date "+%Y-%m-%d_%H-%M-%S"`

# -----------------------------------------------------------------------------
# Unix Date and Time (Other formats)
# -----------------------------------------------------------------------------
# LTIMESTAMP=`date "+%Y-%m-%d_%H-%M-%S"`

# run_date=`date "+%Y_%m_%d"`
# run_time=`date "+%H:%M:%S"`
# LTIMESTAMP=`date "+%Y_%m_%d-%H-%M-%S"`

# run_date=`date -u +"%Y-%m-%d %T"`
#                              %T same as %H:%M:%S
# run_date=`date -u +"%Y-%m-%d"`
# run_tim1=`date -u +"%H-%M-%S"`
# run_tim2=`date -u +"%H:%M:%S"`

# -----------------------------------------------------------------------------
# Unix User and group
# -----------------------------------------------------------------------------

# Current user and group
run_usergroup="unknown"
run_username="unknown"
#run_username=`whoami`
#run_usergroup=`id -g -n`
if   [ -n "$USER"    ]; then
  run_username="$USER"
elif [ -n "$LOGNAME" ]; then
  run_username="$LOGNAME"
else
  run_username="unknown"
  #run_username=`whoami`
fi

# User and group
# oracle:oinstall or ora<dbsid>:dba
user_group=""

# -----------------------------------------------------------------------------
# Unix User and group of Oracle home / Oracle Base (File Permissions)
# -----------------------------------------------------------------------------
oh_usr=""
oh_grp=""
ob_usr=""
ob_grp=""

# -----------------------------------------------------------------------------
# Default Base directory / Working directory (19c version)
# -----------------------------------------------------------------------------
# trace switch: 0=OFF, 1=ON
INITINFO=0
[ $INITINFO -ne 0 ] && echo "INITINFO: ON"

# Setting db_sid_dir and orainstall_dir
[ -n "${DB_SID}" ] && db_sid_dir="/oracle/${DB_SID}" && orainstall_dir="/oracle/${DB_SID}/orainstall"
[ $INITINFO -ne 0 ] && echo "db_sid_dir    =$db_sid_dir"
[ $INITINFO -ne 0 ] && echo "orainstall_dir=$orainstall_dir"

# Creating orainstall_dir, if missing. Using 'mkdir /tmp/qq >/dev/null 2>&1' (see https://stackoverflow.com/questions/793858/how-to-mkdir-only-if-a-dir-does-not-already-exist)
[ -n "${DB_SID}" ] && [ ! -d "${orainstall_dir}" ] &&  mkdir -p "${orainstall_dir}" >/dev/null 2>&1 && echo "Directory ${orainstall_dir} created"

# install_base_dir candidates check
[ $INITINFO -ne 0 ] && [ -n "${DB_SID}" ] && [ ! -d "${orainstall_dir}" ] && echo "Directory does not exist: ${orainstall_dir}"
[ $INITINFO -ne 0 ] && [ -n "${DB_SID}" ] && [   -d "${orainstall_dir}" ] && echo "Directory does     exist: ${orainstall_dir}"
[ $INITINFO -ne 0 ] && [ -n "${DB_SID}" ] && [ ! -d "${HOME}"           ] && echo "Directory does not exist: ${HOME}"
[ $INITINFO -ne 0 ] && [ -n "${DB_SID}" ] && [   -d "${HOME}"           ] && echo "Directory does     exist: ${HOME}"
[ $INITINFO -ne 0 ] && [ -n "${DB_SID}" ] && [ ! -d "${db_sid_dir}"     ] && echo "Directory does not exist: ${db_sid_dir}"
[ $INITINFO -ne 0 ] && [ -n "${DB_SID}" ] && [   -d "${db_sid_dir}"     ] && echo "Directory does     exist: ${db_sid_dir}"
[ $INITINFO -ne 0 ] && [ -n "${DB_SID}" ] && [ ! -d "${ORIGDIR}"        ] && echo "Directory does not exist: ${ORIGDIR}"
[ $INITINFO -ne 0 ] && [ -n "${DB_SID}" ] && [   -d "${ORIGDIR}"        ] && echo "Directory does     exist: ${ORIGDIR}"

# Setting install_base_dir
[ $INITINFO -ne 0 ] && echo "Setting Install Base Directory ..."
install_base_dir=""
[ -z "${install_base_dir}" ] && [ -n "${DB_SID}" ] && [   -d "${orainstall_dir}" ] &&  install_base_dir="${orainstall_dir}" # Prio #1: /oracle/<DBSID>/orainstall
[ -z "${install_base_dir}" ] && [ -n "${HOME}"   ] && [   -d "${HOME}"           ] &&  install_base_dir="${HOME}"           # Prio #2: /home/<software owner name>
[ -z "${install_base_dir}" ] && [ -n "${DB_SID}" ] && [   -d "${db_sid_dir}"     ] &&  install_base_dir="${db_sid_dir}"     # Prio #3: /oracle/<DBSID>
[ -z "${install_base_dir}" ]                                                       &&  install_base_dir="${ORIGDIR}"        # Prio #4: current directory
[ $INITINFO -ne 0 ] && echo "Install Base Directory set to ${install_base_dir}."

# switch off trace
[ $INITINFO -ne 0 ] && INITINFO=0 && echo "INITINFO: OFF"
INITINFO=0

# -----------------------------------------------------------------------------
# Default Base directory / Working directory (12c version)
# -----------------------------------------------------------------------------
# install_base_dir=""
# [ -z "${install_base_dir}" ] && [ -n "${HOME}"   ] && [   -d "${HOME}"           ] &&  install_base_dir="${HOME}"           # Prio #1: /home/<software owner name> 
# [ -z "${install_base_dir}" ] && [ -n "${DB_SID}" ] && [   -d "/oracle/${DB_SID}" ] &&  install_base_dir="/oracle/${DB_SID}" # Prio #2: /oracle/<DBSID>             
# [ -z "${install_base_dir}" ]                                                       &&  install_base_dir="$ORIGDIR"          # Prio #3: current directory           
# #echo "$0 base directory set to $install_base_dir"

# -----------------------------------------------------------------------------
# Log files, response files, temp. files
# -----------------------------------------------------------------------------
VERS_FLAG="_${ORACLE_RELEASE_KURZ}" # Flag: Oracle Version
HIDE_FLAG="."                       # Flag: flag to hide temporary files
TIME_FLAG="$log_time"               # Flag: date and time

# SAP RUNINSTALLER Log file (single)
sap_log_dir="${install_base_dir}"
sap_log_name_single="${script_pfix}${VERS_FLAG}.log"       # 12c name format
sap_log_name_single="${script_pfix}${TIME_FLAG}.log"       # 19c name format
sap_log_file_single="${sap_log_dir}/${sap_log_name_single}"

# SAP RUNINSTALLER Log file (Summary log, History log)
sap_log_name_summary="${script_pfix}${VERS_FLAG}_hist.log" # 12c name format
sap_log_name_summary="${script_pfix}.log"                  # 19c name format
sap_log_file_summary="${sap_log_dir}/${sap_log_name_summary}"

# OUI output log file (used with tee command)
oui_log_dir="${install_base_dir}"
oui_log_name="${HIDE_FLAG}${script_pfix}${VERS_FLAG}.oui"  # 12c name format
oui_log_name="${HIDE_FLAG}${script_pfix}.oui"              # 19c name format
oui_log_file="${oui_log_dir}/${oui_log_name}"              # name of OUI output log file (empty if tee_cmd is not set)

# OUI install session log file
oui_session_log=""

# OUI install session exit code
oui_session_rc=""

# OUI install session temporary directory
tmp_dir_base="${install_base_dir}"
tmp_dir_name="${HIDE_FLAG}${script_pfix}${VERS_FLAG}.tmp"  # 12c name format
tmp_dir_name="${HIDE_FLAG}${script_pfix}.tmp"              # 19c name format
tmp_dir_full="${tmp_dir_base}/${tmp_dir_name}"             # temporary directory
tmp_dir_errfile="${tmp_dir_full}/sap_runinstaller.err"     # unzip error log file
tmp_dir_opt=""
#echo "Changed temporary directory: tmp_dir_full   : $tmp_dir_full"    # dev output, added with PL 015
#echo "Changed temporary directory: tmp_dir_errfile: $tmp_dir_errfile" # dev output, added with PL 015

# OUI response file
rspf_dir="${install_base_dir}"
rspf_name="${HIDE_FLAG}${script_pfix}${VERS_FLAG}.rsp"     # 12c name format
rspf_name="${HIDE_FLAG}${script_pfix}.rsp"                 # 19c name format
rspf_file="${rspf_dir}/${rspf_name}"

# -----------------------------------------------------------------------------
# Free space in critical directories
# -----------------------------------------------------------------------------
# reference: http://unix.stackexchange.com/questions/6008/get-the-free-space-available-in-current-directory-in-bash
tmp_dir_base_free=""      # free space in tmp_dir_base
tmp_dir_base_free_min="2" # minimum free space required [GByte]
home_dir_free=""          # free space in home directory
tmp_dir_free=""           # free space in /tmp
DF_UNIT="GByte"

# -----------------------------------------------------------------------------
# Script Status Flags
# -----------------------------------------------------------------------------
args_checked="${STR_FALSE}"      # Flag: Status of command line arguments ("FALSE"=not checked, "TRUE"=checked)
env_checked="${STR_FALSE}"       # Flag: Status of environment variables  ("FALSE"=not checked, "TRUE"=checked)

logging_enabled="${STR_TRUE}"    # Flag: Disable logging with '-nolog' (by default logging is enabled)
logging_status="OFF"             # Flag: Current Logging status ("ON" or "OFF")

query_mode="${STR_DISABLED}"     # Flag: query mode   (-query option)
trace_mode="${STR_DISABLED}"     # Flag: trace mode   (-trc option)
nowarn_mode="${STR_DISABLED}"    # Flag: nowarn mode  (-ignoreWarnings option)
verbose_mode="${STR_DISABLED}"   # Flag: verbose mode (-verbose option)

# -----------------------------------------------------------------------------
# Debug mode Flags
# -----------------------------------------------------------------------------
flag_debug_mode_oui="" # Debug mode for Oracle Database Setup Wizard (-debug)
flag_debug_mode_rsp="" # Debug mode for Oracle response file generation
flag_debug_mode_sap="" # Debug mode for SAP RUNINSTALLER script

# -----------------------------------------------------------------------------
# Other Flags
# -----------------------------------------------------------------------------
flag_empty_dir_check="yes" # Flag: switch flag with option '-no_empty_dir_check' (lost+found)

# -----------------------------------------------------------------------------
# Installation Options (19c and above)
# -----------------------------------------------------------------------------
# main switches for main tasks
opt_ohi="${STR_YES}" # -ohinstall   : i=install (DEFAULT)
opt_ohn="${STR_NO}"  # -ohnoinstall : n=noinstall

# sub switches for sub tasks
opt_ohp="${STR_NO}"  # -ohprepare   : p=prepare
opt_ohv="${STR_NO}"  # -ohverify    : v=verify
opt_ohx="${STR_NO}"  # -ohextract   : x=extract
opt_ohc="${STR_NO}"  # -ohcheck     : c=check
opt_ohr="${STR_NO}"  # -ohregister  : r=register
opt_ohs="${STR_NO}"  # -ohsapcfg    : s=sapcfg (configure for SAP)
opt_ohm="${STR_NO}"  # -ohmopatch   : m=patching with mopatch - not supported/implemented yet

# Options planned for future
opt_ohu="${STR_NO}"  # -ohuninstall : u=uninstall with deinstall tool

# exec flags for sub tasks
run_ohp="${STR_NO}"  # -ohprepare   : task was (not) yet run
run_ohv="${STR_NO}"  # -ohverify    : task was (not) yet run
run_ohx="${STR_NO}"  # -ohextract   : task was (not) yet run
run_ohc="${STR_NO}"  # -ohcheck     : task was (not) yet run
run_ohr="${STR_NO}"  # -ohregister  : task was (not) yet run
run_ohs="${STR_NO}"  # -ohsapcfg    : task was (not) yet run
run_ohm="${STR_NO}"  # -ohmopatch   : task was (not) yet run

# Task Exit codes
rct_ini=127
rct_ohi=$rct_ini     # -ohinstall   : return code for this task
rct_ohp=$rct_ini     # -ohprepare   : return code for this task
rct_ohv=$rct_ini     # -ohverify    : return code for this task
rct_ohx=$rct_ini     # -ohextract   : return code for this task
rct_ohc=$rct_ini     # -ohcheck     : return code for this task
rct_ohr=$rct_ini     # -ohregister  : return code for this task
rct_ohs=$rct_ini     # -ohsapcfg    : return code for this task
rct_ohm=$rct_ini     # -ohmopatch   : return code for this task

# Description for main tasks and sub tasks
dsc_cur=""                                                 # description of current task
dsc_dnr="task not selected"                                # dnr = do not run
#dsc_ohi="Install Oracle Home"                              # -ohinstall  : task description
#dsc_ohi="Install Oracle Home (fresh and complete)"         # -ohinstall  : task description
dsc_ohi="Install Oracle Home (Extract+Register+Configure)" # -ohinstall  : task description
dsc_ohn="Verify installation settings, but do not install" # -ohnoinstall: task description
dsc_ohp="Prepare Installation and Installation Checks"     # -ohprepare  : task description
dsc_ohv="Verify Installation Settings"                     # -ohverify   : task description 
dsc_ohx="Extract Oracle Home Image File (unzip)"           # -ohextract  : task description 
dsc_ohc="Check Installation Prerequisites (runInstaller)"  # -ohcheck    : task description 
dsc_ohr="Register Oracle Home (runInstaller)"              # -ohregister : task description 
dsc_ohs="Configure Runtime Oracle Home for SAP"            # -ohsapcfg   : task description 
dsc_ohm="Install SAP Bundle Patch (SBP)"                   # -ohmopatch  : task description

# -----------------------------------------------------------------------------
# Oracle Home Image File Extraction Modes
# -----------------------------------------------------------------------------
opt_extract_mode_verbose="-xprogress" # -xquiet | -xverbose | -xprogress
opt_extract_mode_new=""            # -xnew: cleanup before if not empty (only for internal testing)
opt_extract_mode_overwrite=""      # not supported for SAP
[ $opt_extract_mode_verbose = "-xquiet"    ] && OS_UNZIP_OPT="-q"

# -----------------------------------------------------------------------------
# Installation Status Flags
# -----------------------------------------------------------------------------
flag_ohx="${STR_NO}" # Flag: OH is already extracted  (yes / no)
flag_ohr="${STR_NO}" # Flag: OH is already registered (yes / no) - how determin?
flag_ohs="${STR_NO}" # Flag: OH is already configured (yes / no) - link exists / orabasetab

# special flags
flag_ohroot="${STR_NO}" # Flag: root.sh script was executed (yes / no )

# -----------------------------------------------------------------------------
# SAP RUNINSTALLER script names
# -----------------------------------------------------------------------------
 script_name_wrapper="${PROGDIR}/RUNINSTALLER"
 script_name_install="${PROGDIR}/${PROGNAME}"

# -----------------------------------------------------------------------------
# SAP RUNINSTALLER Location Flags
# -----------------------------------------------------------------------------
flag_dvd=""          # Flag: RUNINSTALLER is started from Oracle Software DVD
flag_eoh=""          # Flag: RUNINSTALLER is started from extracted Oracle home

# -----------------------------------------------------------------------------
# SAP RUNINSTALLER Oracle Stage Locations
# -----------------------------------------------------------------------------
ora_stage_loc_0=""    # user specified      (option -oracle_stage <path>, -oracle_image <path>)
ora_stage_loc_1=""    # default location #1 (option -oracle_stage_1, RUNINSTALLER directory)
ora_stage_loc_2=""    # default location #2 (option -oracle_stage_2, RUNINSTALLER directory, one level up)
ora_search_path=""    # stage search path
ora_stage_search="${STR_YES}" # Flag indicating whether Oracle home gold image must be searched or not

# -----------------------------------------------------------------------------
# Oracle Image File (user specified via option -oracle_stage <path>, -oracle_image <path>)
# -----------------------------------------------------------------------------
ora_image_file_path=""           # Oracle gold image file path     (full path)
ora_image_file_diry=""           # Oracle gold image file location (directory)
ora_image_file_name=""           # Oracle gold image file name     (name)
ora_image_file_found="${STR_NO}" # Flag: Oracle Image file found   (yes / no)
ora_image_file_cust="${STR_NO}"  # Flag: Oracle or custom image file (yes / no)

# -----------------------------------------------------------------------------
# Patching Options
# -----------------------------------------------------------------------------
# runInstaller option '-applyOneOffs'
# Reference: https://docs.oracle.com/en/database/oracle/oracle-database/19/rnrdm/linux-platform-issues.html
# runInstaller -help: -applyOneOffs - apply one-off patch to the Oracle home. Multiple one-off patches can be passed as a comma separated list of locations.
opt_applyOO_flag="${STR_NO}"     # contains 'YES', if used
opt_applyOO_strg=""              # contains '-applyOneOffs', if used
opt_applyOO_path=""              # contains <path> of OneOffs, if used

# runInstaller option '-applyRU'
# Reference: https://docs.oracle.com/en/database/oracle/oracle-database/19/ladbi/apply-patches-during-db-install.html
# runInstaller -help: -applyRU - apply release update to the Oracle home.
opt_applyRU_flag="${STR_NO}"     # contains 'YES', if used
opt_applyRU_strg=""              # contains '-applyRU', if used
opt_applyRU_path=""              # contains <path of RU>, if used

# '-applySBP': an SBP is installed with 'mopatch';
#opt_applySB_flag="${STR_NO}"    # contains 'YES', if used
#opt_applySB_strg=""             # contains '-applySBP', if used
#opt_applySB_path=""             # contains <path> of SBP, if used

# runInstaller option '-opatchLocation'
opt_opatchloc_flag="${STR_NO}"   # contains 'YES', if used
opt_opatchloc_strg=""            # contains '-opatchLocation', if used
opt_opatchloc_path=""            # contains <path of opatch>, if used
opt_opatch_s_o_v_c_strg=""       # contains '-skipOpatchVersionCheck', if used

# -----------------------------------------------------------------------------
# Post Installation Options
# -----------------------------------------------------------------------------
opt_cleanup_tmp="${STR_YES}"     # Option to clean up temporary files
opt_opatch_chk="${STR_NO}"       # Check installation with 'opatch lsinventory' (-check_inventory/-no_check_inventory/-lsinventory)
opt_orabasetab="${STR_YES}"      # Configure orabasetab (-orabasetab yes/no)
opt_dbsid_mandatory="${STR_YES}" # Flag indicating to run without DB_SID set in environment -> '-no_db_sid' / '-db_sid'

# -----------------------------------------------------------------------------
# Oracle Parameter: Oracle Inventory Location
# -----------------------------------------------------------------------------
# Oracle Inventory Location (Default = /oracle/oraInventory)
# The location can be changed through -invLoc <path> option.
invloc_path="/oracle/oraInventory"

# -----------------------------------------------------------------------------
# Oracle Parameter: Oracle Home Name
# -----------------------------------------------------------------------------
# Oracle Home Name
# SAP Default < 11g: <SID>_<REL>_<BIT>
# SAP Default >=11g: generated by OUI
# OUI flags        : -defaultHomeName / -oracle_home_name "<name>"
# OUI responsefile : There is no parameter ORACLE_HOME_NAME
# OUI command line variable: Ex 1: session:ORACLE_HOME_NAME="OraHome" 
#                            Ex 2: ORACLE_HOME_NAME="OraHome"
ORACLE_HOME_NAME=""
ORACLE_HOME_NAME_VAR=""

# -----------------------------------------------------------------------------
# Oracle Parameter: Oracle Database Name
# -----------------------------------------------------------------------------
# Target Database Name (Default=$DB_SID)
tgt_db_sid=""

# -----------------------------------------------------------------------------
# Oracle Parameter: Oracle Base Location (ORACLE_BASE)
# -----------------------------------------------------------------------------
# Target Oracle base location (Default=$ORACLE_BASE)
tgt_ob_loc=""
tgt_ob_loc_flag=""
ORACLE_BASE_DEF=""     # Default for ORACLE_BASE
ORACLE_BASE_DEF_OES="" # Default for ORACLE_BASE on Oracle Engineered Systems
ORACLE_BASE_DEF_SAP="" # Default for ORACLE_BASE for SAP on Non-Engineered Systems

# -----------------------------------------------------------------------------
# Oracle Parameter: Oracle Home Location
# -----------------------------------------------------------------------------
#      IHRDBMS: tgt_oh_loc, tgt_oh_dirname
#      OHRDBMS: tgt_oh_link*
# Target Oracle home location <IHRDBMS>
# SAP Default    on Unix              : /oracle/<DB_SID>/<ORACLE_RELEASE_KURZ>
# Oracle Default on Engineered Systems: /u01/app/oracle/product/12.1.0.2/dbhome_1
tgt_oh_dirname=${ORACLE_RELEASE_KURZ}
tgt_oh_loc=""

# additional description of target Oracle home location
tgt_oh_loc_flag=""
tgt_oh_loc_flag1="" # existing / not existing
tgt_oh_loc_flag2="" # empty    / not empty
tgt_oh_loc_flag3="" # shared   / not shared

# The following flags indicate whether the installation location exists and is empty
tgt_oh_loc_exists=""     # no/yes
tgt_oh_loc_isempty=""    # no/yes
tgt_oh_loc_isshared="no" # no/yes: Flag indicating non-shared or shared Oracle home

# Target Runtime Oracle home location <OHRDBMS> (Symbolic link name and path)
# --------+------------------------+----------------------------------
# Release | Name of symbolic link  | Installation type
# --------+------------------------+----------------------------------
# 19c     | name of link is 19     | for all installations
# 18c     | name of link is 18     | for all installations
# 12.2    | name of link is 122    | for all installations
# 12.1    | name of link is 121    | for all installations
# 11,2    | name of link is 112    | for 64-bit, ASM or RAC
# 11.2    | name of link is 112_64 | for 64-bit, non-RAC, non-ASM
# 11.2    | name of link is 112_32 | for 32-bit, non-RAC, non-ASM
# --------+------------------------+----------------------------------
tgt_oh_linkname=""
tgt_oh_link=""
tgt_oh_link_flag=""
tgt_oh_link_flag1="" # existing / not existing
tgt_oh_link_flag2="" # installed / created by SAPINST
tgt_oh_link_flag3="" # symbolic link / lost symbolic link
tgt_oh_link_type=""
# create symbolic link with relative or absolute path (default=relative)
sym_link_path="relative"

# Create symbolic link "yes"/"no" (Default: "yes")
sym_link_create_opt="yes"

# Flag indicating whether the symbolic link was created ("no"/"yes")
sym_link_created="no"

# Flag indicating whether the target was installed by SAPINST
created_by_SAPINST_flag=""

# define privileged OS groups 
# Database Installation Guide for Linux
#  Configuring Users, Groups and Environments for Oracle Database
#    12.1: http://docs.oracle.com/database/121/LADBI/usr_grps.htm
#    12.2: http://docs.oracle.com/database/122/LADBI/creating-operating-system-privileges-groups.htm
#
# OS group   | Privilege | Group name         | Description
# name       |           |                    |
# -----------+-----------+--------------------+---------------------------------
# OSDBA      | SYSDBA    | dba                | database administrator (full)
# OSOPER     | SYSOPER   | oper               | database operator (startup, shutdown, ...)
# OSBACKUPDBA| SYSBACKUP | oper               | database backup and recovery administrator (RMAN, ...)
# OSDGDBA    | SYSDG     | dba                | database data guard administrator (Data Guard, Standby, ...)
# OSKMDBA    | SYSKM     | dba                | database key management administrator (Encryption key, wallet, Master key, ...)
# OSRACDBA   | SYSRAC    | dba                | RAC administrator
#

osgroup_name_install="Oracle inventory group"      
osgroup_name_dba="OSDBA"      
osgroup_name_oper="OSOPER"     
osgroup_name_backupdba="OSBACKUPDBA"
osgroup_name_dgdba="OSDGDBA"    
osgroup_name_kmdba="OSKMDBA"    
osgroup_name_racdba="OSRACDBA"   

osgroup_priv_dba="SYSDBA"      
osgroup_priv_oper="SYSOPER"     
osgroup_priv_backupdba="SYSBACKUP"
osgroup_priv_dgdba="SYSDG"    
osgroup_priv_kmdba="SYSKM"    
osgroup_priv_racdba="SYSRAC"   

osgroup_install="oinstall"
osgroup_dba="dba"
osgroup_oper="oper"
osgroup_backupdba="oper"
osgroup_dgdba="dba"
osgroup_kmdba="dba"
osgroup_racdba="dba"

group_inventory="${osgroup_dba}"
group_file=/etc/group

# -----------------------------------------------------------------------------
# Oracle runInstaller
# -----------------------------------------------------------------------------
ora_runinstaller_found="${STR_NO}"   # Flag: Oracle runInstaller file found (yes / no)
ora_runinstaller_path=""             # Oracle runInstaller path
ora_runinstaller_file="runInstaller" # Oracle runInstaller file name

# -----------------------------------------------------------------------------
# Oracle runInstaller Flags / OUI Flags
# -----------------------------------------------------------------------------

# Check OUI return code (-check_oui_rc)
# tee_opt="-tee"
# tee_pipe="|"
# tee_cmd=" tee "
case $platform in
  aix            ) tee_opt=""    ; tee_pipe="" ; tee_cmd=""      ;; # SAP internal incident 1870497010, tee command does not work on AIX
  *              ) tee_opt="-tee"; tee_pipe="|"; tee_cmd=" tee " ;;
esac

# OUI start flag
flag_start_oui="${STR_TRUE}"        # Indicates whether to start OUI or not (FALSE/TRUE)
flag_oui_was_started="${STR_FALSE}" # Indicates whether OUI was started or not (FALSE/TRUE)

# Initialize Oracle Database Setup Wizard (runInstaller) Version
OUI_VERSION_REAL_0="0.0.0.0.0"      # variable for getOUIVersion() function
OUI_VERSION_REAL_5=""               # OUI version found in oraparam.ini - 5 digits
OUI_VERSION_REAL_4=""               # OUI version found in oraparam.ini - 4 digits
OUI_VERSION_RFRC_5="12.2.0.7.0"     # OUI reference version - 5 digits (must be adapted for next release > 19c)
OUI_VERSION_RFRC_4="12.2.0.7"       # OUI reference version - 4 digits (must be adapted for next release > 19c)


# runInstaller OUI return code
# oui_env=""
# oui_env="LANG=C TMP=$tmp_dir_full TMPDIR=$tmp_dir_full"
# LANG=C: Purpose: always start OUI in English as default installer language
oui_result="UNKNOWN"

# runInstaller arguments
ignoreInternalDriverError=""
oui_ignorePrereq_1=""               # -ignorePrereqWarnings: -ignorePrereq
oui_ignorePrereq_2=""               # -ignorePrereqWarnings: -ignorePrereqFailure
oui_ignorePrereq_wrn="${STR_FALSE}" # Flag: warning when -ignorePrereq* options are used
oui_executePrereqs=""               # -ohcheck: prereqisites check (-executePrereqs)

# runInstaller silent mode
silent_mode=""          # silent mode          (-silent)
silent_mode_progress="" # silent mode progress (-silent) # [INS-04009] The argument [-showProgress] passed is not supported for the current context DBSetup

oui_nolink_mode=""
oui_invptrloc_option=""
oui_invptr_file=""
oui_invptr_file_exists=""

oui_wait_option="-waitForCompletion"
oui_lang_option=""

# OUI responseFile option
oui_rsp_opt="-responseFile"
oui_rsp_use="yes"
oui_rsp_file=""
oui_rsp_create="no" # option '-creatersp'

# OUI root script automation (-rsa)
#oracle.install.db.rootconfig.executeRootScript=false
#oracle.install.db.rootconfig.configMethod=ROOT # ROOT
#oracle.install.db.rootconfig.rootUserName=     # ROOT (not yet supported, see Oracle Enh. Req. 29801905)
#oracle.install.db.rootconfig.configMethod=SUDO # SUDO
#oracle.install.db.rootconfig.sudoPath=         # SUDO (e.g. /usr/bin/sudo)
#oracle.install.db.rootconfig.sudoUserName=     # SUDO
#Installation log shows:
#INFO:  [Sep 1, 2022 3:20:55 PM] Running root scripts using specified configuration method successful.
#INFO:  [Sep 1, 2022 3:20:55 PM] Running root scripts using specified configuration method successful.
#INFO:  [Sep 1, 2022 3:20:55 PM] Overall status of execution of root/configuration scripts : succeeded

oui_rsa_option="false"                          # false or true (true means RSA is enabled )
oui_rsa_option_verify="true"                    # false or true (with password verification)
oui_rsa_option_noverify="false"                 # false or true (w/o  password verification)
oui_rsa_option_nopassword="false"               # false or true (sudo passwordless         )

oui_rsa_method=""                               # ROOT or SUDO
oui_rsa_result=""                               # result of root script automation (SUCCESS or FAILED)

oui_rsa_userun=""                               # rsa  username (generic    )
oui_rsa_userpw=""                               # rsa  password (transparent)
oui_rsa_userpx=""                               # rsa  password (masked     )
oui_rsa_userp2=""                               # rsa  password (re-enter   )

oui_rsa_rootun="root"                           # root username (default: root, see Oracle Enh. Req. 29801905)
oui_rsa_rootpw=""                               # root password (transparent)
oui_rsa_rootpx=""                               # root password (masked     )
oui_rsa_rootp2=""                               # root password (re-enter   )

oui_rsa_sudoun="${run_username}"                # sudo username (default: current user=Oracle software owner)
oui_rsa_sudopw=""                               # sudo password (transparent)
oui_rsa_sudopx=""                               # sudo password (masked     )
oui_rsa_sudop2=""                               # sudo password (re-enter   )
oui_rsa_sudoph="/usr/bin/sudo"                  # sudo path     (Default: /usr/bin/sudo)

# -----------------------------------------------------------------------------
# oraInst.loc / oratab / orabasetab
# -----------------------------------------------------------------------------

# extension of Unix shared libraries (.so or .sl)
shared_lib_ext=".so"

case $platform in
  aix            ) shared_lib_ext=".so" ; bit="64" ; ORAINST_LOCATION="/etc/oraInst.loc"            ; ORATAB_LOCATION="/etc/oratab"            ;;
  hp_ux_9000_800 ) shared_lib_ext=".sl" ; bit="64" ; ORAINST_LOCATION="/var/opt/oracle/oraInst.loc" ; ORATAB_LOCATION="/var/opt/oracle/oratab" ;;
  hp_ux_ia64     ) shared_lib_ext=".so" ; bit="64" ; ORAINST_LOCATION="/var/opt/oracle/oraInst.loc" ; ORATAB_LOCATION="/etc/oratab"            ;;
  sunos_sun4u    ) shared_lib_ext=".so" ; bit="64" ; ORAINST_LOCATION="/var/opt/oracle/oraInst.loc" ; ORATAB_LOCATION="/var/opt/oracle/oratab" ;;
  sunos_i86pc    ) shared_lib_ext=".so" ; bit="64" ; ORAINST_LOCATION="/var/opt/oracle/oraInst.loc" ; ORATAB_LOCATION="/var/opt/oracle/oratab" ;;
  osf1_alpha     ) shared_lib_ext=".so" ; bit="64" ; ORAINST_LOCATION="/var/opt/oracle/oraInst.loc" ; ORATAB_LOCATION="/var/opt/oracle/oratab" ;;
  linux_x86_64   ) shared_lib_ext=".so" ; bit="64" ; ORAINST_LOCATION="/etc/oraInst.loc"            ; ORATAB_LOCATION="/etc/oratab"            ;;
  linux_i686     ) shared_lib_ext=".so" ; bit="32" ; ORAINST_LOCATION="/etc/oraInst.loc"            ; ORATAB_LOCATION="/etc/oratab"            ;;
  linux_ia64     ) shared_lib_ext=".so" ; bit="64" ; ORAINST_LOCATION="/var/opt/oracle/oraInst.loc" ; ORATAB_LOCATION="/var/opt/oracle/oratab" ;;
  linux_ppc64    ) shared_lib_ext=".so" ; bit="64" ; ORAINST_LOCATION="/etc/oraInst.loc"            ; ORATAB_LOCATION="/etc/oratab"            ;;
  *              ) echo_err "Cannot determine oraInst.loc information for platform \"$platform\"."                                                ;;
esac

# -----------------------------------------------------------------------------
# Oracle home image file (Simplified image-based installation)
# -----------------------------------------------------------------------------
ORA_GOLD_IMAGE_FILE_S="db_home.zip" # short name - not used
ORA_GOLD_IMAGE_FILE_L=""            # long name  - set below
ORA_GOLD_IMAGE_FILE_CNT=45000       # number of files in Oracle Home Image File (estimated, valid for all Unix platforms)

case $platform in
  aix            ) ORA_GOLD_IMAGE_FILE_CNT=45000 ;; # zip archive info: 36425 files
  hp_ux_ia64     ) ORA_GOLD_IMAGE_FILE_CNT=45000 ;; # zip archive info: 34650 files
  sunos_sun4u    ) ORA_GOLD_IMAGE_FILE_CNT=45000 ;; # zip archive info: 36901 files
  linux_x86_64   ) ORA_GOLD_IMAGE_FILE_CNT=45000 ;; # zip archive info: 38558 files
  sunos_i86pc    ) ORA_GOLD_IMAGE_FILE_CNT=45000 ;; # default
  *              ) echo_err "Cannot determine Oracle home image file count information for platform \"$platform\"."                                                ;;
esac

# -----------------------------------------------------------------------------
# Check Sums: sha256sum / md5sum
# -----------------------------------------------------------------------------

case $platform in
  aix            ) ORA_GOLD_IMAGE_FILE_L="AIX.PPC64_193000_db_home.zip"       ; ORA_SHA256SUM="03cb2aff2984b47597108572048d4ee432c7e05a74362829f5ddb5540baf56b1";;
  hp_ux_ia64     ) ORA_GOLD_IMAGE_FILE_L="HPUX.IA64_193000_db_home.zip"       ; ORA_SHA256SUM="70670e0022678bfb8f2e5b5f6f636eeebb9b20c68e3fe8dd79562e116ca1c59c";;
  sunos_sun4u    ) ORA_GOLD_IMAGE_FILE_L="SOLARIS.SPARC64_193000_db_home.zip" ; ORA_SHA256SUM="ac52bfd8c82bb1b72478ee0cbdba60f2cf5c46c02b2aef60e0d54253b3f02309";;
  linux_x86_64   ) ORA_GOLD_IMAGE_FILE_L="LINUX.X64_193000_db_home.zip"       ; ORA_SHA256SUM="ba8329c757133da313ed3b6d7f86c5ac42cd9970a28bf2e6233f3235233aa8d8";;
  sunos_i86pc    ) ORA_GOLD_IMAGE_FILE_L="SOLARIS.X64_195000_db_home.zip"     ; ORA_SHA256SUM="d864a106d2bdc6f0e565a6357f003fe3419398170f89326c8e6823253a95e723";;
##hp_ux_9000_800 ) ORA_GOLD_IMAGE_FILE_L="db_home.zip" ; ORA_SHA256SUM="";; # not supported any more
##osf1_alpha     ) ORA_GOLD_IMAGE_FILE_L="db_home.zip" ; ORA_SHA256SUM="";; # not supported any more
##linux_i686     ) ORA_GOLD_IMAGE_FILE_L="db_home.zip" ; ORA_SHA256SUM="";; # not supported any more
##linux_ia64     ) ORA_GOLD_IMAGE_FILE_L="db_home.zip" ; ORA_SHA256SUM="";; # not supported any more
##linux_ppc64    ) ORA_GOLD_IMAGE_FILE_L="db_home.zip" ; ORA_SHA256SUM="";; # not supported any more
  *              ) echo_err "Cannot determine platform information for platform \"$platform\"."                                                ;;
esac

ora_chksum_reference="$ORA_SHA256SUM" # sha256sum reference value
ora_chksum_value=""                   # sha256sum calculated value
ora_chksum_check="${STR_NO}"          # -sha256sum option has been selected
ora_chksum_is_checked="${STR_NO}"     # sha256sum value has been calculated
ora_chksum_is_valid=""                # sha256sum value is identical to reference value -> file is ok

###############################################################################
#                                                                             #
#                                                                             #
#                                                                             #
#                         DEFINITION OF FUNCTIONS                             #
#                                                                             #
#                                                                             #
#                                                                             #
###############################################################################

# -----------------------------------------------------------------------------
# Output functions (deprecated)
# -----------------------------------------------------------------------------

LEAD_CHAR="."
echo_std() {
  #
  # NAME
  #   echo_std - standard output function
  #
  # SYNOPSIS
  #   echo_std <string>
  #
  # DESCRIPTION
  #   This function writes a string to standard output and to log file.
  #
  echo ${LEAD_CHAR} "$*"
  if [ "${logging_status}" = "ON" ]; then
    echo ${LEAD_CHAR} "$*" >> $sap_log_file_single
    echo_rc=$?
    if [ $echo_rc -ne 0 ]; then
      echo
      echo "${MSG_ERRR}" "Logging disabled."
      echo "Can not write to log file $sap_log_file_single. Check permissions."
      echo
      logging_status="OFF"
    fi
  fi
}

echo_vrb() {
  #
  # NAME
  #   echo_vrb - standard output function for verbose mode
  #
  # SYNOPSIS
  #   echo_vrb <string>
  #
  # DESCRIPTION
  #   Writes to stdout if verbose mode is enabled.
  #
  if [ "${verbose_mode}" = "${STR_ENABLED}" ]; then
    echo_std "${MSG_VRBM}" "$*"
    #echo_std "$*"
  fi
}

echo_trc() {
  #
  # NAME
  #   echo_trc - standard output function for trace mode
  #
  # SYNOPSIS
  #   echo_trc <string>
  #
  # DESCRIPTION
  #   Writes to stdout if trace mode is enabled.
  #
  if [ "${trace_mode}" = "${STR_ENABLED}" ]; then
    echo_std "${MSG_TRCM}" "$*"
  fi
}

echo_sum() {
  #
  # NAME
  #   echo_sum - writes to summary log file (history log file) - former name: echo_hist
  #
  # SYNOPSIS
  #   echo_sum <string>
  #
  # DESCRIPTION
  #   This function writes a string to the summary log file.
  #
  echo "$*" >> ${sap_log_file_summary}
  echo_rc=$?
  if [ $echo_rc -ne 0 ]; then
    echo
    echo "Can not write to summary log file ${sap_log_file_summary}. Check permissions."
    echo
  fi
  if [ -f ${sap_log_file_summary} ]; then
  	chmod 664 ${sap_log_file_summary} || MSGWARNS "Changing permissions on summary log file ${sap_log_file_summary} failed."
  else
    echo "${MSG_WARN}" "Summary log file ${sap_log_file_summary} does not exist."
  fi
}

echo_nln() {
  #
  # NAME
  #   echo_nln - new line
  #
  # SYNOPSIS
  #   echo_nln
  #
  # DESCRIPTION
  #   This function writes an empty new line
  #
  echo
  [ "${logging_status}" = "ON" ] &&  echo >> $sap_log_file_single
}

echo_cmd() {
  #
  # NAME
  #   echo_cmd - standard output function for commands
  #
  # SYNOPSIS
  #   echo_cmd <command string>
  #
  # DESCRIPTION
  #   This function writes a command string to standard output and to log file.
  #
  echo "$*"
  [ "${logging_status}" = "ON" ] &&  echo "$*" >> $sap_log_file_single
}

# -----------------------------------------------------------------------------
# New Output functions
# -----------------------------------------------------------------------------

###############################################################################
# MSGOUTX                        : internal                                   #
# MSGINFOS   MSGWARNS   MSGERRRS : standard mode                              #
# MSGINFOV   MSGWARNV   MSGERRRV : verbose  mode                              #
# MSGINFOT   MSGWARNT   MSGERRRT : trace    mode                              #
###############################################################################

MSGOUTX() {
  #
  # NAME
  #   MSGOUTX
  #
  # SYNOPSIS
  #   MSGOUTX <string>
  #
  # DESCRIPTION
  #   This function must only be used by dedicated output functions.
  #
  echo "${LEAD_CHAR}" "$*"
  if [ "${logging_status}" = "ON" ]; then
    echo "${LEAD_CHAR}" "$*" >> $sap_log_file_single
    echo_rc=$?
    if [ $echo_rc -ne 0 ]; then
      echo
      echo "${MSG_STR_ERRRS}" "Logging disabled."
      echo "${MSG_STR_ERRRS}" "Can not write to log file $sap_log_file_single. Check permissions."
      echo
      logging_status="OFF"
    fi
  fi
}

## Functions for standard output
MSGFREES() {                                             MSGOUTX                    "$*"; } # standard free
MSGINFOS() {                                             MSGOUTX "${MSG_STR_INFOS}" "$*"; } # standard info
MSGWARNS() {                                             MSGOUTX "${MSG_STR_WARNS}" "$*"; } # standard warning
MSGERRRS() {                                             MSGOUTX "${MSG_STR_ERRRS}" "$*"; } # standard error
## Functions for verbose output
MSGFREEV() { [ "${verbose_mode}" = "${STR_ENABLED}" ] && MSGOUTX                    "$*"; } # verbose  free    
MSGINFOV() { [ "${verbose_mode}" = "${STR_ENABLED}" ] && MSGOUTX "${MSG_STR_INFOV}" "$*"; } # verbose  info    
MSGWARNV() { [ "${verbose_mode}" = "${STR_ENABLED}" ] && MSGOUTX "${MSG_STR_WARNV}" "$*"; } # verbose  warning 
MSGERRRV() { [ "${verbose_mode}" = "${STR_ENABLED}" ] && MSGOUTX "${MSG_STR_ERRRV}" "$*"; } # verbose  error   
## Functions for trace output
MSGFREET() { [ "${trace_mode}"   = "${STR_ENABLED}" ] && MSGOUTX                    "$*"; } # trace    free    
MSGINFOT() { [ "${trace_mode}"   = "${STR_ENABLED}" ] && MSGOUTX "${MSG_STR_INFOT}" "$*"; } # trace    info    
MSGWARNT() { [ "${trace_mode}"   = "${STR_ENABLED}" ] && MSGOUTX "${MSG_STR_WARNT}" "$*"; } # trace    warning 
MSGERRRT() { [ "${trace_mode}"   = "${STR_ENABLED}" ] && MSGOUTX "${MSG_STR_ERRRT}" "$*"; } # trace    error   

MSGDATETIME() {
  cur_date=`date "+%Y-%m-%d"`
  cur_time=`date "+%H-%M-%S"`
 #MSGFREES "Date/Time: ${cur_date} ${cur_time} (Starting task $*)"
 #MSGINFOS "${cur_date} ${cur_time} - Starting task $*"
  MSGINFOS "${cur_date} ${cur_time}"
}

MSGTASKINFO() {
  MSGINFOS "############################################################"
  MSGINFOS "TASK: $*"
  MSGINFOS "############################################################"
}

# -----------------------------------------------------------------------------
# Exit functions
# -----------------------------------------------------------------------------

install_exit_succ() {
  #
  # NAME
  #   install_exit_succ
  #
  # SYNOPSIS
  #   install_exit_succ
  #
  # DESCRIPTION
  #   Exit with success
  #
  exit $RC_SUCC
}

install_exit_warn() {
  #
  # NAME
  #   install_exit_warn
  #
  # SYNOPSIS
  #   install_exit_warn
  #
  # DESCRIPTION
  #   Exit with warning
  #
  exit $RC_WARN
}

install_exit_errr() {
  #
  # NAME
  #   install_exit_errr
  #
  # SYNOPSIS
  #   install_exit_errr
  #
  # DESCRIPTION
  #   Exit with error
  #
  exit $RC_ERRR
}

install_exit() {
  #
  # NAME
  #   install_exit - standard exit function
  #
  # SYNOPSIS
  #   install_exit <EXIT_CODE>
  #
  # DESCRIPTION
  #   Exit this script with the given exit code.
  #
  
  # show argument
  #echo_std $*
  
  # cleanup
  inst_session_cleanup
  
  # Begin of exit
  echo_std  
  
  # Show log files
  [ -n "${oui_session_log}"     ] && [ -f ${oui_session_log}     ] && MSGINFOS "${STR_OUI_NAME_0}: you find the log file at ${oui_session_log}"
  [ -n "${sap_log_file_single}" ] && [ -f ${sap_log_file_single} ] &&	MSGINFOS "$STR_SRI_NAME: you find the log file at ${sap_log_file_single}"
  
  # Number of arguments must be 1
  if [ $# -ne 1 ]; then
    echo_std "${MSG_IERR}" "Exit code missing."
    echo_std "Exiting with exit code ${RC_ERRR}."
    exit $RC_ERRR
  fi

  # Return codes numerical values (0/1/2) -> return code string values (success/warning/error)
  # tbd
  case $rct_ohp in $RC_SUCC) rct_ohp_str="${STR_SUCC}" ;; $RC_WARN) rct_ohp_str="${STR_WARN}" ;; $RC_ERRR) rct_ohp_str="${STR_ERRR}" ;; *) rct_ohp_str="${STR_NDEF}" ;; esac
  case $rct_ohv in $RC_SUCC) rct_ohv_str="${STR_SUCC}" ;; $RC_WARN) rct_ohv_str="${STR_WARN}" ;; $RC_ERRR) rct_ohv_str="${STR_ERRR}" ;; *) rct_ohv_str="${STR_NDEF}" ;; esac
  case $rct_ohx in $RC_SUCC) rct_ohx_str="${STR_SUCC}" ;; $RC_WARN) rct_ohx_str="${STR_WARN}" ;; $RC_ERRR) rct_ohx_str="${STR_ERRR}" ;; *) rct_ohx_str="${STR_NDEF}" ;; esac
  case $rct_ohc in $RC_SUCC) rct_ohc_str="${STR_SUCC}" ;; $RC_WARN) rct_ohc_str="${STR_WARN}" ;; $RC_ERRR) rct_ohc_str="${STR_ERRR}" ;; *) rct_ohc_str="${STR_NDEF}" ;; esac
  case $rct_ohr in $RC_SUCC) rct_ohr_str="${STR_SUCC}" ;; $RC_WARN) rct_ohr_str="${STR_WARN}" ;; $RC_ERRR) rct_ohr_str="${STR_ERRR}" ;; *) rct_ohr_str="${STR_NDEF}" ;; esac
  case $rct_ohs in $RC_SUCC) rct_ohs_str="${STR_SUCC}" ;; $RC_WARN) rct_ohs_str="${STR_WARN}" ;; $RC_ERRR) rct_ohs_str="${STR_ERRR}" ;; *) rct_ohs_str="${STR_NDEF}" ;; esac
  case $rct_ohm in $RC_SUCC) rct_ohm_str="${STR_SUCC}" ;; $RC_WARN) rct_ohm_str="${STR_WARN}" ;; $RC_ERRR) rct_ohm_str="${STR_ERRR}" ;; *) rct_ohm_str="${STR_NDEF}" ;; esac
  
  # Show result (Return code numberical values)
  #[ "${run_ohp}" = "${STR_YES}" ] && MSGINFOS "Task completed (${rct_ohp}): ${dsc_ohp}" # MSGINFOS "${dsc_ohp} finished with return code ${rct_ohp}" 
  #[ "${run_ohv}" = "${STR_YES}" ] && MSGINFOS "Task completed (${rct_ohv}): ${dsc_ohv}" # MSGINFOS "${dsc_ohv} finished with return code ${rct_ohv}" 
  #[ "${run_ohx}" = "${STR_YES}" ] && MSGINFOS "Task completed (${rct_ohx}): ${dsc_ohx}" # MSGINFOS "${dsc_ohx} finished with return code ${rct_ohx}" 
  #[ "${run_ohc}" = "${STR_YES}" ] && MSGINFOS "Task completed (${rct_ohc}): ${dsc_ohc}" # MSGINFOS "${dsc_ohc} finished with return code ${rct_ohc}" 
  #[ "${run_ohr}" = "${STR_YES}" ] && MSGINFOS "Task completed (${rct_ohr}): ${dsc_ohr}" # MSGINFOS "${dsc_ohr} finished with return code ${rct_ohr}" 
  #[ "${run_ohs}" = "${STR_YES}" ] && MSGINFOS "Task completed (${rct_ohs}): ${dsc_ohs}" # MSGINFOS "${dsc_ohs} finished with return code ${rct_ohs}" 

  # Show result (Return code string values)
  [ "${run_ohp}" = "${STR_YES}" ] && MSGINFOS "Task completed with ${rct_ohp_str}: ${dsc_ohp}"
  [ "${run_ohv}" = "${STR_YES}" ] && MSGINFOS "Task completed with ${rct_ohv_str}: ${dsc_ohv}"
  [ "${run_ohx}" = "${STR_YES}" ] && MSGINFOS "Task completed with ${rct_ohx_str}: ${dsc_ohx}"
  [ "${run_ohc}" = "${STR_YES}" ] && MSGINFOS "Task completed with ${rct_ohc_str}: ${dsc_ohc}"
  [ "${run_ohr}" = "${STR_YES}" ] && MSGINFOS "Task completed with ${rct_ohr_str}: ${dsc_ohr}"
  [ "${run_ohs}" = "${STR_YES}" ] && MSGINFOS "Task completed with ${rct_ohs_str}: ${dsc_ohs}"
  [ "${run_ohm}" = "${STR_YES}" ] && MSGINFOS "Task completed with ${rct_ohm_str}: ${dsc_ohm}"

  # Show exit code
 #echo_std "${MSG_EXIT}" "Exiting with exit code $1."
 #MSGINFOS "Exiting with exit code $1."
  case $1 in 
    $RC_SUCC         ) RC_STR_VAL="${STR_SUCC}" ;; 
    $RC_WARN         ) RC_STR_VAL="${STR_WARN}" ;; 
    $RC_ERRR         ) RC_STR_VAL="${STR_ERRR}" ;; 
    $RC_PREREQ_ERROR ) RC_STR_VAL="${STR_ERRR}" ;; 
    $RC_INVARG_ERROR ) RC_STR_VAL="${STR_ERRR}" ;; 
    *                ) RC_STR_VAL="${STR_NDEF}" ;;
  esac
  
  # Final date / time
  MSGDATETIME

  # Final Exit Code / Final Completion Status
  MSGINFOS "${STR_SRI_NAME}: Completed with ${RC_STR_VAL}."
  MSGINFOS "${STR_SRI_NAME}: Exiting with exit code $1."
  
  # Final exit here
  exit $1
}

# -----------------------------------------------------------------------------
# Check functions
# -----------------------------------------------------------------------------

##is_lost_link() {
##  [ $# -eq 1 ] || return 1
##  [ -h "$1"  ] || return 1
##  lost_link_target=`readlink -n $1`
##  MSGINFOT "is_lost_link: link: $1 -> $lost_link_target"
##  if [ -e "$lost_link_target" ]; then
##  	# link target exists
##    MSGINFOT "is_lost_link: not a lost link"
##    return 1;
##  fi
##  
##  # link target does not exist
##  MSGINFOT "is_lost_link: link is lost"
##  return 0
##}

is_link() {
  if [ $# -ne 1 ]; then
    return 1
  fi
  if [ -h "$1" ];  then
    return 0;
  fi
  return 1;
}

create_sym_link() {
  #
  # NAME
  #   create_sym_link
  #
  # SYNOPSIS
  #   create_sym_link
  #
  # DESCRIPTION
  #   This function will return true (0) if the symbolic link will be created
  #   otherwise, it will return false (1).
  if [ "$sym_link_create_opt" = "yes" ]; then
    return 0;
  fi

  return 1;
}

db_sid_is_mandatory() {
  #
  # NAME
  #   db_sid_is_mandatory
  #
  # SYNOPSIS
  #   db_sid_is_mandatory
  #
  # DESCRIPTION
  #   This function will return true (0) if DB_SID must be set in the environment;
  #   otherwise, it will return false (1).
  MSGINFOT "db_sid_is_mandatory: "
  if [ "$opt_dbsid_mandatory" = "yes" ]; then
  	MSGINFOT "DB_SID is mandatory"
    return 0;
  fi

  MSGINFOT "DB_SID is not mandatory"
  return 1;
}

is_engineered_system() {
  #
  # NAME
  #   is_engineered_system
  #
  # SYNOPSIS
  #   is_engineered_system
  #
  # DESCRIPTION
  #   This function will return true (0) if this is an Oracle Engineered System
  #   otherwise, it will return false (1).
  MSGINFOT "is_engineered_system: "

  if [ -d "/u01/app/oracle" ]; then
    MSGINFOT "Oracle Engineered System: YES"
    return 0;
  fi

  MSGINFOT "Oracle Engineered System: NO"
  return 1;
}

db_sid_is_set() {
  #
  # NAME
  #   db_sid_is_set
  #
  # SYNOPSIS
  #   db_sid_is_set
  #
  # DESCRIPTION
  #   This function will return true (0) if DB_SID is set in the environment;
  #   otherwise, it will return false (1).
  MSGINFOT "db_sid_is_set: "
  if [ -n "$DB_SID" ]; then
    MSGINFOT "DB_SID is set"
    return 0;
  fi

  MSGINFOT "DB_SID is not set"
  return 1;
}

db_sid_is_not_set() {
  #
  # NAME
  #   db_sid_is_not_set
  #
  # SYNOPSIS
  #   db_sid_is_not_set
  #
  # DESCRIPTION
  #   opposite of db_sid_is_set
  MSGINFOT "db_sid_is_not_set: "
  if [ -z "$DB_SID" ]; then
    MSGINFOT "DB_SID is not set"
    return 0;
  fi

  MSGINFOT "DB_SID is set"
  return 1;
}

PostSharedOhInstall() {
  #
  # NAME
  #   PostSharedOhInstall
  #
  # SYNOPSIS
  #   PostSharedOhInstall
  #
  # DESCRIPTION
  #   This function will return 
  #   true (0) after an installation of a shared Oracle home; 
  #   false (1) otherwise

  if [ "${query_mode}" = "${STR_ENABLED}" ]; then
    # do not perform post installation tasks
    MSGINFOT "Skipping post installation tasks - query_mode = ${query_mode}"
    post_install_skip_reason="query_mode = ${query_mode}"
    return 1
  fi

  if [ "$tgt_oh_loc_isshared" = "yes" ]; then
    MSGINFOT "This is the installation for a shared Oracle home."
    return 0;
  fi

  return 1;
}

SharedOhInstall() {
  #
  # NAME
  #   SharedOhInstall
  #
  # SYNOPSIS
  #   SharedOhInstall
  #
  # DESCRIPTION
  #   This function will return true (0) if this is an installation
  #   of a shared Oracle home; otherwise, it will return false (1).
  MSGINFOT "SharedOhInstall: "
  if [ "$tgt_oh_loc_isshared" = "yes" ]; then
    MSGINFOT "This is the installation for a shared Oracle home."
    return 0;
  fi

  MSGINFOT "This is the installation for a non-shared Oracle home."
  return 1;
}

SharedOhExists() {
  #
  # NAME
  #   SharedOhExists
  #
  # SYNOPSIS
  #   SharedOhExists
  #
  # DESCRIPTION
  #   This function will return true (0) if this is an installation
  #   of a shared Oracle home and this Oracle home already exists;
  #   otherwise, it will return false (1).
  MSGINFOT "SharedOhExists: "
  if [ "$tgt_oh_loc_isshared" = "yes" ] && 
  	 [ "$tgt_oh_loc_exists" = "yes" ] &&
  	 [ "$tgt_oh_loc_isempty" = "no" ]; then
  	# shared Oracle home already exists
    MSGINFOT "The shared Oracle home exists."
    return 0;
  fi

  # no shared Oracle home
  MSGINFOT "The shared Oracle home does not exist."
  return 1;
}


CanCreateFileIn() {
  #
  # NAME
  #   CanCreateFileIn
  #
  # SYNOPSIS
  #   CanCreateFileIn <path>
  #
  # DESCRIPTION
  #   This function will return true (0) if you have permissions
  #   to create a file in path specified; otherwise, it will return
  #   false (1).
  #
  # EXAMPLE
  #   Don't use this function with '!' as 'not'. This is not POSIX standard and does not work
  #   on Solaris 10.
  #   if ! CanCreateFileIn <dir>; then ...
  # 
  #   Use this function in the following way:
  #   if CanCreateFileIn <dir>; then
  #     :
  #   else
  #     <put here if you can not create a file in <dir>
  #   fi
  #
  if [ $# -eq 1 ] && [ -w $1 ] && [ -x $1 ]; then
    return 0;
  fi

  # no write permissions
  return 1;
}

is_dir() {
  if [ $# -ne 1 ]; then
    return 1
  fi
  if [ -d "$1" ];  then
    return 0;
  fi
  return 1;
}

# 2018-11-16: JS version (Jens version)
is_empty_dir() {
	# echo $1
  if ls -A "$1" | grep . 1>/dev/null ; then
    # echo not empty
    return 1
  else
    # echo empty
    return 0
  fi
}
# $ mkdir haha                     
# $ mkdir hihi                     
# $ touch hihi/.xxx                
# $ ls -A haha | grep .            
# $ echo $?                        
# 1                                
# $ ls -A hihi | grep .            
# .xxx                             
# $  echo $?                       
# 0                                
# $ ls -A haha | grep . 1>/dev/null
# $ echo $?                        
# 1                                
# $ ls -A hihi | grep . 1>/dev/null
# $ echo $?                        
# 0                                
# $                                


IsDir() {
  #
  # NAME
  #   IsDir - determine if a path is a directory
  #
  # SYNOPSIS
  #   IsDir <path>
  #
  # DESCRIPTION
  #   This function will return true (0) if the string contains a path
  #   that exists and that is a directory; otherwise, it will return
  #   false (1).
  #
  if [ $# -ne 1 ]; then
    return 1
  fi
  if [ -d "$1" ]; then
    return 0
  fi

  return 1
}

IsFile() {
  #
  # NAME
  #   IsFile - determine if a path is a regular file
  #
  # SYNOPSIS
  #   IsFile <path>
  #
  # DESCRIPTION
  #   This function will return true (0) if the string contains a path
  #   that exists and that is a regular file; otherwise, it will return
  #   false (1).
  #
  if [ $# -ne 1 ]; then
    return 1
  fi
  if [ -f "$1" ]; then
    return 0
  fi

  return 1
}

IsLink() {
  #
  # NAME
  #   IsLink - determine if a path is a symbolic link
  #
  # SYNOPSIS
  #   IsLink <path>
  #
  # DESCRIPTION
  #   This function will return true (0) if the string contains a path
  #   that exists and that is a symbolic link; otherwise, it will return
  #   false (1).
  #
  if [ $# -ne 1 ]; then
    return 1
  fi
  if [ -h "$1" ]; then
    return 0
  fi

  return 1
}

PathExists() {
  #
  # NAME
  #   PathExists - determine if a path exists
  #
  # SYNOPSIS
  #   PathExists <path>
  #
  # DESCRIPTION
  #   This function will return true (0) if the string contains a path
  #   that exists and that is any type of file; otherwise, it will return
  #   false (1).
  #
  if [ $# -ne 1 ]; then
    return 1
  fi
  if [ -f "$1" ] || [ -h "$1" ] || [ -d "$1" ]; then
    return 0
  fi

  return 1
}

PathIsAbs() {
  #
  # NAME
  #   PathIsAbs - determine if path is absolute
  #
  # SYNOPSIS
  #   PathIsAbs <path>
  #
  # DESCRIPTION
  #   returns (0) if path is absolute
  #   returns (1) if path is relative
  # REFERENCE
  #   http://www.unix.com/shell-programming-and-scripting/38018-test-whether-absolute-path-variable.html
  #
  if [ $# -ne 1 ]; then
    return 1
  fi
  case $1 in
    /* )
      # absolute
      return 0
      ;;
    *)
      # relative
      return 1
      ;;
  esac
}

PathIsRel() {
  #
  # NAME
  #   PathIsRel - determine if path is relative
  #
  # SYNOPSIS
  #   PathIsRel <path>
  #
  # DESCRIPTION
  #   returns (0) if path is relative
  #   returns (1) if path is absolute
  # REFERENCE
  #   http://www.unix.com/shell-programming-and-scripting/38018-test-whether-absolute-path-variable.html
  #
  if [ $# -ne 1 ]; then
    return 1
  fi
  case $1 in
    /* )
      # absolute
      return 1
      ;;
    *)
      # relative
      return 0
      ;;
  esac
}

RunningAsRoot() {
  #
  # RunningAsRoot
  #   RunningAsRoot - determine whether you are running as root
  #
  # SYNOPSIS
  #   RunningAsRoot
  #
  # DESCRIPTION
  #   This function will return 
  #     true  (0) if the logon user is root
  #     false (1) otherwise
  #
  RUID=`/usr/bin/id|${OS_AWK} -F\( '{print $1}'|${OS_AWK} -F= '{print $2}'`
  [ $RUID -eq 0 ] && return 0
  return 1
}

PostInstTasksRun() {
  #
  # NAME
  #   PostInstTasksRun - determine whether to run post installation tasks
  #
  # SYNOPSIS
  #   PostInstTasksRun
  #
  # DESCRIPTION
  #   This function will return true (0) if it is indicated to run post installations tasks;
  #   otherwise, it will return false (1).
  #
  
  if [ -n "${oui_executePrereqs}" ]; then
    # do not perform post installation tasks
    MSGINFOT "Skipping post installation tasks - ${oui_executePrereqs}"
    post_install_skip_reason="${oui_executePrereqs}"
    return 1
  fi
  
  if [ "${query_mode}" = "${STR_ENABLED}" ]; then
    # do not perform post installation tasks
    MSGINFOT "Skipping post installation tasks - query_mode = ${query_mode}"
    post_install_skip_reason="query_mode = ${query_mode}"
    return 1
  fi

  # Default: perform post-installation tasks
    MSGINFOT "Performing post installation tasks - default action"
    return 0
}

group_check() {
  #
  # NAME
  #   group_check - Check in /etc/group whether a given group exists
  #
  # SYNOPSIS
  #   group_check <name>
  #
  # DESCRIPTION
  #   Check in /etc/group whether a given group exists
  #
  # RETURN VALUES:
  #   0: group is defined
  #   1: group is not defined
  #   2: existence of group could not be checked.

  if [ $# -eq 0 ]; then 
    # invalid: missing argument for group name
    return 2; 
  fi
  grp_name=$1
  
  if [ -f $group_file ]; then 
    :
  else
    # /etc/group missing
    return 2;
  fi
  
  grp_name_result=`${OS_GREP} "^${grp_name}:" $group_file|cut -d: -f1`
  
  if [ "$grp_name_result" = "$grp_name" ]; then
    # found
    return 0;
  else
    # not found
    return 1;
  fi
}

getOUIVersion() {
  #
  # NAME
  #   OUIVersion - determine version of OUI
  #
  # SYNOPSIS
  #   OUIVersion <stage>
  #
  # DESCRIPTION
  #   This function checks the version of OUI in <extracted_oracle_home/oui/oraparam.ini.
  #
  # EXAMPLE
  #   OUI_VERSION_REAL_0=12.2.0.4.0
  #
  #   If the version string is found, the function returns true (0), otherwise false (1).
  
  if [ $# -ne 1 ]; then
    echo_std ${MSG_IERR} "getOUIVersion(): argument missing"
    return 1
  fi
  
 #ORAPARAMINI="$1/install/oraparam.ini" # 12.2 and before (stage)
  ORAPARAMINI="$1/oui/oraparam.ini"     # 19c and higher (extracted OH)
  if [ -f "$ORAPARAMINI" ]; then
    OUI_VERSION_REAL_0=`${OS_GREP} "OUI_VERSION" $ORAPARAMINI | ${OS_AWK} -F\( '{print $1}' | ${OS_AWK} -F= '{print $2}'`
    if [ -n "$OUI_VERSION_REAL_0" ]; then
      # entry found
      return 0
    else
      # entry not found
      OUI_VERSION_REAL_0="0.0.0.0.0"
      MSGWARNS "getOUIVersion(): OUI version not found in $ORAPARAMINI"
      return 1
    fi
  fi
  
  # not found
  # OUI_VERSION_REAL_0="0.0.0.0.0"
  MSGWARNS "getOUIVersion(): $ORAPARAMINI not found."
  return 1
}

# -----------------------------------------------------------------------------
# Show Usage functions
# -----------------------------------------------------------------------------

show_usage() {
  #
  # NAME
  #   show_usage - Show help on command line options
  #
  # SYNOPSIS
  #   show_usage
  #   show_usage all
  #
  # DESCRIPTION
  #
  #   This function displays the usage of the script and supported options.
  #   '-help all' also displays internal script options.

  if [ -n "${script_caller}" ]; then
    script_name=${script_caller}
  fi

 #echo_std "$script_bnnr"
 #echo_std "Version $script_vers Release Date $script_date Patch Level $script_plvl $script_stat"
  MSGFREES "$script_name ${script_vers} (${script_plvl}) ${script_date} ${script_stat}"
 
  MSGFREES
  MSGFREES "Usage:"
  MSGFREES
  MSGFREES " '${script_name} [all options]'"
  MSGFREES "        [basic options]            - basic options for script ${script_name}"
  MSGFREES "        [check options]            - options for additional checks"
  MSGFREES "        [main install options]     - Oracle home installation main options"
  MSGFREES "        [install step options]     - Oracle home installation step-by-step"
  MSGFREES "        [advanced install options] - Oracle home installation advanced options"
  MSGFREES "        [rsa options]              - Oracle home root script automation options"
  MSGFREES "        [patch options]            - Oracle home installation patch options"
  MSGFREES "        [post install options]     - Oracle home post-installation options"
  MSGFREES
  MSGFREES "Basic options [basic options]"
  MSGFREES
  MSGFREES "        [-help|-h' [all]]"
  MSGFREES "                show this help"
  MSGFREES "        [-version|-V]"
  MSGFREES "                show version"
  MSGFREES "        [-verbose|-v]"
  MSGFREES "                enable verbose mode"
  MSGFREES "        [-query|-q]"
  MSGFREES "                enable test mode (do not install)"
  MSGFREES "        [-nolog]"
  MSGFREES "                enable nolog mode (disable logging)"
  MSGFREES "        [-log <path>]"
  MSGFREES "                location for log files ( Default: ${sap_log_dir} )"
  MSGFREES "        [-tmp <path>]"
  MSGFREES "                location for temporary files ( Default: ${tmp_dir_base} )"
  MSGFREES
  MSGFREES "Check Options [check options]"
  MSGFREES
  MSGFREES "        [-check_display]"
  MSGFREES "                check DISPLAY setting (xclock)"
  MSGFREES
  MSGFREES "Main Installation Options [main install options]"
  MSGFREES
  MSGFREES "        [-ohinstall]"
  MSGFREES "                ${dsc_ohi} (Default)"
  MSGFREES "        [-ohnoinstall]"
  MSGFREES "                ${dsc_ohn}"
  MSGFREES
  MSGFREES "Installation Step Options [install step options]"
  MSGFREES
  MSGFREES "        [-ohprepare]"
  MSGFREES "                ${dsc_ohp}"
  MSGFREES "        [-ohverify]"
  MSGFREES "                ${dsc_ohv}"
  MSGFREES "        [-ohextract [-xquiet|-xverbose|-xprogress][-sha256sum]"
  MSGFREES "                ${dsc_ohx}"
  MSGFREES "                [-xquiet   ]: quiet extraction mode"
  MSGFREES "                [-xverbose ]: verbose extraction mode"
  MSGFREES "                [-xprogress]: show extraction progress (Default)"
  MSGFREES "                [-sha256sum]: check SHA256 message digest"
 #MSGFREES "                [-xnew     ]: remove existing IHRDBMS before"
 #MSGFREES "                Extraction mode (Default: $opt_extract_mode_verbose)"
  MSGFREES "        [-ohcheck]"
  MSGFREES "                ${dsc_ohc}"
  MSGFREES "        [-ohregister]"
  MSGFREES "                ${dsc_ohr}"
  MSGFREES "        [-ohsapcfg]"
  MSGFREES "                ${dsc_ohs}"
  MSGFREES "        [-ohmopatch]"
  MSGFREES "                ${dsc_ohm}"
  MSGFREES
  MSGFREES "Advanced Installation Options [advanced install options]"
  MSGFREES
  MSGFREES "        [-silent|-s]"
  MSGFREES "                Run ${STR_OUI_NAME_0} in silent mode"
  MSGFREES "        [-ignorePrereqWarnings]"
  MSGFREES "                ignore warnings from prerequisite checks (runInstaller)"
  MSGFREES "        [-ignoreWarnings | -iW ]"
  MSGFREES "                ignore warnings from installation (RUNINSTALLER)"
  MSGFREES "        [-oracle_base  <path>]"
  MSGFREES "                Oracle base location, default <ORACLE_BASE>"
  MSGFREES "        [-oracle_image <path> | -oracle_stage <path>"
  MSGFREES "                Oracle home image file (full path)"
 ##############################################################################
 #MSGFREES "        [-oracle_stage_1 <path>"
 #MSGFREES "                Location of Oracle home image file (SAP default #1)"
 #MSGFREES "        [-oracle_stage_2 <path>"
 #MSGFREES "                Location of Oracle home image file (SAP default #2)"
 ##############################################################################
  MSGFREES "        [-install_home <path> | -ihrdbms <path>]"
  MSGFREES "                Installation Oracle home path <IHRDBMS>"
  MSGFREES "                Default: /oracle/<DB_SID>/${tgt_oh_dirname}"
  MSGFREES "        [-runtime_home <path> | -ohrdbms <path>]"
  MSGFREES "                Runtime Oracle home path <OHRDBMS>"
  MSGFREES "                Default: /oracle/<DB_SID>/<link name>"
  MSGFREES "        [-ohname <ohname>]"
  MSGFREES "                Name of Oracle Home in inventory"
  MSGFREES "                Default: system-generated by OUI"
  MSGFREES "        [-db <DB_SID> | -db_sid <DB_SID>] [-dbsid <DB_SID>]"
  MSGFREES "                Oracle Database Name, default <DB_SID>"
  MSGFREES "                Used for Installation Oracle home path <IHRDBMS>"
  MSGFREES "        [-no_db_sid]"
  MSGFREES "                No <DB_SID> specified, requires -ihrdbms <path> option"
  MSGFREES "        [-shared [-no_db_sid | -db_sid <DB_SID>] ]"
  MSGFREES "                install a shared Oracle home (for database <DB_SID>)"
  MSGFREES "                Default: /oracle/RDBMS/${ORACLE_RELEASE_KURZ}"
  MSGFREES "        [-no_empty_dir_check]"
  MSGFREES "                extract Oracle Home Gold Image into non-empty Oracle home"
  MSGFREES "        [-norsp]"
  MSGFREES "                installation without response file"
  MSGFREES "        [-creatersp] [-nocleanup]"
  MSGFREES "                create response file only"
 #MSGFREES "        [-invPtrLoc <path>]"
 #MSGFREES "                location of oraInst.loc ( Default: platform-dependent )"
  MSGFREES "        [-invLoc <path>]"
  MSGFREES "                location of Oracle inventory ( Default: /oracle/oraInventory )"
  MSGFREES "        [-link_name <name>]"
  #MSGFREES "                name of symbolic link for <OHRDBMS> ( Default: ${ORA_DB_VERS1}${ORA_DB_VERS2} )"
  MSGFREES "                name of symbolic link for <OHRDBMS> ( Default: ${ORA_DB_VERS1} )"
  MSGFREES "        [-link_type abs|rel]"
  MSGFREES "                absolute or relative path ( Default: relative, if possible )"
  MSGFREES
  MSGFREES "        [-osgroup_dba <name>]"
  MSGFREES "                OS group OSDBA (default $osgroup_dba) for Database Administrator"
  MSGFREES "        [-osgroup_oper <name>]"
  MSGFREES "                OS group OSOPER (default $osgroup_oper) for Database Operator"
  MSGFREES "        [-osgroup_backupdba <name>]"
  MSGFREES "                OS group OSBACKUPDBA (default $osgroup_backupdba) for Backup and Recovery"
  MSGFREES "        [-osgroup_dgdba <name>]"
  MSGFREES "                OS group OSDGDBA (default $osgroup_dgdba) for Data Guard Administrator"
  MSGFREES "        [-osgroup_kmdba <name>]"
  MSGFREES "                OS group OSKMDBA (default $osgroup_kmdba) for Key Management Administrator"
  MSGFREES "        [-osgroup_racdba <name>]"
  MSGFREES "                OS group OSRACDBA (default $osgroup_racdba) for RAC Administrator"
  MSGFREES
  MSGFREES "Root Script Automation Options [rsa options]"
 ##############################################################################
 #MSGFREES
 #MSGFREES "        [-rsa root|sudo|none]"
 #MSGFREES "                Specify Root Script Automation Method (Default: none)"
 #MSGFREES "        [-rsauser <username>]"
 #MSGFREES "                Root Script Automation - root username or sudo username"
 #MSGFREES "        [-rsapass <password>]"
 #MSGFREES "                Password for Root Script Automation"
 ##############################################################################
  MSGFREES
  MSGFREES "        [-rsasudouser <username>]"
  MSGFREES "                Root Script Automation - sudo username"
  MSGFREES "        [-rsasudopass <password>]"
  MSGFREES "                Root Script Automation - sudo password (not secure)"
  MSGFREES "        [-rsasudopath <path>]"
  MSGFREES "                Root Script Automation - sudo path (default: ${oui_rsa_sudoph})" #Root Script Automation - sudo path (optional)
  MSGFREES
  MSGFREES "        [-rsarootuser <username>]"
  MSGFREES "                Root Script Automation - root username (default: ${oui_rsa_rootun})"
  MSGFREES "        [-rsarootpass <password>]"
  MSGFREES "                Root Script Automation - root password (not secure)"
  MSGFREES
  MSGFREES "        [-rsa-verify-password"
  MSGFREES "                Root Script Automation - re-enter password for verification (default)"
  MSGFREES "        [-rsa-noverify-password"
  MSGFREES "                Root Script Automation - no password verification"
  MSGFREES "        [-rsa-no-password"
  MSGFREES "                Root Script Automation - no password (passwordless sudo configuration)"
  MSGFREES
  MSGFREES "Patch Options [patch options]"
  MSGFREES
  MSGFREES "        [-applyOneOffs <path>]"
  MSGFREES "                Apply one or more patches during the installation"
  MSGFREES "                Note: Multiple one-off patches can be passed as a comma separated list of locations."
  MSGFREES "                Note: The list of locations must not contain space characters."
  MSGFREES "        [-applyRU <path>]"
  MSGFREES "                Apply a Release Update (RU) during the installation"
  MSGFREES "                Note: <path> specifies the location of the RU to be applied."
  MSGFREES "        [-opatchLocation <path>]"
  MSGFREES "                Directory of another OPatch"
 #The following option is not yet implemented.
 ####################################################################
 #MSGFREES "        [-applySBP <path>]"
 #MSGFREES "                Apply an SAP Bundle Patch (SBP) during the installation"
 ####################################################################
  MSGFREES
  MSGFREES "Post Installation Options [post install options]"
  MSGFREES
  MSGFREES "        [-create_link yes|no]"
  MSGFREES "                create symbolic link ( Default: $sym_link_create_opt )"
  MSGFREES "        [-orabasetab yes|no]"
  MSGFREES "                configure orabasetab ( Default: $opt_orabasetab )"
  MSGFREES "        [-lsinventory yes|no]"
  MSGFREES "                check installed patches ( Default: $opt_opatch_chk )"
  if [ "$1" = "all" ]; then
    # ----------------------------------------------------------------------- #
    # Debug    options - do not use in production environments                #
    # ----------------------------------------------------------------------- #
    MSGFREES
    MSGFREES "Debug Options [debug options]"
    MSGFREES
    MSGFREES "        Only use when advised by Oracle Support."
    MSGFREES
    MSGFREES "        [-dbg]"
    MSGFREES "                enable debug mode"
    MSGFREES "        [-dbgo | -debug]"
    MSGFREES "                enable debug mode for ${STR_OUI_NAME_0}"
    MSGFREES "        [-dbgr]"
    MSGFREES "                enable debug mode for Oracle response file generation"
    MSGFREES "        [-dbgs]"
    MSGFREES "                enable debug mode for SAP RUNINSTALLER script"
    MSGFREES "        [-trc]"
    MSGFREES "                enable trace mode"
    MSGFREES "        [-nocleanup]"
    MSGFREES "                do not clean up response file and temporary files"
    MSGFREES "        [-ignoreInternalDriverError]"
    MSGFREES "                ignore OUI internal errors"
    MSGFREES "        [-nolink]"
    MSGFREES "                Run ${STR_OUI_NAME_0} in nolink mode (do not link executables)"
    MSGFREES
    # ----------------------------------------------------------------------- #
    # Internal options - do not use in production environments                #
    # ----------------------------------------------------------------------- #
    MSGFREES "Internal options [internal options]"
    MSGFREES
    MSGFREES "        Only use when advised by Oracle Support."
    MSGFREES
    MSGFREES "        [-caller <name>]"
    MSGFREES "                name of calling program"
    MSGFREES "        [-check_oui_rc] [-no_check_oui_rc]"
    MSGFREES "                check OUI exit code"
    MSGFREES "        [-lang en|de|fr]"
    MSGFREES "                OUI language (Default: English)"
    MSGFREES "        [-nowait]"
    MSGFREES "                run OUI without -waitForCompletion option"
  fi
  MSGFREES
  MSGFREES "Examples"
  MSGFREES
  MSGFREES "        ./${script_name} [-ohinstall] [-silent]"
  MSGFREES "                Install a new Oracle home"
  MSGFREES
  MSGFREES "For more information, see SAP Note $script_note."
  MSGFREES
}

# -----------------------------------------------------------------------------
# Show functions
# -----------------------------------------------------------------------------

show_arg_list_1() {
  #
  # NAME
  #   Show list of arguments in one line
  #
  # DESCRIPTION
  #
  #   Show list of arguments
  #
  MSGFREEV "Calling program / command with the following arguments:"
  MSGFREEV "$*"
}

show_arg_list_2() {
  #
  # NAME
  #   Show list of arguments
  #
  # DESCRIPTION
  #
  #   Show list of arguments in multiple lines
  #
  MSGFREEV "Calling program / command with the following arguments:"
  for arg in "$@"
  do
    MSGFREEV $arg
  done
}

# -----------------------------------------------------------------------------
# Installation Session Start and Cleanup
# -----------------------------------------------------------------------------

inst_session_start() {
  MSGFREEV "Install session start: preparation"
  # create temp directory
  MSGFREEV "Creating temporary directory $tmp_dir_full"
  mkdir -p $tmp_dir_full
  rc_os_cmd=$?; [ ${rc_os_cmd} -ne 0 ] && MSGWARNS "Creating temporary directory $tmp_dir_full failed (rc=$rc_os_cmd)."
  MSGFREEV "Install session start: preparation completed."
}

inst_session_cleanup() {
# #############################################################################
# Performing clean up tasks
# #############################################################################
if [ "${opt_cleanup_tmp}" = "${STR_YES}" ]; then
  MSGFREEV "Install session cleanup: start"
	if [ -n "${tmp_dir_full}" ]; then
  	if [ -d "${tmp_dir_full}" ]; then
      rm -rf ${tmp_dir_full}
      rc_os_cmd=$?; [ ${rc_os_cmd} -ne 0 ] && MSGERRRS "Removing temporary directory ${tmp_dir_full} failed (rc=${rc_os_cmd})."
    fi
  fi

  if [ -n "${oui_log_file}" ]; then 
    if [ -f "${oui_log_file}" ]; then
      rm ${oui_log_file}
      rc_os_cmd=$?; [ ${rc_os_cmd} -ne 0 ] && MSGERRRS "Removing temporary output log file ${oui_log_file} failed (rc=${rc_os_cmd})."
    fi
  fi

  if [ -n "${rspf_file}" ]; then 
    if [ -f "${rspf_file}" ]; then
      rm ${rspf_file}
      rc_os_cmd=$?; [ ${rc_os_cmd} -ne 0 ] && MSGERRRS "Removing temporary response file ${rspf_file} failed (rc=${rc_os_cmd})."
    fi
  fi
  MSGFREEV "Install session cleanup: completed."
else
  MSGFREEV "Install session cleanup: skipped."
fi
}


###############################################################################
#                                                                             #
#                                                                             #
#                                                                             #
#                         DEFINITION OF MAIN - START HERE                     #
#                                                                             #
#                                                                             #
#                                                                             #
###############################################################################

#clear # Clear the output screen

###############################################################################
#                                                                             #
#                                                                             #
#                                                                             #
#                         CHECKING COMMAND LINE ARGUMENTS                     #
#                                                                             #
#                                                                             #
#                                                                             #
###############################################################################
args_checked="${STR_FALSE}"
# echo_std "Checking command line arguments ..."
while [ $# -ge 1 ]; do
  # print out current argument
  #echo_std $# $1
  cmdl_arg=$1
  cur_arg=$1
  case $1 in
    ### Next arg ###
    -ohinstall )
     # Design decision: do not perform an extra prerequisite check before you perform installation
      opt_ohi=${STR_YES} && opt_ohn=${STR_NO}  && opt_ohp=${STR_YES} && opt_ohv=${STR_YES} && opt_ohx=${STR_YES} && opt_ohc=${STR_NO}  && opt_ohr=${STR_YES} && opt_ohs=${STR_YES} # && opt_ohm=${STR_YES}
      ;;
    ### Next arg ###
    -ohnoinstall )
     # Design decision: do only tasks that do not change the configuration in any way
      opt_ohi=${STR_NO}  && opt_ohn=${STR_YES} && opt_ohp=${STR_YES} && opt_ohv=${STR_YES} && opt_ohx=${STR_NO}  && opt_ohc=${STR_YES} && opt_ohr=${STR_NO}  && opt_ohs=${STR_NO}  && opt_ohm=${STR_NO}
      ;;
    ### Next arg ###
    -ohprepare )
      opt_ohi=${STR_NO}  && opt_ohn=${STR_NO}  && opt_ohp=${STR_YES}
      ;;
    ### Next arg ###
    -ohverify )
      opt_ohi=${STR_NO}  && opt_ohn=${STR_NO}  && opt_ohp=${STR_YES} && opt_ohv=${STR_YES}
      ;;
    ### Next arg ###
    -ohextract )
      opt_ohi=${STR_NO}  && opt_ohn=${STR_NO}  && opt_ohp=${STR_YES} && opt_ohv=${STR_YES} && opt_ohx=${STR_YES}
      ;;
    ### Next arg ###
    -ohcheck )
      opt_ohi=${STR_NO}  && opt_ohn=${STR_NO}  && opt_ohp=${STR_YES} && opt_ohv=${STR_YES} && opt_ohc=${STR_YES}
      ;;
    ### Next arg ###
    -ohregister )
      opt_ohi=${STR_NO}  && opt_ohn=${STR_NO}  && opt_ohp=${STR_YES} && opt_ohv=${STR_YES} && opt_ohr=${STR_YES}
      ;;
    ### Next arg ###
    -ohsapcfg )
      opt_ohi=${STR_NO}  && opt_ohn=${STR_NO}  && opt_ohp=${STR_YES} && opt_ohv=${STR_YES} && opt_ohs=${STR_YES}
      ;;
    ### Next arg ###
    -ohmopatch ) # This option is not implemented.
      opt_ohi=${STR_NO}  && opt_ohn=${STR_NO}  && opt_ohp=${STR_YES} && opt_ohv=${STR_YES} && opt_ohm=${STR_YES}
      MSGINFOS "-ohmopatch: This option is not implemented in ${STR_SRI_NAME}."
      MSGINFOS "Use MOPatch to install an up-to-date SAP Bundle Patch."
      install_exit $RC_WARN
      ;;
    ### Next arg ###
    -xquiet | -xverbose | -xprogress)
      opt_extract_mode_verbose=$1
      [ $opt_extract_mode_verbose = "-xquiet"    ] && OS_UNZIP_OPT="-q"
      [ $opt_extract_mode_verbose = "-xverbose"  ] && OS_UNZIP_OPT=""
      [ $opt_extract_mode_verbose = "-xprogress" ] && OS_UNZIP_OPT=""
      ;;
    ### Next arg ###
    -xnew)
      opt_extract_mode_new=$1
      MSGWARNS "$1: This option is only for testing."
      ;;
    ### Next arg ###
    -caller) # name of calling program
      shift
      if [ $# -ge 1 ]; then
        script_caller="$1"
      else
        MSGERRRS "Missing argument for '-caller' option."
        install_exit $RC_INVARG_ERROR
      fi
      ;;
    ### Next arg ###
    -v | -verbose) # Run in verbose mode
      verbose_mode="${STR_ENABLED}" && echo_std "Verbose mode enabled"
      ;;
    ### Next arg ###
    -trc) # trace level
      trace_mode="${STR_ENABLED}" && echo_std "Trace mode enabled"
      ;;
    ### Next arg ###
    -dbg) # debug mode 
      flag_debug_mode_sap="yes"     && echo_std "Debug mode enabled for SAP RUNINSTALLER script" &&  set -x
      flag_debug_mode_oui="-debug"  && echo_std "Debug mode enabled for ${STR_OUI_NAME_0}"
      flag_debug_mode_rsp="yes"     && echo_std "Debug mode enabled for Oracle response file"
      ;;
    ### Next arg ###
    -dbgs) # debug mode for script
      flag_debug_mode_sap="yes"     && echo_std "Debug mode enabled for SAP RUNINSTALLER script" &&  set -x
      ;;
    ### Next arg ###
    -dbgo | -debug) # debug mode for OUI - can be used if OUI is not starting. MOS 885643.1
      flag_debug_mode_oui="-debug"  && echo_std "Debug mode enabled for ${STR_OUI_NAME_0}"
      ;;
    ### Next arg ###
    -dbgr) # debug mode for response file
      flag_debug_mode_rsp="yes"     && echo_std "Debug mode enabled for Oracle response file"
      ;;
    ### Next arg ###
    -query | -q) # do not start installer, but show command (test mode)
      query_mode="${STR_ENABLED}"
      ;;
    ### Next arg ###
    -nowait) # disable OUI option "-waitForCompletion"
      #oui_wait_option="-waitForCompletion"
      oui_wait_option=""
      ;;
    ### Next arg ###
    -displaytest | -check_display) # test display setting
      echo_std "Testing display setting"
      echo_std "DISPLAY=$DISPLAY"
      echo_std "Trying to start xclock ..."
      ${OS_XCLOCK}
      rc_cmd=$?
      echo_std "xclock finished with return code=$rc_cmd."
      install_exit_succ
      ;;
    ### Next arg ###
    -help | -h | --h) # Usage help
      show_usage "$2"
      install_exit_succ
      ;;
    ### Next arg ###
    -version|-V) # Version info
      #[ -n "${script_caller}" ] && script_name=${script_caller}
      echo_std
      echo_std "${script_caller:-${script_name}} ${script_vers} (${script_plvl}) ${script_date} ${script_stat}"
      echo_std
      echo_std "Script name      ${script_name:-${STR_NOT_SET}}"
      echo_std "Script version   ${script_plvl:-${STR_NOT_SET}}"
      echo_std "Script date      ${script_date:-${STR_NOT_SET}}"
      echo_std "Script status    ${script_stat:-${STR_NOT_SET}}"
      echo_std "Oracle version   ${script_vers:-${STR_NOT_SET}}"
      echo_std
      echo_std "SAP note         ${script_note:-${STR_NOT_SET}}"
      echo_std
      install_exit_succ
      ;;
    ### Next arg ###
    -nosilent) # interactive mode
      silent_mode=""
      silent_mode_progress=""
      ;;
    ### Next arg ###
    -s |-silent) # silent mode
      silent_mode="-silent"
      ;;
    ### Next arg ###
    -rsa) # root script automation
      #oracle.install.db.rootconfig.executeRootScript
      #oracle.install.db.rootconfig.configMethod
      shift
      if [ $# -ge 1 ]; then
      	case $1 in
          root | ROOT) 
            oui_rsa_option="true"
            oui_rsa_method="ROOT"
            ;;
          sudo | SUDO)
            oui_rsa_option="true"
            oui_rsa_method="SUDO"
            ;;
          none | NONE)
            oui_rsa_option="false"
            ;;
          *) # Invalid option
            MSGERRRS "Invalid option for '${cur_arg}' option: $1"
            install_exit $RC_INVARG_ERROR
            ;;
        esac
      else
        MSGERRRS "Missing argument for '${cur_arg}' option."
        install_exit $RC_INVARG_ERROR
      fi
      ;;
    ### Next arg ###
    -rsauser) # root script automation
      #oracle.install.db.rootconfig.rootUserName
      #oracle.install.db.rootconfig.sudoUserName
      shift
      if [ $# -ge 1 ]; then
      	case $oui_rsa_method in
          ROOT) 
            oui_rsa_rootun="$1"
            ;;
          SUDO)
            oui_rsa_sudoun="$1"
            ;;
          *) # Invalid option
            MSGERRRS "Invalid root script automation method ${oui_rsa_method}. Cannot assign user name."
            install_exit $RC_INVARG_ERROR
            ;;
        esac
      else
        MSGERRRS "Missing argument for '${cur_arg}' option."
        install_exit $RC_INVARG_ERROR
      fi
      ;;
    ### Next arg ###
    -rsapass) # root script automation password
      shift
      if [ $# -ge 1 ]; then
      	case $oui_rsa_method in
          ROOT) 
            oui_rsa_rootpw="$1"
            ;;
          SUDO)
            oui_rsa_sudopw="$1"
            ;;
          *) # Invalid option
            echo_std "Invalid root script automation method ${oui_rsa_method}. Cannot assign password."
            install_exit $RC_INVARG_ERROR
            ;;
        esac
      else
        MSGERRRS "Missing argument for '${cur_arg}' option."
        install_exit $RC_INVARG_ERROR
      fi
      ;;
    ### Next arg ###
    -rsarootuser) # root script automation
      #oracle.install.db.rootconfig.rootUserName
      shift
      if [ $# -ge 1 ]; then
        oui_rsa_option="true"
        oui_rsa_method="ROOT"
        oui_rsa_rootun="$1"
      else
        MSGERRRS "Missing argument for '${cur_arg}' option."
        install_exit $RC_INVARG_ERROR
      fi
      ;;
    ### Next arg ###
    -rsarootpass) # root script automation password for root
      shift
      if [ $# -ge 1 ]; then
        oui_rsa_rootpw="$1"
      else
        MSGERRRS "Missing argument for '${cur_arg}' option."
        install_exit $RC_INVARG_ERROR
      fi
      ;;
    ### Next arg ###
    -rsasudouser) # root script automation
      #oracle.install.db.rootconfig.sudoUserName
      shift
      if [ $# -ge 1 ]; then
        oui_rsa_option="true"
        oui_rsa_method="SUDO"
        oui_rsa_sudoun="$1"
      else
        MSGERRRS "Missing argument for '${cur_arg}' option."
        install_exit $RC_INVARG_ERROR
      fi
      ;;
    ### Next arg ###
    -rsasudopass) # root script automation password for sudo
      shift
      if [ $# -ge 1 ]; then
        oui_rsa_sudopw="$1"
      else
        MSGERRRS "Missing argument for '${cur_arg}' option."
        install_exit $RC_INVARG_ERROR
      fi
      ;;
    ### Next arg ###
    -rsasudopath ) # root script automation sudo path
      #oracle.install.db.rootconfig.sudoPath
      shift
      if [ $# -ge 1 ]; then
        oui_rsa_sudoph="$1"
      else
        MSGERRRS "Missing argument for '${cur_arg}' option."
        install_exit $RC_INVARG_ERROR
      fi
      ;;
    ### Next arg ###
    -rsa-verify-password ) # root script automation
      oui_rsa_option_verify="true"
      oui_rsa_option_noverify="false"
      ;;
    -rsa-noverify-password ) # root script automation
      oui_rsa_option_noverify="true"
      oui_rsa_option_verify="false"
      ;;
    -rsa-no-password ) # root script automation
      oui_rsa_option_nopassword="true"
      ;;
    ### Next arg ###
    -nolink) # nolink mode
      oui_nolink_mode="-nolink"
      ;;
    ### Next arg ###
      # English   "-J-Duser.country=US -J-Duser.language=en"
      # French    "-J-Duser.country=FR -J-Duser.language=fr"
      # German    "-J-Duser.country=DE -J-Duser.language=de"
    -en) # installer language
      oui_lang_option="-J-Duser.country=US -J-Duser.language=en"
      ;;
    -de) # installer language
      oui_lang_option="-J-Duser.country=DE -J-Duser.language=de"
      ;;
    -fr) # installer language
      oui_lang_option="-J-Duser.country=FR -J-Duser.language=fr"
      ;;
    ### Next arg ###
    -lang | -language) # OUI language (default is English)
      shift
      if [ $# -ge 1 ]; then
      	case $1 in
          en) 
            oui_lang_option="-J-Duser.country=US -J-Duser.language=en"
            ;;
          de)
            oui_lang_option="-J-Duser.country=DE -J-Duser.language=de"
            ;;
          fr)
            oui_lang_option="-J-Duser.country=FR -J-Duser.language=fr"
            ;;
          *) # Invalid language
            echo_std "Invalid language: $1"
            install_exit $RC_INVARG_ERROR
            ;;
        esac
      else
        MSGERRRS "Missing argument for '-lang' option."
        install_exit $RC_INVARG_ERROR
      fi
      ;;
    ### Next arg ###
    -check) # product specific prerequisite checks (oui_executePrereqs="-executePrereqs")
      #oui_executePrereqs="-executePrereqs"
      MSGINFOS "This option is desupported. Use option -ohcheck."
      MSGINFOS "For more information, run $STR_SRI_NAME with '-help'."
      install_exit $RC_INVARG_ERROR
      ;;
    ### Next arg ###
    -osgroup_dba) # group
      shift
      if [ $# -ge 1 ]; then
        osgroup_dba="$1"
      else
        MSGERRRS "Missing argument for '-osgroup_dba' option."
        install_exit $RC_INVARG_ERROR
      fi
      ;;
    ### Next arg ###
    -osgroup_oper) # group
      shift
      if [ $# -ge 1 ]; then
        osgroup_oper="$1"
      else
        MSGERRRS "Missing argument for '-osgroup_oper' option."
        install_exit $RC_INVARG_ERROR
      fi
      ;;
    ### Next arg ###
    -osgroup_backupdba) # group
      shift
      if [ $# -ge 1 ]; then
        osgroup_backupdba="$1"
      else
        MSGERRRS "Missing argument for '-osgroup_backupdba' option."
        install_exit $RC_INVARG_ERROR
      fi
      ;;
    ### Next arg ###
    -osgroup_dgdba) # group
      shift
      if [ $# -ge 1 ]; then
        osgroup_dgdba="$1"
      else
        MSGERRRS "Missing argument for '-osgroup_dgdba' option."
        install_exit $RC_INVARG_ERROR
      fi
      ;;
    ### Next arg ###
    -osgroup_kmdba) # group
      shift
      if [ $# -ge 1 ]; then
        osgroup_kmdba="$1"
      else
        MSGERRRS "Missing argument for '-osgroup_kmdba' option."
        install_exit $RC_INVARG_ERROR
      fi
      ;;
    ### Next arg ###
    -osgroup_racdba) # group
      shift
      if [ $# -ge 1 ]; then
        osgroup_racdba="$1"
      else
        MSGERRRS "Missing argument for '-osgroup_racdba' option."
        install_exit $RC_INVARG_ERROR
      fi
      ;;
    ### Next arg ###
    -oracle_stage | -oracle_image | -ohgoldimage ) # Oracle Home Gold Image
      shift
      if [ $# -ge 1 ]; then
        ORA_SHA256SUM=""             # OH gold image file checksum is not known for custom images
        ORA_GOLD_IMAGE_FILE_L=""     # OH gold image file name is not known for custom images
        ora_stage_search="${STR_NO}" # Do not search, use given path

        ora_image_file_path="$1"          # Oracle home gold image: full path
        ora_image_file_diry=`dirname $1`  # Oracle home gold image: directory
        ora_image_file_name=`basename $1` # Oracle home gold image: file name
        ora_image_file_cust="${STR_YES}"  # custom image file
        ora_stage_loc_0=""                # not used
      else
        MSGERRRS "Missing argument for '${cur_arg}' option."
        install_exit $RC_INVARG_ERROR
      fi
      ;;
    ### Next arg ###
    -oracle_stage_1) # Oracle stage directory
      shift
      if [ $# -ge 1 ]; then
        ora_stage_loc_1="$1"
      else
        echo_std "Missing location for '-oracle_stage_1' option."
        install_exit $RC_INVARG_ERROR
      fi
      ;;
    ### Next arg ###
    -oracle_stage_2) # Oracle stage directory
      shift
      if [ $# -ge 1 ]; then
        ora_stage_loc_2="$1"
      else
        echo_std "Missing location for '-oracle_stage_2' option."
        install_exit $RC_INVARG_ERROR
      fi
      ;;
    ### Next arg ###
    -oracle_base) # Oracle base location
      oracle_base_opt="$1"
      shift
      if [ $# -ge 1 ]; then
        tgt_ob_loc="$1"
      else
        echo_std "Missing location for '-oracle_base' option."
        install_exit $RC_INVARG_ERROR
      fi
      if PathIsRel "${tgt_ob_loc}"; then
        MSGERRRS "-oracle_base <path>: <path> is not absolute."
        install_exit $RC_INVARG_ERROR
      fi
      ;;
    ### Next arg ###
    -oracle_home) # Oracle home location
     echo_std "'-oracle_home' option is not supported any more. Use '-install_home' option instead."
     install_exit $RC_INVARG_ERROR
      ;;
    ### Next arg ###
    -oracle_home_name | -ohname) # Oracle home name
      shift
      if [ $# -ge 1 ]; then
        ORACLE_HOME_NAME="$1"
        ORACLE_HOME_NAME_VAR="ORACLE_HOME_NAME=${ORACLE_HOME_NAME}"
       # Example: ORACLE_HOME_NAME="MY_ORA_121_HOME" (OUI 11.2)
       #          ORACLE_HOME_NAME=MY_ORA_121_HOME   (OUI 12.1)
       #ORACLE_HOME_NAME_VAR="ORACLE_HOME_NAME=\"${ORACLE_HOME_NAME}\"" # this worked with OUI 11.2
       #ORACLE_HOME_NAME_VAR="session:ORACLE_HOME_NAME=\"${ORACLE_HOME_NAME}\""
      else
        echo_std "Missing argument for '-oracle_home_name' option."
        install_exit $RC_INVARG_ERROR
      fi
      ;;
    ### Next arg ###
    -install_home | -ihrdbms) # Oracle home installation location
      shift
      if [ $# -ge 1 ]; then
        tgt_oh_loc="$1"
        tgt_oh_dirname=`basename ${tgt_oh_loc}`
        if [ `dirname ${tgt_oh_loc}` = "/oracle/RDBMS" ]; then
        	tgt_oh_loc_isshared="yes"
        fi
      	opt_dbsid_mandatory="no"
        #sym_link_path="absolute"
      else
        echo_std "Missing location for '-install_home' option."
        install_exit $RC_INVARG_ERROR
      fi
      if PathIsRel "${tgt_oh_loc}"; then
        MSGERRRS "-install_home <path> / -ihrdbms <path>: <path> is not absolute."
        install_exit $RC_INVARG_ERROR
      fi
      ;;
    ### Next arg ###
    -shared) # Shared Oracle home installation
      if is_engineered_system; then
  	    # Oracle Engineered System
       #tgt_oh_loc="/u01/app/oracle/product/${ORA_DB_VERS1}.${ORA_DB_VERS2}.${ORA_DB_VERS3}.${ORA_DB_VERS4}/dbhome_1"
        :
      else
        # Non-Engineered Custom System
        tgt_oh_loc="/oracle/RDBMS/${ORACLE_RELEASE_KURZ}"
        # ORACLE_BASE=/oracle/RDBMS
        tgt_oh_dirname=`basename ${tgt_oh_loc}`
      fi
      tgt_oh_loc_isshared="yes"
      ;;
    ### Next arg ###
    -runtime_home | -ohrdbms) # Oracle home runtime location
      shift
      if [ $# -ge 1 ]; then
        tgt_oh_link="$1"
        tgt_oh_linkloc=`dirname ${tgt_oh_link}`
        tgt_oh_linkname=`basename ${tgt_oh_link}`
        #sym_link_path="absolute"
      else
        echo_std "Missing location for '-runtime_home' option."
        install_exit $RC_INVARG_ERROR
      fi
      if PathIsRel "${tgt_oh_link}"; then
        MSGERRRS "-runtime_home <path> / -ohrdbms <path>: <path> is not absolute."
        install_exit $RC_INVARG_ERROR
      fi
      ;;
    ### Next arg ###
    -no_empty_dir_check) # allow install into non-empty Oracle Home
      flag_empty_dir_check="no"
      ;;
    ### Next arg ###
    -norsp) # run without response file
      oui_rsp_use="no"
      oui_rsp_opt=""
      oui_rsp_file=""
      ;;
    ### Next arg ###
    -creatersp) # create response file
      oui_rsp_create="yes"
      ;;
###    ### Next arg ###
###    -no_db_sid) # no DB_SID set in environment
###      # This option is only supported for shared OH installations!
###      # DB_SID is not mandatory if this option is used.
###      # This option allows to install a shared Oracle home at an earlier time
###      # and assign the database and the runtime home later
###      if SharedOhInstall; then
###      	opt_dbsid_mandatory="no"
###        MSGINFOV "Performing installation without env. var. DB_SID set in the environment."
###      else
###        echo_std "'-no_db_sid' option is only allowed with '-shared' option."
###        install_exit $RC_INVARG_ERROR
###      fi
###      ;;
###    ### Next arg ###
###    -db_sid) # Database name
###      # This option is only supported for shared OH installations!
###      # This option allows the fast configuration of multiple runtime Oracle homes
###      # without changing DB_SID in the environment.
###      if SharedOhInstall; then
###        shift
###        if [ $# -ge 1 ]; then
###          tgt_db_sid="$1"
###          # convert from lower to upper case
###          # tr '[a-z]'     '[A-Z]'
###          # tr '[:lower:]' '[:upper:]'
###          tgt_db_sid=`echo $tgt_db_sid | tr '[:lower:]' '[:upper:]'`
###          DB_SID=$tgt_db_sid
###          opt_dbsid_mandatory="no"
###        else
###          MSGERRRS "Missing argument for '-db_sid' option."
###          install_exit $RC_INVARG_ERROR
###        fi
###      else
###        echo_std "'-db_sid' option is only allowed with '-shared' option."
###        install_exit $RC_INVARG_ERROR
###      fi
###      ;;
    ### Next arg ###
    -no_db_sid) # no DB_SID set in environment
      # Option to install without DB_SID in the environment
      # This option can be used for the following scenarios:
      # 1) install a shared Oracle home
      # 2) install with -ihrdbms option
    	opt_dbsid_mandatory="no"
      ;;
    ### Next arg ###
    -db | -db_sid | -dbsid) # Database name <DB_SID>
      # Option to provide DB_SID on the command line instead by setting an env. var.
      # For shared Oracle homes you can use this option to configure 
      # multiple runtime Oracle homes without changing DB_SID in the environment.
      shift
      if [ $# -ge 1 ]; then
        tgt_db_sid="$1"
        # convert from lower to upper case
        tgt_db_sid=`echo $tgt_db_sid | tr '[:lower:]' '[:upper:]'`
        DB_SID=$tgt_db_sid
      	opt_dbsid_mandatory="no"
      else
        MSGERRRS "Missing argument for '$cmdl_arg' option."
        install_exit $RC_INVARG_ERROR
      fi
      ;;
    ### Next arg ###
    -link_create | -create_link) # Create symbolic link (yes or no)
      shift
      if [ $# -ge 1 ]; then
      	case $1 in
          yes|YES)
            sym_link_create_opt="yes"
            ;;
          no|NO)
            sym_link_create_opt="no"
            ;;
          *) # Invalid argument
            echo_std "Invalid argument for '-link_create' option."
            install_exit $RC_INVARG_ERROR
            ;;
        esac
      else
        MSGERRRS "Missing argument for '-link_create' option."
        install_exit $RC_INVARG_ERROR
      fi
      ;;
    ### Next arg ###
    -link_name) # Link name
      shift
      if [ $# -ge 1 ]; then
        tgt_oh_linkname="$1"
      else
        MSGERRRS "Missing argument for '-link_name' option."
        install_exit $RC_INVARG_ERROR
      fi
      ;;
    ### Next arg ###
    -link_type) # Link type: absolute or relative path
      shift
      if [ $# -ge 1 ]; then
      	case $1 in
          abs|absolute)
            sym_link_path="absolute"
            ;;
          rel|relative)
            sym_link_path="relative"
            ;;
          *) # Invalid argument
            echo_std "Invalid argument for '-link_type' option."
            install_exit $RC_INVARG_ERROR
            ;;
        esac
      else
        MSGERRRS "Missing argument for '-link_type' option."
        install_exit $RC_INVARG_ERROR
      fi
      ;;
    ### Next arg ###
    -nocleanup) # disable clean up of tmp directory and temporary files
      opt_cleanup_tmp="${STR_NO}"
      ;;
    ### Next arg ###
    -check_oui_rc) # check exit code of OUI
      # With this option you can check the return code of OUI.
      # A consequence of using this option is that the OUI standard output
      # can not be captured and written to the log file of this script.
      # Using this option means that the standard output is not tee'd 
      # (-tee is not used)
      tee_opt=""
      tee_pipe=""
      tee_cmd=""
      ;;
    ### Next arg ###
    -no_check_oui_rc) # do not check exit code of OUI
      tee_opt="-tee"
      tee_pipe="|"
      tee_cmd=" tee "
      ;;
    ### Next arg ###
    -tmp) # tmp directory
      tmp_dir_opt="$1"
      shift
      if [ $# -ge 1 ]; then
      	tmp_dir_base="$1"
        tmp_dir_full="${tmp_dir_base}/${tmp_dir_name}"
        tmp_dir_errfile="${tmp_dir_full}/sap_runinstaller.err"     # unzip error log file
        MSGINFOV "Changed temporary directory: tmp_dir_full   : $tmp_dir_full"
        MSGINFOV "Changed temporary directory: tmp_dir_errfile: $tmp_dir_errfile"
      else
        echo_std "Missing location for '-tmp' option."
        install_exit $RC_INVARG_ERROR
      fi
      ;;
    ### Next arg ###
    -applyRU) # -applyRU option
      opt_applyRU_strg="$1"
      opt_applyRU_flag="${STR_YES}"
      shift
      if [ $# -ge 1 ]; then
        opt_applyRU_path="$1"
        if [ -n "$opt_applyRU_path" ] && [ -d "$opt_applyRU_path" ]; then 
          MSGINFOV "Path to Release Update: $opt_applyRU_path"
        else
          MSGERRRS "$opt_applyRU_strg: path is invalid."
          install_exit $RC_INVARG_ERROR
        fi
      else
        MSGERRRS "Missing location for '-applyRU' option."
        install_exit $RC_INVARG_ERROR
      fi
      ;;
    ### Next arg ###
    -applyOneOffs) # -applyOneOffs option
      opt_applyOO_strg="$1"
      opt_applyOO_flag="${STR_YES}"
      shift
      if [ $# -ge 1 ]; then
        opt_applyOO_path="$1"
        MSGINFOV "Path to OneOffs       : $opt_applyOO_path"
      else
        MSGERRRS "Missing location for '-applyOneOffs' option."
        install_exit $RC_INVARG_ERROR
      fi
      ;;
    ### Next arg ###
    -nolog) # do not log into a log file
      logging_enabled="${STR_FALSE}"
      ;;
    ### Next arg ###
    -opatchLocation) # -opatchLocation option
      opt_opatchloc_strg="$1"
      opt_opatchloc_flag="${STR_YES}"
      opt_opatch_s_o_v_c_strg="-skipOpatchVersionCheck"
      shift
      if [ $# -ge 1 ]; then
        opt_opatchloc_path="$1"
        if [ -n "$opt_opatchloc_path" ] && [ -d "$opt_opatchloc_path" ]; then 
          MSGINFOV "Path to OPatch: $opt_opatchloc_path"
        else
          MSGERRRS "$opt_opatchloc_strg: path is invalid."
          install_exit $RC_INVARG_ERROR
        fi
      else
        MSGERRRS "Missing location for '-opatchLocation' option."
        install_exit $RC_INVARG_ERROR
      fi
      ;;
    ### Next arg ###
    -log) # base directory for log and response file
      shift
      if [ $# -ge 1 ]; then
        install_base_dir="$1"
        sap_log_dir="${install_base_dir}"
        sap_log_file_single="${sap_log_dir}/${sap_log_name_single}"
        rspf_dir="${install_base_dir}"
        rspf_file="${rspf_dir}/${rspf_name}"
        oui_log_dir="${install_base_dir}"
        oui_log_file="${oui_log_dir}/${oui_log_name}"
      else
        echo_std "Missing location for '-log' option."
        install_exit $RC_INVARG_ERROR
      fi
      ;;
    ### Next arg ###
    -invLoc) # inventory location
      shift
      if [ $# -ge 1 ]; then
        invloc_path="$1"
      else
        MSGERRRS "Missing argument for '-invLoc' option."
        install_exit $RC_INVARG_ERROR
      fi
      ;;
    ### Next arg ###
    # Incident 337874 / 2020: '-invPtrLoc' option is not supported any more by 19c 'runInstaller'
    # -invPtrLoc) # oraInst.loc
    #   shift
    #   if [ $# -ge 1 ]; then
    #     oui_invptrloc_option="-invPtrLoc $1"
    #     oui_invptr_file="$1"
    #   else
    #     MSGERRRS "Missing argument for '-invPtrLoc' option."
    #     install_exit $RC_INVARG_ERROR
    #   fi
    #   ;;
    ### Next arg ###
    -lsinventory)    # verify installation with opatch lsinventory / opatch version
      shift
      if [ $# -ge 1 ]; then
      	case $1 in
          no | NO) 
            opt_opatch_chk="no"
            ;;
          yes | YES) 
            opt_opatch_chk="yes"
            ;;
          *) # Invalid argument
            echo_std "Invalid argument for '-lsinventory' option."
            install_exit $RC_INVARG_ERROR
            ;;
        esac
      else
        MSGERRRS "Missing argument for '-lsinventory' option."
        install_exit $RC_INVARG_ERROR
      fi
      ;;
    ### Next arg ###
    -orabasetab)    # configure orabasetab entry for OHRDBMS
      shift
      if [ $# -ge 1 ]; then
      	case $1 in
          no | NO) 
            opt_orabasetab="no"
            ;;
          yes | YES) 
            opt_orabasetab="yes"
            ;;
          *) # Invalid argument
            echo_std "Invalid argument for '-orabasetab' option."
            install_exit $RC_INVARG_ERROR
            ;;
        esac
      else
        MSGERRRS "Missing argument for '-orabasetab' option."
        install_exit $RC_INVARG_ERROR
      fi
      ;;
    ### Next arg ###
    -ignoreInternalDriverError)
      ignoreInternalDriverError="$1"
      #echo_std "Ignoring internal driver errors ..."
      ;;
    ### Next arg ###
    -ignorePrereqWarnings) # ignore all prerequisite checks failures [-ignorePrereqFailure] [-ignorePrereq]
      oui_ignorePrereq_wrn="${STR_TRUE}"
     #oui_ignorePrereq_1="-ignorePrereq"  # if you use both arguments, you get [INS-04010] Repetition of command line argument is not supported: -ignorePrereqFailure
      oui_ignorePrereq_2="-ignorePrereqFailure"
      ;;
    ### Next arg ###
    -ignoreWarnings | -iW) # ignore all warnings (in case of warnings return success (0) instead of (1))
      nowarn_mode="${STR_ENABLED}" # this is not an option of Oracle installer, this is an SAP RUNINSTALLER option (needed for internal validation tests)
      MSGINFOV "Nowarning mode enabled"
      ;;
    ### Next arg ###
    -sha256sum) # compute check sum
      ora_chksum_check="${STR_YES}"
      ;;
    ### Next arg ###
    *) # Invalid option
      MSGERRRS "Invalid option: $1"
      #show_usage
      install_exit $RC_INVARG_ERROR
      ;;
  esac
  # go to next argument
  shift
done
###############################################################################
#                                                                             #
#                                                                             #
#                                                                             #
#                         COMMAND LINE ARGUMENTS CHECKED                      #
#                                                                             #
#                                                                             #
#                                                                             #
###############################################################################
args_checked="${STR_TRUE}"

###############################################################################
#                                                                             #
#                                                                             #
#                                                                             #
#                         CHECKING ENVIRONMENT VARIABLES (PART I)             #
#                                                                             #
#                                                                             #
#                                                                             #
###############################################################################
env_checked="${STR_FALSE}"

# #########################################################
# Check ORACLE_STAGE
# #########################################################
# AB: check removed 2018-09-10
#if [ -z "${ORACLE_STAGE}" ] && [ -z "${ora_stage_loc_0}" ]; then
#  MSGERRRS "Oracle stage is not specified."
#  echo_std "${MSG_INFO}" "Set ORACLE_STAGE in the environment or use -oracle_stage option."
#  RC_RETCODE=$RC_PREREQ_ERROR
#  install_exit $RC_PREREQ_ERROR
#fi

# #########################################################
# Check DB_SID
# #########################################################
if [ -z "${DB_SID}" ] && [ -z "${tgt_db_sid}" ]; then
 	if db_sid_is_mandatory; then
    MSGERRRS "<DB_SID> is not specified."
    echo_std "${MSG_INFO}" "Set DB_SID in the environment."
    install_exit $RC_PREREQ_ERROR
  else
    MSGINFOS "<DB_SID> is not specified and '-no_db_sid option' is used. Trying to continue without <DB_SID>."
  fi
fi
 
# #########################################################
# Specify Default value for ORACLE_BASE
# #########################################################
if [ -d "/u01/app/oracle" ]; then
 	# Oracle Engineered System
  ORACLE_BASE_DEF_OES="/u01/app/oracle"
  ORACLE_BASE_DEF=$ORACLE_BASE_DEF_OES
else
  # Non-Engineered Custom System
  ORACLE_BASE_DEF_SAP="/oracle/${DB_SID}"
  if SharedOhInstall; then
    ORACLE_BASE_DEF_SAP="/oracle/RDBMS"
  fi
  ORACLE_BASE_DEF=$ORACLE_BASE_DEF_SAP
fi

# #########################################################
# Check ORACLE_BASE
# #########################################################
# ORACLE_BASE is required for the installation
# ORACLE_BASE can be specified as follows:
# 1. by specifying '-oracle_base <path>' option
# 2. by setting ORACLE_BASE in the environment
# 3. If /u01/app/oracle exists, then use this Oracle default as value for ORACLE_BASE (Engineered Systems)
# 4. Otherwise use the SAP default /oracle/<DB_SID>
# #########################################################

if [ -n "${tgt_ob_loc}" ]; then
  MSGINFOV "Oracle base is specified via '-oracle_base <path>'."
else
  MSGINFOV "Oracle base is not specified via '-oracle_base <path>'."
  if [ -n "${ORACLE_BASE}" ]; then
    MSGINFOV "Oracle base is specified via ORACLE_BASE environment variable."
  else
    MSGINFOV "Oracle base is not specified via ORACLE_BASE environment variable."
    if [ -d "/u01/app/oracle" ]; then
    	# Oracle Engineered System - Using Oracle Default for ORACLE_BASE
      MSGINFOV "Directory /u01/app/oracle exists."
      MSGINFOV "ORACLE_BASE: using Oracle default /u01/app/oracle"
    else
      # Non-Engineered Custom System
      if [ -n "${tgt_db_sid}" ]; then
        MSGINFOV "<DB_SID> is specified via '-db_sid <DB_SID>'."
      else
        MSGINFOV "<DB_SID> is not specified via '-db_sid <DB_SID>'."
      fi
      if [ -n "${DB_SID}" ]; then
        # Non-Engineered Custom System - Using SAP Default for ORACLE_BASE
        MSGINFOV "<ORACLE_BASE> is not specified, but <DB_SID> is defined."
        MSGINFOV "ORACLE_BASE: using SAP default /oracle/<DB_SID>"
      else
      	# ERROR - ORACLE_BASE is UNDEFINED
        MSGERRRS "Neither <ORACLE_BASE> nor <DB_SID> are specified."
        MSGERRRS "Cannot determine value for <ORACLE_BASE>."
        echo_std "${MSG_INFO}" "Set ORACLE_BASE in the environment or use -oracle_base option or set DB_SID in the environment."
        install_exit $RC_PREREQ_ERROR
      fi
    fi
  fi
fi

# #########################################################
# Check CV_ASSUME_DISTID
# #########################################################
if [ -z "${CV_ASSUME_DISTID}" ]; then
  MSGINFOV "<CV_ASSUME_DISTID> is not specified."
else
  MSGINFOV "<CV_ASSUME_DISTID> is specified."
fi

###############################################################################
#                                                                             #
#                                                                             #
#                                                                             #
#                         ENVIRONMENT VARIABLES CHECKED  (PART I)             #
#                                                                             #
#                                                                             #
#                                                                             #
###############################################################################
env_checked="${STR_TRUE}"

# #############################################################################
# Enable logging
# #############################################################################
if [ "${env_checked}" = "${STR_TRUE}" ] && [ "${logging_enabled}" = "${STR_TRUE}" ]; then
	logging_status="ON"
fi

# #############################################################################
# Write command line to history log file / summary log file
# #############################################################################
echo_sum "${log_time} | ${script_name} ${script_cmdl}"

###############################################################################
#                                                                             #
#                                                                             #
#                                                                             #
#                              START OUTPUT HERE                              #
#                                                                             #
#                                                                             #
#                                                                             #
###############################################################################

# #############################################################################
# Function Test Output
# #############################################################################
#MSGFREES "Hello, world!"
#MSGINFOS "Hello, world!"
#MSGWARNS "Hello, world!"
#MSGERRRS "Hello, world!"

#MSGFREEV "Hello, world!"
#MSGINFOV "Hello, world!"
#MSGWARNV "Hello, world!"
#MSGERRRV "Hello, world!"

#MSGFREET "Hello, world!"
#MSGINFOT "Hello, world!"
#MSGWARNT "Hello, world!"
#MSGERRRT "Hello, world!"

# #############################################################################
# BANNER / HEADER
# #############################################################################
MSGFREES
MSGFREES "$script_line"
MSGFREES "$script_bnnr"
MSGFREES "$script_copy"
MSGFREES "$script_line"

# #############################################################################
# VERSION INFORMATION
# #############################################################################
#MSGFREEV "$script_name Version ${script_vers} Patch Level ${script_plvl} Release Date ${script_date} (${script_stat})"
MSGFREES "$script_name ${script_vers} (${script_plvl}) ${script_date} ${script_stat}"
MSGFREES "$script_line"

# #############################################################################
# SAP REFERENCE NOTE
# #############################################################################
MSGFREEV "SAP note ${script_note}"

# #############################################################################
# Basic technical information
# #############################################################################
MSGFREES
MSGFREES "Host          : ${run_host}"
MSGFREES "Platform      : ${platform} (${bit}-bit)"

case $platform in
  aix            ) MSGFREES "Unix Version  : ${unix_version}" ;;
  hp_ux_ia64     ) MSGFREES "Unix Version  : ${unix_version}" ;;
  linux_x86_64   ) MSGFREES "Unix Version  : ${unix_version}" ;;
  sunos_i86pc    ) MSGFREES "Unix Version  : ${unix_version}" ;;
  sunos_sun4u    ) MSGFREES "Unix Version  : ${unix_version}" ;;
esac

MSGFREES "Date          : ${run_date} ${run_time}"
MSGFREES "User          : ${run_username}"
MSGFREES

# #############################################################################
# SAP RUNINSTALLER Information
# #############################################################################
MSGFREEV "SAP RUNINSTALLER"
MSGFREEV "Wrapper script: ${PROGDIR}/RUNINSTALLER"
MSGFREEV "Install script: ${PROGDIR}/${PROGNAME}"

# #############################################################################
# Logging information
# #############################################################################
MSGFREEV "Log dir.      : ${install_base_dir}"
MSGFREEV "Log file      : ${sap_log_file_single}"
MSGFREEV "Summary log   : ${sap_log_file_summary}"

# #############################################################################
# Trace mode and Verbose mode
# #############################################################################
MSGFREEV "Verbose mode  : ${verbose_mode}"
MSGFREEV "Trace mode    : ${trace_mode}"

MSGFREEV "Query mode    : ${query_mode}"  # -query
MSGFREEV "Nowarn mode   : ${nowarn_mode}" # -ignoreWarnings

# #############################################################################
# Command Line / Command Line Arguments / Number of Arguments
# #############################################################################
MSGFREEV "${script_name} was called with ${script_argn} arguments."
MSGFREEV "${script_name} was called with the following options (command line):"
MSGFREEV "${script_cmdl}"

MSGFREES "Command line #: ${script_argn}"
MSGFREES "Command line  : ${script_cmdl}"

# #######################################
# show_arg_list_1  ${script_cmdl}
# #######################################
# show_arg_list_2  ${script_cmdl}
# #######################################
# echo_std "Command line: $*"
# #######################################
# echo_std "Command line: ${script_cmdl}"
# #######################################
# for opt in ${script_cmdl}
#   do
# 	  echo_std "$opt"
#   done
# #######################################

###############################################################################
# Root Script Automation (-rsa)
###############################################################################
# https://stackoverflow.com/questions/3980668/how-to-get-a-password-from-a-shell-script-without-echoing
if [ "${oui_rsa_option}" = "true" ]; then
  # root script automation is enabled
  case $oui_rsa_method in
    ROOT) oui_rsa_userun="${oui_rsa_rootun}" ;;
    SUDO) oui_rsa_userun="${oui_rsa_sudoun}" ;;
    *   ) # this should never happen
          MSGERRRS "Invalid root script automation method ${oui_rsa_method}. Cannot continue."
          install_exit $RC_INVARG_ERROR
          ;;
  esac
  # check rsa user name
  if [ -z "${oui_rsa_userun}" ]; then
    MSGERRRS "User name for root script automation method ${oui_rsa_method} is not specified. Cannot continue."
    install_exit $RC_INVARG_ERROR
  fi
  # check whether RUNINSTALLER runs in silent mode
  if [ "${silent_mode}" = "-silent" ] && [ "${oui_rsa_option_nopassword}" = "false" ]; then
    # silent mode is enabled AND password is required
    MSGINFOS "Root Script Automation + Silent Installation"
    MSGINFOS "Root Script Automation Method: ${oui_rsa_method}"
    MSGINFOS "The password for '${oui_rsa_userun}' is needed for Root Script Automation."
    MSGINFOS
    MSGINFOS "You have the following options to specify the password:"
    MSGINFOS "1. You can enter the password to SAP RUNINSTALLER now."
    MSGINFOS "2. You can enter the password to Oracle Installer when prompted."
    MSGINFOS "3. You can specify the password to RUNINSTALLER through a pipe:"
    MSGINFOS "   OS> echo ""<pwd>"" | RUNINSTALLER <options>"
    MSGINFOS "4. You can specify the password to RUNINSTALLER on the command line (not secure):"
    MSGINFOS "   OS> RUNINSTALLER <options> [-rsasudopass <pwd>] [-rsarootpass <pwd>]"
    MSGFREES
  	case $oui_rsa_method in
      ROOT) 
        if [ -z "${oui_rsa_rootpw}" ]; then
          # password required
          MSGFREES "RUNINSTALLER: Please enter the password for '${oui_rsa_userun}':"
          read -s -p "Enter the password   :" oui_rsa_rootpw
          MSGFREES
          if [ -n "${oui_rsa_rootpw}" ] && [ "${oui_rsa_option_verify}" = "true" ]; then
            read -s -p "Re-enter the password:" oui_rsa_rootp2
            MSGFREES
            if [ "${oui_rsa_rootpw}" = "${oui_rsa_rootp2}" ]; then
              MSGINFOS "Passwords are identical."
            else
              MSGERRRS "Passwords do not match."
              install_exit $RC_ERRR
            fi
          fi
          MSGFREES
          [ -n "${oui_rsa_rootpw}" ] && MSGINFOS "Password entered."
          [ -z "${oui_rsa_rootpw}" ] && MSGWARNS "Password not entered (empty)."
          MSGFREES
        else
          # password already set
          MSGINFOS "The password for '${oui_rsa_userun}' is already specified."
        fi
        ;;
      SUDO)
        if [ -z "${oui_rsa_sudopw}" ]; then
          # password required
          MSGFREES "RUNINSTALLER: Please enter the password for '${oui_rsa_userun}':"
          read -s -p "Enter the password   :" oui_rsa_sudopw
          MSGFREES
          if [ -n "${oui_rsa_sudopw}" ] && [ "${oui_rsa_option_verify}" = "true" ]; then
            read -s -p "Re-enter the password:" oui_rsa_sudop2
            MSGFREES
            if [ "${oui_rsa_sudopw}" = "${oui_rsa_sudop2}" ]; then
              MSGINFOS "Passwords are identical."
            else
              MSGERRRS "Passwords do not match."
              install_exit $RC_ERRR
            fi
          fi
          MSGFREES
          [ -n "${oui_rsa_sudopw}" ] && MSGINFOS "Password entered."
          [ -z "${oui_rsa_sudopw}" ] && MSGWARNS "Password not entered (empty)."
          MSGFREES
        else
          # password already set
          MSGINFOS "The password for '${oui_rsa_userun}' is already specified."
        fi
        ;;
    esac
  else
    MSGINFOS "Root Script Automation + Non-Silent Installation"
    MSGINFOS "Root Script Automation Method: ${oui_rsa_method}"
  fi
fi

# masking passwords for sudo or root
[ -n "${oui_rsa_rootpw}" ] && oui_rsa_rootpx=`echo "${oui_rsa_rootpw}" | sed 's/./X/g' `  # replace with 'X'
[ -n "${oui_rsa_rootpw}" ] && oui_rsa_rootpx=`echo "${oui_rsa_rootpw}" | sed 's/./*/g' `  # replace with '*'
[ -n "${oui_rsa_sudopw}" ] && oui_rsa_sudopx=`echo "${oui_rsa_sudopw}" | sed 's/./X/g' `  # replace with 'X'
[ -n "${oui_rsa_sudopw}" ] && oui_rsa_sudopx=`echo "${oui_rsa_sudopw}" | sed 's/./*/g' `  # replace with '*'

# copy password for sudo or root (incl. masked passwords)
[ -n "${oui_rsa_rootpw}" ] && oui_rsa_userpw="${oui_rsa_rootpw}" && oui_rsa_userpx="${oui_rsa_rootpx}"
[ -n "${oui_rsa_sudopw}" ] && oui_rsa_userpw="${oui_rsa_sudopw}" && oui_rsa_userpx="${oui_rsa_sudopx}"

# tracing root password (never enable for production)
#[ -n "${oui_rsa_rootpw}" ] && MSGINFOS "Root Script Automation: root password       : $oui_rsa_rootpw"
#[ -n "${oui_rsa_rootpx}" ] && MSGINFOS "Root Script Automation: root password masked: $oui_rsa_rootpx"
#[ -n "${oui_rsa_sudopw}" ] && MSGINFOS "Root Script Automation: sudo password       : $oui_rsa_sudopw"
#[ -n "${oui_rsa_sudopx}" ] && MSGINFOS "Root Script Automation: sudo password masked: $oui_rsa_sudopx"

# #############################################################################
# Installation Session Start
# #############################################################################
inst_session_start

# #############################################################################
# Setting Installation Tasks (-ohinstall / -ohnoinstall)
# #############################################################################
[ "$opt_ohi" = "${STR_YES}" ] && opt_ohp=${STR_YES} && opt_ohv=${STR_YES} && opt_ohx=${STR_YES} && opt_ohr=${STR_YES} && opt_ohs=${STR_YES} # && opt_ohm=${STR_YES}

MSGINFOT "opt_ohi=${opt_ohi}"
MSGINFOT "opt_ohn=${opt_ohn}"
MSGINFOT "opt_ohp=${opt_ohp}"
MSGINFOT "opt_ohv=${opt_ohv}"
MSGINFOT "opt_ohx=${opt_ohx}"
MSGINFOT "opt_ohc=${opt_ohc}"
MSGINFOT "opt_ohr=${opt_ohr}"
MSGINFOT "opt_ohs=${opt_ohs}"
MSGINFOT "opt_ohm=${opt_ohm}"

###############################################################################
#                                                                             #
#                     BGN TASK: -ohinstall                                    #
#                                                                             #
###############################################################################
dsc_cur="${dsc_ohi}"
[ $opt_ohi = ${STR_YES} ] && MSGINFOS "TASK - $dsc_ohi"
[ $opt_ohi = ${STR_YES} ] && MSGDATETIME "${dsc_cur}"

###############################################################################
#                                                                             #
#                     BGN TASK: -ohnoinstall                                  #
#                                                                             #
###############################################################################
dsc_cur="${dsc_ohn}"
[ $opt_ohn = ${STR_YES} ] && MSGINFOS "TASK - $dsc_ohn"
[ $opt_ohn = ${STR_YES} ] && MSGDATETIME "${dsc_cur}"

###############################################################################
#                                                                             #
#                     BGN TASK: -ohprepare                                    #
#                                                                             #
###############################################################################
dsc_cur="${dsc_ohp}"
[ $opt_ohi = ${STR_NO}  ] && [ $opt_ohm = ${STR_NO} ] && [ $opt_ohs = ${STR_NO} ] && [ $opt_ohr = ${STR_NO} ] && [ $opt_ohc = ${STR_NO} ] && [ $opt_ohx = ${STR_NO} ] && [ $opt_ohv = ${STR_NO} ] && [ $opt_ohp = ${STR_NO} ] && install_exit $RC_SUCC
[ $opt_ohp = ${STR_YES} ] && MSGINFOS "TASK - $dsc_ohp" && run_ohp="${STR_YES}"
[ $opt_ohp = ${STR_YES} ] && MSGDATETIME "${dsc_cur}"
[ $opt_ohp = ${STR_NO}  ] && MSGINFOS "TASK - $dsc_ohp - ${dsc_dnr}"
[ $opt_ohp = ${STR_YES} ] && rct_ohp=$RC_SUCC

# #############################################################################
# Pre-installation checks
# #############################################################################
echo_std
echo_std "Performing Pre-Installation Checks ..."
echo_std

# #############################################################################
# Checking version of unzip utility
# #############################################################################
MSGFREEV "Checking version of unzip utility"
#if ( unzip | grep -i '^unzip 6' ) 1>/dev/null 2>&1; then
if ( unzip | head -1 | grep -i 'unzip 6' ) 1>/dev/null 2>&1; then
  echo_std "$MSG_OKOK" "unzip 6.00 or later available."
else
  MSGERRRS "No unzip 6.00 or later available. See SAP Note 2599248."
  MSGINFOS "unzip path  : ${OS_UNZIP_PATH:-${STR_NOT_SET}}"
  MSGINFOS "unzip banner: ${OS_UNZIP_BANNER:-${STR_NOT_SET}}"
  install_exit $RC_PREREQ_ERROR
fi

# #############################################################################
# Change permissions on Log file 644 -> 664
# #############################################################################
MSGFREEV "Setting permissions for log file ${sap_log_file_single} ..."
if [ -f ${sap_log_file_single} ]; then
  # Check current permissions
  # ls -l ${sap_log_file_single}
  chmod 664 ${sap_log_file_single}
  chmod_rc=$?
  if [ $chmod_rc -ne 0 ]; then
    MSGWARNS "Changing permissions on ${sap_log_file_single} failed."
    rct_ohp=$RC_WARN
# else
#   echo_std "Permissions on log file ${sap_log_file_single} changed successfully."
  fi
  # Verify that permissions are changed
  # ls -l ${sap_log_file_single}
else
  # Log file does not exist.
  MSGWARNS "Log file ${sap_log_file_single} does not exist."
  #MSGWARNS "Can not write to log file ${sap_log_file_single}."
fi

# #############################################################################
# Check write permissions
# #############################################################################
MSGFREEV "Checking write permissions ..."

for dir_to_check in ${sap_log_dir} ${rspf_dir} ${oui_log_dir} ${tmp_dir_base}
do
  if CanCreateFileIn ${dir_to_check}; then
  	MSGFREEV  "${MSG_OKOK}" "write permission for directory ${dir_to_check} checked."
  else
    echo_std  "${MSG_WARN}" "Cannot create files in directory ${dir_to_check}. No write/create permissions."
    rct_ohp=$RC_WARN
  fi
done

# #############################################################################
# Retrieve size of free space in critical directories
# #############################################################################
# http://unix.stackexchange.com/questions/6008/get-the-free-space-available-in-current-directory-in-bash
MSGFREEV "Checking free space in directory ${tmp_dir_base} ..."

# get free space in tmp_dir_base
if [ -n "${tmp_dir_base}" ] && [ -d "${tmp_dir_base}" ]; then
  case $platform in
    aix)
      tmp_dir_base_free=`df -Pg "${tmp_dir_base}" | tail -1 | awk '{print $4}'`
      DF_UNIT="GByte"
      ;;
    hp_ux_9000_800)
      tmp_dir_base_free="unknown"
      ;;
    hp_ux_ia64)
      # Version 1
      #tmp_dir_base_free=`df -Pk "${tmp_dir_base}" | tail -1 | awk '{print $4}'`
      #DF_UNIT="KByte"
      # Version 2
      tmp_dir_base_free=`df -Pk "${tmp_dir_base}" | tail -1 | awk '{print $4}'`
      tmp_dir_base_free=`expr $tmp_dir_base_free / 1048576 `
      DF_UNIT="GByte"
      ;;
    sunos_sun4u | sunos_i86pc)
      tmp_dir_base_free=`df -h  "${tmp_dir_base}" | tail -1 | awk '{print $4}'`
      ;;
    osf1_alpha)
      tmp_dir_base_free="unknown"
      ;;
    linux_x86_64 | linux_i686 | linux_ia64 | linux_ppc64)
      # Version 1:
      #AB 2016-12-12: changed from human readable to KByte
      #tmp_dir_base_free=`df -Ph "${tmp_dir_base}" | tail -1 | awk '{print $4}'`
      # Version 2:
      #tmp_dir_base_free=`df -Pk "${tmp_dir_base}" | tail -1 | awk '{print $4}'`
      #DF_UNIT="KByte"
      # Version 3:
      tmp_dir_base_free=`df -Pk "${tmp_dir_base}" | tail -1 | awk '{print $4}'`
      tmp_dir_base_free=`expr $tmp_dir_base_free / 1048576 `
      DF_UNIT="GByte"
      ;;
    *)
      echo_err "Cannot determine free disk space in $tmp_dir_base ($platform)." 
      ;;
  esac
fi

#### get free space in tmp_dir_base
###if [ -n "${tmp_dir_base}" ] && [ -d "${tmp_dir_base}" ]; then
###  tmp_dir_base_free=`df -Ph "${tmp_dir_base}" | tail -1 | awk '{print $4}'`
###fi

#### get free space in home directory
###if [ -n "${HOME}" ] && [ -d "${HOME}" ]; then
###  home_dir_free=`df -Ph "${HOME}" | tail -1 | awk '{print $4}'`
###fi

#### get free space in /tmp directory
###if [ -n "${HOME}" ] && [ -d "${HOME}" ]; then
###  tmp_dir_free=`df -Ph "/tmp" | tail -1 | awk '{print $4}'`
###fi

# #############################################################################
# check for zero UID (root)
# #############################################################################
MSGFREEV "Checking whether script runs as root user ..."

if RunningAsRoot;then
  MSGERRRS "You are logged in as super user (UID=0)."
  MSGERRRS "You must be logged in as a normal OS user (e.g. oracle or ora<dbsid> user) to install Oracle software."
  install_exit $RC_PREREQ_ERROR
fi

# #############################################################################
# Check for enough free space in temp dir
# Checking for 2GByte of free space
# #############################################################################
MSGFREEV "Checking for enough free disk space in directory ${tmp_dir_base} ..."

if [ -n "${tmp_dir_base}" ] && [ -d "${tmp_dir_base}" ]; then
  case $platform in
    hp_ux_9000_800 | sunos_sun4u | sunos_i86pc | osf1_alpha)
      #echo_std "$MSG_WARN" "Cannot decide for this platform ($platform) whether there is enough free space in TEMP directory."
	  #echo_std "$MSG_INFO" "Cannot decide for this platform ($platform) whether there is enough free space in TEMP directory."
	  echo_std "$MSG_INFO" "Skipping check for enough free space in TEMP on platform ${platform}."
      ;;
    aix | hp_ux_ia64 | linux_x86_64 | linux_i686 | linux_ia64 | linux_ppc64 )
      if [ $tmp_dir_base_free -ge $tmp_dir_base_free_min ]; then
        echo_std "$MSG_OKOK" "There is enough free space in TEMP directory."
        echo_std "$MSG_OKOK" "${tmp_dir_base} has $tmp_dir_base_free $DF_UNIT free."
      else
        echo_std "$MSG_WARN" "There's not enough free disk space in TEMP directory ${tmp_dir_base}."
        MSGFREEV "$MSG_WARN" "${tmp_dir_base} has $tmp_dir_base_free $DF_UNIT free disk space."
        MSGFREEV "$MSG_WARN" "For installation we need $tmp_dir_base_free_min $DF_UNIT free disk space."
      fi
      ;;
    *)
      echo_err "Could not verify free disk space in $tmp_dir_base ($platform)." 
      ;;
  esac
fi

# #############################################################################
# Checking environment variables (Part II)
# #############################################################################

# DB_SID
MSGFREEV "Checking environment variable <DB_SID> ..."
db_sid_is_set && echo_std "${MSG_OKOK}" "Environment variable <DB_SID> is set to ${DB_SID}"
if [ -n "${tgt_db_sid}" ]; then
  echo_std "${MSG_OKOK}" "Got value for <DB_SID> from '-db_sid' option."
else
  if db_sid_is_set; then
    tgt_db_sid=${DB_SID}
    echo_std "${MSG_OKOK}" "Got value for <DB_SID> from environment."
  else
    # DB_SID is not set 
    if db_sid_is_mandatory; then 
      MSGWARNS "No value for <DB_SID> given."
    else
      echo_std "${MSG_OKOK}" "No value for <DB_SID> given (not mandatory)."
    fi
    tgt_db_sid=""
  fi
fi
# tgt_db_sid is set here (or not if not mandatory)

# ORACLE_BASE
MSGFREEV "Checking environment variable <ORACLE_BASE> ..."
if [ -n "${tgt_ob_loc}" ]; then
  echo_std "${MSG_OKOK}" "Got location for Oracle base from '-oracle_base' option."
else
  if [ -n "${ORACLE_BASE}" ]; then
    # ORACLE_BASE environment variable is set
    tgt_ob_loc=${ORACLE_BASE}
    echo_std "${MSG_OKOK}" "Got location for Oracle base from environment (ORACLE_BASE)."
    # 2017-10-19: added for 12.2.0.1: migrate ORACLE_BASE from /oracle to /oracle/<DBSID>
    #             you can override this mechanism using -oracle_base /oracle option
    if [ "${ORACLE_BASE}" = "/oracle" ]; then
      if db_sid_is_set; then
        tgt_ob_loc="/oracle/$tgt_db_sid"
        echo_std "${MSG_OKOK}" "Using new ORACLE_BASE=${tgt_ob_loc} instead of ORACLE_BASE=/oracle"
      fi
    fi
  else
    # ORACLE_BASE environment variable is not set
    if [ -n "${ORACLE_BASE_DEF_OES}" ]; then
    	# Oracle Engineered System - Using Oracle Default for ORACLE_BASE
      tgt_ob_loc=$ORACLE_BASE_DEF_OES
      echo_std "${MSG_OKOK}" "ORACLE_BASE: using Oracle default $tgt_ob_loc"
    else
      # Non-Engineered Custom System - Using SAP Default for ORACLE_BASE
      tgt_ob_loc=$ORACLE_BASE_DEF_SAP
      echo_std "${MSG_OKOK}" "ORACLE_BASE: using SAP default $tgt_ob_loc"
    fi
  fi
fi
# tgt_ob_loc is set here

# ORACLE_STAGE
[ -n "${ora_stage_loc_0}" ] && MSGFREEV "${MSG_OKOK}" "Got location for Oracle stage from '-oracle_stage'   option: ${ora_stage_loc_0}"
[ -n "${ora_stage_loc_1}" ] && MSGFREEV "${MSG_OKOK}" "Got location for Oracle stage from '-oracle_stage_1' option: ${ora_stage_loc_1}"
[ -n "${ora_stage_loc_2}" ] && MSGFREEV "${MSG_OKOK}" "Got location for Oracle stage from '-oracle_stage_2' option: ${ora_stage_loc_2}"
if [ -z "${ora_stage_loc_0}" ] && [ -z "${ora_stage_loc_1}" ] && [ -z "${ora_stage_loc_2}" ]; then
  MSGWARNS "Oracle stage is not specified."
  rct_ohp=$RC_WARN
  #RC_RETCODE=$RC_PREREQ_ERROR
  #install_exit $RC_PREREQ_ERROR
fi

# DISPLAY
MSGFREEV "Checking environment variable <DISPLAY> ..."
if [ -z "${DISPLAY}" ]; then
  if [ -z "${silent_mode}" ]; then
    # interactive mode
    if [ "$opt_ohr" = "${STR_YES}" ] || [ "$opt_ohc" = "${STR_YES}" ]; then 
      MSGERRRS "Environment variable DISPLAY is not set (required for interactive mode)."
      rct_ohp=$RC_ERRR
      install_exit $RC_PREREQ_ERROR
    else
      echo_std "${MSG_OKOK}" "Environment variable DISPLAY is not set (runInstaller is not started)."
    fi
  else
    # silent mode
    echo_std "${MSG_OKOK}" "Environment variable DISPLAY is not set (not required for silent mode)."
  fi
else  
  echo_std "${MSG_OKOK}" "Environment variable DISPLAY is set."
fi

# CV_ASSUME_DISTID
MSGFREEV "Checking environment variable <CV_ASSUME_DISTID> ..."
if [ -n "${CV_ASSUME_DISTID}" ]; then
  # special scenario: could be reported as WARNING??
  echo_std "${MSG_OKOK}" "Environment variable <CV_ASSUME_DISTID> is set to ${CV_ASSUME_DISTID}"
else
  # default scenario: not set
  echo_std "${MSG_OKOK}" "Environment variable <CV_ASSUME_DISTID> is not set"
fi

#
# SKIP_ROOTPRE
#
MSGFREEV "Checking environment variable <SKIP_ROOTPRE> ..."
if [ "$platform" = "aix" ]; then
  #############################################################################
  # AIX
  #############################################################################
  MSGINFOV "AIX: Checking environment variable SKIP_ROOTPRE (AIX)."
  if [ -n "${SKIP_ROOTPRE}" ]; then
    #####################
    # SKIP_ROOTPRE=TRUE #
    #####################
    echo_std "${MSG_OKOK}" "AIX: Environment variable SKIP_ROOTPRE is set (${SKIP_ROOTPRE})."
  else
    echo_std "${MSG_OKOK}" "AIX: Environment variable SKIP_ROOTPRE is not set."
    if [ -z "${silent_mode}" ]; then
      #####################
      # Interactive Mode  #
      #####################
      echo_std "${MSG_OKOK}" "AIX: Environment variable SKIP_ROOTPRE is not set (interactive mode)."
    else
      #####################
      # Silent Mode       #
      #####################
      echo_std "${MSG_OKOK}" "AIX: Environment variable SKIP_ROOTPRE is not set (silent mode)."
      if [ "$opt_ohr" = "${STR_YES}" ]; then # runInstaller is started
        MSGERRRS "AIX: You must set environment variable SKIP_ROOTPRE to run runInstaller in silent mode."
        rct_ohp=$RC_ERRR
        install_exit $RC_PREREQ_ERROR
      fi
      if [ "$opt_ohc" = "${STR_YES}" ]; then # runInstaller is started
        MSGERRRS "AIX: You must set environment variable SKIP_ROOTPRE to run runInstaller in silent mode."
        rct_ohp=$RC_ERRR
        install_exit $RC_PREREQ_ERROR
      fi
    fi
  fi
else
  #############################################################################
  # NOT AIX
  #############################################################################
  MSGINFOV "Checking environment variable SKIP_ROOTPRE is skipped (not AIX)."
fi

# #############################################################################
# Checking environment variables (Part III)
# #############################################################################

# The following environment variables should never be set (Reference: SAP Database Upgrade Guide for Oracle for 11.2)
[ -z "${TWO_TASK}"  ] || MSGWARNS "Environment variable TWO_TASK should not be set."
[ -z "${ORA_NLS}"   ] || MSGWARNS "Environment variable ORA_NLS should not be set."
[ -z "${ORA_NLS10}" ] || MSGWARNS "Environment variable ORA_NLS10 should not be set."
[ -z "${ORA_NLS32}" ] || MSGWARNS "Environment variable ORA_NLS32 should not be set."
[ -z "${ORA_NLS33}" ] || MSGWARNS "Environment variable ORA_NLS33 should not be set."

# #############################################################################
# Checking existence of /oracle/<DB_SID>
# #############################################################################
# This check is needed for Shared Oracle Home scenario
# Check whether the base directory for the runtime Oracle home exists
MSGFREEV "Checking directory /oracle/<DB_SID> ..."
if [ -n "${DB_SID}" ]; then
	if [ -d "/oracle/${DB_SID}" ]; then
   #echo_std "${MSG_OKOK}" "Base directory for runtime Oracle home /oracle/${DB_SID} exists."
    echo_std "${MSG_OKOK}" "Directory /oracle/${DB_SID} exists."
  else
   #MSGWARNS "Base directory for runtime Oracle home /oracle/${DB_SID} does not exist."
    MSGWARNS "Directory /oracle/${DB_SID} does not exist."
    rct_ohp=$RC_WARN
  fi
fi

# #############################################################################
# Checking installation user
# #############################################################################
# This check is needed for Shared Oracle Home scenario
MSGFREEV "Checking software owner ..."
if SharedOhInstall; then
	if [ "$run_username" = "oracle" ]; then
    echo_std "${MSG_OKOK}" "Shared Oracle home is supported for software owner 'oracle'."
	else
    MSGWARNS "Shared Oracle home is only supported for software owner 'oracle'."
    rct_ohp=$RC_WARN
  fi
fi
 
# #############################################################################
# Checking ORACLE_BASE (SAP note 1521371)
# #############################################################################
MSGFREEV "Checking directory <ORACLE_BASE> ..."
if [ -d ${tgt_ob_loc} ]; then
  echo_std "${MSG_OKOK}" "Oracle base location ${tgt_ob_loc} exists."
  tgt_ob_loc_flag=" (exists) "
else
  MSGWARNS "Oracle base location ${tgt_ob_loc} does not exist."
  tgt_ob_loc_flag=" (does not exist) "
  rct_ohp=$RC_WARN
fi

# #############################################################################
# Checking oratab
# #############################################################################
MSGFREEV "Checking oratab ..."

oratabfile=${ORATAB_LOCATION}
if [ -f ${oratabfile} ]; then
  echo_std "${MSG_OKOK}" "oratab file ${oratabfile} exists."
  oratabfile_flag=" (exists) "
else
  echo_std "${MSG_OKOK}" "oratab file${oratabfile} does not exist."
  oratabfile_flag=" (does not exist) "
fi

# #############################################################################
# Setting Inventory Group
# #############################################################################
# install as 'ora<sid>:dba'    -> inventory group is 'dba'
# install as 'oracle:oinstall' -> inventory group is 'oinstall'
# #############################################################################

if [ "${run_username}" = "oracle" ]; then
  group_inventory="${osgroup_install}"
fi

user_group="${run_username}:${group_inventory}"
MSGINFOT "User:Group = $user_group"

# #############################################################################
# Setting Oracle home location (Installation location)
# #############################################################################

if [ -n "${tgt_oh_loc}" ]; then
	# install Oracle home has been specified on command line
  tgt_oh_dirname=`basename ${tgt_oh_loc}`
  MSGINFOV "IHRDBMS: using specified value $tgt_oh_loc"
else
  if [ "${tgt_ob_loc}" = "${ORACLE_BASE_DEF_OES}" ]; then
	  # set installation Oracle home IHRDBMS to Oracle default
	  # Example for release 12.1.0.2: /u01/app/oracle/product/12.1.0.2/dbhome_1
    tgt_oh_loc="/u01/app/oracle/product/${ORA_DB_VERS1}.${ORA_DB_VERS2}.${ORA_DB_VERS3}.${ORA_DB_VERS4}/dbhome_1"
    MSGINFOV "IHRDBMS: using Oracle default $tgt_oh_loc"
  else
	  # set installation Oracle home IHRDBMS to SAP default 
	  if [ -n "${tgt_db_sid}" ]; then
      tgt_oh_loc="/oracle/${tgt_db_sid}/${tgt_oh_dirname}"
      MSGINFOV "IHRDBMS: using SAP default $tgt_oh_loc"
    else
      MSGERRRS "Cannot determine installation location for target Oracle home because <DB_SID> is not specified."
      install_exit $RC_PREREQ_ERROR
    fi
  fi
fi

# #############################################################################
# Checking Oracle home location (Installation location)
# Setting flags
# #############################################################################
MSGFREEV "Checking location for Oracle home <IHRDBMS> ..."

tgt_oh_loc_flag=""
tgt_oh_loc_exists="no"
tgt_oh_loc_isempty="yes"
# The following flag combinations are possible:
# tgt_oh_loc_flag1="" # existing / not existing
# tgt_oh_loc_flag2="" # empty    / not empty
# tgt_oh_loc_flag3="" # shared   / not shared

if [ -d ${tgt_oh_loc} ]; then
  MSGWARNS "Installation location ${tgt_oh_loc} already exists."
  rct_ohp=$RC_WARN
 #tgt_oh_loc_flag=" (*) already exists "
  tgt_oh_loc_exists="yes"
  tgt_oh_loc_flag1="existing"
  # #######################################################
  # Oracle home location (Installation location) is empty?
  # If not empty, OUI will report warning:
  # INS-32016: The selected Oracle home contains directories or files.
  # #######################################################
  if [ -d ${tgt_oh_loc}/bin ]; then
    MSGWARNS "Installation location ${tgt_oh_loc} is not empty."
    rct_ohp=$RC_WARN
   #tgt_oh_loc_flag=" (*) already exists (not empty) "
    tgt_oh_loc_isempty="no"
    tgt_oh_loc_flag2="not empty"
  else
    echo_std "${MSG_OKOK}" "Installation location ${tgt_oh_loc} is empty."
   #tgt_oh_loc_flag=" (*) already exists (empty) "
    tgt_oh_loc_isempty="yes"
    tgt_oh_loc_flag2="empty"
  fi
else
  echo_std "${MSG_OKOK}" "Installation location ${tgt_oh_loc} does not exist."
  tgt_oh_loc_exists="no"
  tgt_oh_loc_flag1="not existing"
fi

if SharedOhInstall; then
  tgt_oh_loc_flag3="shared"
else
  tgt_oh_loc_flag3="not shared"
fi

# Set combined flag
tgt_oh_loc_flag="( $tgt_oh_loc_flag1 / $tgt_oh_loc_flag2 / $tgt_oh_loc_flag3 )"

# #############################################################################
# Setting Link location (Runtime location / OHRDBMS )
# #############################################################################
# Link name
if [ -z "${tgt_oh_linkname}" ]; then
  # Name of symbolic link is '18' (Runtime Oracle Home)
  tgt_oh_linkname="${ORA_DB_VERS1}"
fi

# Link location
if [ -n "${tgt_oh_linkloc}" ]; then
	#########################################################
	# Link location (tgt_oh_linkloc) is specified           #
	#########################################################
  # <OHRDBMS> was specified via -runtime_home <path> / -ohrdbms <path>
  # tgt_oh_link=<path>
  # tgt_oh_linkloc=`dirname ${tgt_oh_link}`
  # tgt_oh_linkname=`basename ${tgt_oh_link}`
  :
  MSGINFOT "Link location: specified on command line."
else
	#########################################################
	# Link location (tgt_oh_linkloc) is not yet specified   #
	#########################################################
  # Note: there is no need that the symbolic link is 
  #       created in the the same directory as the 
  #       installation directory.
  MSGINFOT "Link location: not specified on command line."
  if SharedOhInstall; then
    #######################################################
    # Shared OH                                           #
    #######################################################
    MSGINFOT "Link location: Shared OH scenario."
  	if db_sid_is_set; then
    	#####################################################
  		# Shared OH / DB_SID is set                         #
  		# /oracle/<DBSID>/<linkname> -> <IHRDBMS>           #
    	#####################################################
      MSGINFOT "Link location: deriving <OHRDBMS> from DB_SID from environment."
      tgt_oh_linkloc="/oracle/${tgt_db_sid}"
      tgt_oh_link="${tgt_oh_linkloc}/${tgt_oh_linkname}"
  	else
    	#####################################################
  		# Shared OH / DB_SID is not set                     #
    	#####################################################
      MSGINFOT "Link location: no DB_SID set, <OHRDBMS> can not be configured."
      # Do not create symbolic link like this:
      # /oracle/RDBMS/112 -> /oracle/RDBMS/<RELEASE>
      # In a shared Oracle home installation scenario the runtime OH must be specified 
      # using the -ohrdbms option.
      tgt_oh_link_flag="not specified"
      # set the following flag to ensure that no link will be created
      sym_link_create_opt="no"  	
      MSGFREEV "This is a shared Oracle home installation, but no runtime Oracle home <OHRDBMS> has been specified. "
      MSGFREEV "A symbolic link will therefore not be created. Setting flag to 'no'."
    fi
  else
    #######################################################
    # Non-Shared OH                                       #
    #######################################################
    MSGINFOT "Link location: Non-Shared OH scenario."
    if db_sid_is_set; then
      #####################################################
      # Non-shared OH: Standard installation              #
      # /oracle/<DB_SID>/<LINK> -> <RELEASE>              #
      #####################################################
      # PL 055: changing tgt_oh_linkloc computation
      #         from tgt_oh_linkloc=`dirname ${tgt_oh_loc}`
      #         to 
     #tgt_oh_linkloc=`dirname ${tgt_oh_loc}`
      tgt_oh_linkloc="/oracle/${tgt_db_sid}"
      tgt_oh_link="${tgt_oh_linkloc}/${tgt_oh_linkname}"
    else
      #####################################################
      # Non-shared OH: DB_SID is not set                  #
      # Do not set a runtime home and do not create link  #
      # Do not set add an entry in orabasetab             #
      #####################################################
      tgt_oh_linkloc=""
      tgt_oh_link=""
      sym_link_create_opt="no"
      opt_orabasetab="no"
    fi
  fi
fi

# Tracing link location
if [ -n "$tgt_oh_link" ]; then
  MSGINFOT "Link location and link name"
  MSGINFOT "OHRDBMS      : $tgt_oh_link $tgt_oh_link_flag"
  MSGINFOT "Link location: $tgt_oh_linkloc"
  MSGINFOT "Link name    : $tgt_oh_linkname"
fi

# #############################################################################
# Checking Link location (Runtime location)
# Setting flags for link location
# #############################################################################
# The following flag combinations are possible:
# tgt_oh_link_flag1="" # existing / not existing
# tgt_oh_link_flag2="" # installed / created by SAPINST
# tgt_oh_link_flag3="" # symbolic link / lost symbolic link

MSGFREEV "Checking location for Oracle home <OHRDBMS> ..."

if [ -n "$tgt_oh_link" ]; then
	# runtime location is specified - > check
  if [ -h ${tgt_oh_link} ]; then
  	tgt_oh_link_type="symbolic link"
	  tgt_oh_link_flag3="symbolic link"
  	##if is_lost_link ${tgt_oh_link} ; then
    ##	tgt_oh_link_type="lost symbolic link"
  	##  tgt_oh_link_flag3="lost symbolic link"
  	##fi
  elif [ -d ${tgt_oh_link} ]; then
  	tgt_oh_link_type="directory"
  elif [ -f ${tgt_oh_link} ]; then
  	tgt_oh_link_type="file"
  else
    #tgt_oh_link_type=""
    tgt_oh_link_type="unknown filetype"
  fi
  
  # Try to remove empty directory
  if is_dir "${tgt_oh_link}"; then 
    MSGINFOS "Runtime Oracle home directory ${tgt_oh_link} already exists (directory)."
    if is_empty_dir "${tgt_oh_link}"; then
      MSGINFOS "Runtime Oracle home directory ${tgt_oh_link} is empty and can be deleted."
      MSGFREEV "${OS_RMDIR} ${tgt_oh_link}"
      ${OS_RMDIR} ${tgt_oh_link}
      if is_dir "${tgt_oh_link}"; then
        MSGWARNS "Removing empty directory ${tgt_oh_link} failed."
      else
        MSGINFOS "Empty directory ${tgt_oh_link} removed."
      fi
    else
      MSGINFOS "Runtime Oracle home directory ${tgt_oh_link} is not empty."
    fi
  fi

  # Check symbolic link (2018-11-29 added), but do not remove
  if [ -h "${tgt_oh_link}" ]; then 
    MSGWARNS "Runtime Oracle home ${tgt_oh_link} already exists (link)."
  fi

  # Try to remove symbolic link (2018-11-29 added)
  #if [ -h "${tgt_oh_link}" ]; then 
  #  MSGINFOS "Runtime Oracle home ${tgt_oh_link} already exists (link)."
  #  ${OS_RMLINK} ${tgt_oh_link}
  #  if is_link "${tgt_oh_link}"; 
  #    then MSGWARNS "Failed to remove link ${tgt_oh_link}."
  #    else MSGINFOS "Link ${tgt_oh_link} removed successfully."
  #  fi
  #fi

  ### Try to remove lost symbolic link
  ##if is_lost_link "${tgt_oh_link}"; then
  ##  MSGINFOS "Runtime Oracle home ${tgt_oh_link} is a lost symbolic link that can be deleted."
  ##  MSGFREEV "${OS_RMLINK} ${tgt_oh_link}"
  ##  ${OS_RMLINK} ${tgt_oh_link}
  ##  if is_link "${tgt_oh_link}"; then
  ##    MSGWARNS "Removing lost symbolic link ${tgt_oh_link} failed."
  ##  else
  ##    MSGINFOS "Lost symbolic link ${tgt_oh_link} successfully removed."
  ##  fi
  ##fi
  
  if [ -f ${tgt_oh_link} ] || [ -h ${tgt_oh_link} ] || [ -d ${tgt_oh_link} ]; then
    # #######################################################
    # Check whether Runtime location was created by SAPINST.
    # 1. location must exist and
    # 2. location is empty except dbs/init<SID>.ora and 
    #                             network/admin/*.ora
    # #######################################################
    if [ -x ${tgt_oh_link}/bin/oracle ]; then
    	# oracle executable exists  -> not created by SAPINST
      MSGWARNS "Runtime location ${tgt_oh_link} already exists."
      MSGINFOV "Runtime location ${tgt_oh_link} is a ${tgt_oh_link_type}."
      MSGINFOV "Runtime location ${tgt_oh_link} cannot be renamed."
      MSGINFOV "The symbolic link ${tgt_oh_link} will not be created."
      # set flags
      tgt_oh_link_flag=" (*) already exists (${tgt_oh_link_type})"
      tgt_oh_link_flag1="existing (${tgt_oh_link_type})"
      tgt_oh_link_flag2="installed"
      created_by_SAPINST_flag="no"
      sym_link_create_opt="no"
    else
      # oracle executable missing -> created by SAPINST
      echo_std "${MSG_OKOK}" "Runtime location ${tgt_oh_link} already exists."
      echo_std "${MSG_CONT}" "Runtime location ${tgt_oh_link} is a ${tgt_oh_link_type}."
      # set flags
      tgt_oh_link_flag=" (*) already exists (${tgt_oh_link_type}), created by SAPINST "
      tgt_oh_link_flag1="existing (${tgt_oh_link_type})"
      if [ -d ${tgt_oh_link} ]; then
      	# if directory -> created by SAPINST, if symlink -> not created by SAPINST
        echo_std "${MSG_OKOK}" "Runtime location was created by SAPINST and can be renamed."
        tgt_oh_link_flag2="created by SAPINST"
        created_by_SAPINST_flag="yes"
      fi
      # sym_link_create_opt="yes" is the default setting
    fi
  else
    echo_std "${MSG_OKOK}" "Runtime location ${tgt_oh_link} does not exist."
    tgt_oh_link_flag1="not existing"
    tgt_oh_link_flag2="not installed"
  fi
  
  # Set combined flag
  tgt_oh_link_flag="( $tgt_oh_link_flag1 / $tgt_oh_link_flag2 )"
  
  # #############################################################################
  # Checking that installation and runtime location are not identical
  # #############################################################################
  if [ "${tgt_oh_loc}" = "${tgt_oh_link}" ]; then
    MSGERRRS "Oracle home installation location and runtime location are identical."
    install_exit $RC_PREREQ_ERROR
  fi
  
  # #############################################################################
  # Checking installation and runtime location
  # #############################################################################
  if [ `dirname ${tgt_oh_loc}` != `dirname ${tgt_oh_link}` ]; then
  	#echo_std "Location of Oracle home   " `dirname ${tgt_oh_loc}`
  	#echo_std "Location of symbolic link " `dirname ${tgt_oh_link}`
  	sym_link_path="absolute"
   #echo_std "${MSG_OKOK}" "Creating symbolic link as type $sym_link_path."
    echo_std "${MSG_OKOK}"    "Symbolic link for runtime location will use the $sym_link_path path of the installation location."
    MSGFREEV "${MSG_CONT}"  "$tgt_oh_link -> $tgt_oh_loc"
  fi
else
	# runtime location is not specified - > skip checks
  echo_std "${MSG_OKOK}" "No runtime environment is specified. Checks are skipped."
fi

# #############################################################################
# Central Oracle Inventory Pointer File oraInst.loc
# #############################################################################
# References:
#  1) How to Troubleshoot 11gR2 Installation Issue [ID 1056322.1]
#  2) For location of oraInst.loc see chapter '2 Managing Oracle Homes' 
#     in "Oracle Universal Installer and OPatch User's Guide"
#     http://docs.oracle.com/cd/E18283_01/em.112/e12255/oui2_manage_oracle_homes.htm
#       /etc/oraInst.loc           : Linux Linux.PPC64 AIX
#       /var/opt/oracle/oraInst.loc: Solaris.SPARC Solaris.X64 HPUX HPIA HP.TRU64 Linux.IA64 Linux.xSeries
#  3) MOS 454442.1: Oracle default location of Oracle Inventory is <ORACLE_BASE>/../oraInventory
#     For SAP installations the better default location one of the following:
#     option 1: /oracle/oraInventory
#     option 2: <ORACLE_BASE>/oraInventory
#     We use option 1 as there should be only one inventory per host.
#     INVENTORY_LOCATION_OPT="INVENTORY_LOCATION=${tgt_ob_loc}/oraInventory"
#     INVENTORY_LOCATION_OPT="INVENTORY_LOCATION=/oracle/oraInventory"
# #############################################################################
# Report a warning if no inventory pointer file exists
# Reason: OUI RC=-2
# Oracle Universal Installer finished with return code -2.
# From the install log:
# INFO: INFO: Validating state <inventoryPage>
# INFO: INFO: Checking whether the given inventory location /oraInventory is user home or not...
# INFO: INFO: OUI-10036:Could not create the inventory location. Ensure that you have sufficient permission to write this location, the directory names do not exceed the operating system limits, and the directory names contain valid characters, which consist of alphanumeric characters (|A|-|Z|, |a|-|z|, |0|-|9|) and the dollar sign ( $ ) or underscore ( _ ).
# INFO: SEVERE: [FATAL] [INS-32031] Invalid inventory location.
# INFO:    CAUSE: Inventory location was invalid.
# INFO:    ACTION: Specify a valid inventory location.
# INFO: SEVERE: [FATAL] [INS-32033] Central Inventory location is not writable.
# INFO:    CAUSE: Central Inventory location was not writable.
# INFO:    ACTION: Ensure that the inventory location is writable.
# INFO: INFO: Advice is ABORT
# INFO: INFO: Adding ExitStatus INVALID_USER_INPUT to the exit status set
# INFO: INFO: Completed validating state <inventoryPage>
# #############################################################################

# Check whether inventory pointer file exists
oui_invptr_file_exists="${STR_FALSE}"
INVENTORY_LOCATION_OPT="#INVENTORY_LOCATION="
for iloc in $ORAINST_LOCATION $oui_invptr_file
do
  if [ -f ${iloc} ]; then
    echo_std "${MSG_OKOK}" "Inventory pointer file ${iloc} exists."
    oui_invptr_file_exists="${STR_TRUE}"
  else
    MSGWARNS "Inventory pointer file ${iloc} does not exist."
    rct_ohp=$RC_WARN
  fi
done
if [ "${oui_invptr_file_exists}" = "${STR_FALSE}" ]; then
  echo_std "${MSG_OKOK}" "You are starting your first Oracle installation on this host."
  INVENTORY_LOCATION_OPT="INVENTORY_LOCATION=${invloc_path}"
fi

# #############################################################################
# Checking OS groups dba, oper, oinstall
# #############################################################################
MSGFREEV "Checking OS groups ..."

if [ -f $group_file ]; then
  for i in $osgroup_dba $osgroup_oper $osgroup_backupdba $osgroup_dgdba $osgroup_kmdba $osgroup_racdba
  do
    group_check $i
    group_check_rc=$?
    case $group_check_rc in
      0)
        echo_std "${MSG_OKOK}" "OS group $i is defined."
        ;;
      1)
        MSGWARNS "OS group $i is not defined."
        ;;
      *)
        MSGWARNS "Could not check existence of OS group $i."
        ;;
    esac
  done

  if [ $group_inventory = ${osgroup_install} ]; then
    i=${osgroup_install}
    group_check $i
    group_check_rc=$?
    case $group_check_rc in
      0)
        echo_std "${MSG_OKOK}" "OS group $i is defined."
        ;;
      1)
        MSGWARNS "OS group $i is not defined."
        rct_ohp=$RC_WARN
        ;;
      *)
        MSGWARNS "Could not check existence of OS group $i."
        rct_ohp=$RC_WARN
        ;;
    esac
  fi
else
  echo_std "Can not check existence of OS groups because $group_file is missing."
fi

# #############################################################################
# Searching Oracle home image file
# #############################################################################

if [ "${ora_stage_search}" = "${STR_YES}" ]; then
  #############################################################################
  # search Oracle home gold image in SAP default location (SAP DVD, enabled for 19c)
  #############################################################################
  ora_image_file_found="${STR_NO}"
  ora_image_file_path=""
  
  MSGFREEV "Oracle home image file        : searching ..."
  MSGFREEV "Oracle home image file path   : ${ora_image_file_path}"
  MSGFREEV "Oracle home image file name   : ${ORA_GOLD_IMAGE_FILE_L}"
  MSGFREEV "Oracle home image file found  : ${ora_image_file_found}"
  MSGFREEV "Oracle home image file custom : ${ora_image_file_cust}"

  for ora_search_path in ${ora_stage_loc_1} ${ora_stage_loc_2}
  do
    if [ -n "${ora_search_path}" ]; then
      MSGFREEV "Checking location ${ora_search_path}"
      if [ ora_image_file_found="${STR_NO}"  ]; then
        MSGFREEV "Searching Oracle home image file ${ORA_GOLD_IMAGE_FILE_L} in location/directory ${ora_search_path}"
        if [ -f ${ora_search_path}/${ORA_GOLD_IMAGE_FILE_L} ]; then
          # Oracle home image file found
          ora_image_file_path=${ora_search_path}/${ORA_GOLD_IMAGE_FILE_L}
          ora_image_file_found="${STR_YES}"
          MSGFREEV "Oracle home image file found: $ora_image_file_path"
        else
          # Oracle home image file not found
          MSGFREEV "Oracle home image file not found."
        fi
      else
        MSGFREEV "Oracle home image file location is already known."
      fi
    fi
  done
  MSGFREEV "Oracle home image file        : search result"
  MSGFREEV "Oracle home image file path   : ${ora_image_file_path}"
  MSGFREEV "Oracle home image file name   : ${ORA_GOLD_IMAGE_FILE_L}"
  MSGFREEV "Oracle home image file found  : ${ora_image_file_found}"
  MSGFREEV "Oracle home image file custom : ${ora_image_file_cust}"
  MSGFREEV "Searching Oracle home image file completed."
else
  #############################################################################
  # Oracle home gold image (user specified location)
  #############################################################################
  
  MSGFREEV "Oracle home image file        : checking path"
  MSGFREEV "Oracle home image file path   : ${ora_image_file_path}"
  MSGFREEV "Oracle home image file dir    : ${ora_image_file_diry}"
  MSGFREEV "Oracle home image file name   : ${ora_image_file_name}"
  
  if [ -n "${ora_image_file_path}" ] && [ -f "${ora_image_file_path}" ]; then
    # Oracle home image file found
    ora_image_file_found="${STR_YES}"
  else
    # Oracle home image file not found
    ora_image_file_found="${STR_NO}"
    MSGERRRS "Oracle home image file not found: ${ora_image_file_path}"
    install_exit $RC_PREREQ_ERROR
  fi
  MSGFREEV "Oracle home image file        : checking result"
  MSGFREEV "Oracle home image file found  : ${ora_image_file_found}"
  MSGFREEV "Oracle home image file custom : ${ora_image_file_cust}"
fi


## #############################################################################
## Calculating sha256sum -> moved to -ohextract (option '-sha256sum')
## #############################################################################
#if [ "${ora_chksum_check}" = "${STR_YES}" ]; then
#  echo_std "Calculating sha256sum for Oracle home image file ..."
#  MSGFREEV "This can take a while, please wait ..."
#  show_arg_list_1 "sha256sum" "$ora_image_file_path" "| awk '{print \$1}'"
#  ora_chksum_value=`sha256sum $ora_image_file_path    | awk '{print $1}'`
#  rc_last=$?
#  if [ $rc_last -ne 0 ]; then
#    echo_std "$MSG_ERRR" "Calculating sha256sum for Oracle home image file failed (rc=$rc_last)."
#  else
#    MSGINFOV "Calculating sha256sum for Oracle home image file finished successfully."
#    MSGFREEV "sha256sum (reference) : $ora_chksum_reference"
#    MSGFREEV "sha256sum (calculated): $ora_chksum_value"
#    ora_chksum_is_checked="${STR_YES}"
#    if [ "${ora_chksum_value}" = "${ora_chksum_reference}" ]; then
#      ora_chksum_is_valid="${STR_YES}"
#      echo_std "${MSG_OKOK}" "Check sum value is valid, Oracle home image file is valid."
#    else
#      MSGERRRS "Check sum value is different from reference value."
#      MSGERRRS "Oracle home image file might be corrupted."
#    fi
#  fi
#fi


# #############################################################################
# Searching Oracle runInstaller
# #############################################################################
MSGFREEV "Searching Oracle runInstaller ..."

ora_runinstaller_found="${STR_NO}"
ora_runinstaller_path=""

# search in Oracle Stage
for ora_search_path in ${ora_stage_loc_1} ${ora_stage_loc_2}
do
  if [ -n "${ora_search_path}" ]; then
    [ ora_runinstaller_found="${STR_NO}" ] && MSGFREEV "Searching Oracle runInstaller in location ${ora_search_path} ..."
    [ ora_runinstaller_found="${STR_NO}" ] && [ -f ${ora_search_path}/${ora_runinstaller_file} ] && ora_runinstaller_path=${ora_search_path}/${ora_runinstaller_file} && ora_runinstaller_found="${STR_YES}"
    [ ora_runinstaller_found="${STR_NO}" ] || MSGFREEV "Oracle runInstaller found: $ora_runinstaller_path"
    MSGFREEV "Oracle stage path             : $ora_search_path"
    MSGFREEV "Oracle runInstaller path      : $ora_runinstaller_path"
    MSGFREEV "Oracle runInstaller file found: $ora_runinstaller_found"
  fi
done

# #############################################################################
# Started from Oracle DVD or from extracted Oracle Home?
# #############################################################################
if [ "${ora_image_file_found}" = "${STR_YES}" ] && [ "${ora_image_file_cust}" = "${STR_NO}" ]; then
  flag_dvd="${STR_YES}"
  MSGFREEV "Script is started from Oracle Software DVD"
fi
if [ "${ora_runinstaller_found}" = "${STR_YES}" ]; then
  flag_eoh="${STR_YES}"
  MSGFREEV "Script is started from extracted Oracle home"
fi
#if [ "${flag_dvd}" = "${STR_YES}" ] && [ "${flag_eoh}" = "${STR_YES}" ]; then
#  MSGERRRS "Strange: Found Oracle image file inside extracted Oracle home."
#  install_exit $RC_PREREQ_ERROR
#fi

# #############################################################################
# Searching Oracle runInstaller
# #############################################################################
MSGFREEV "Searching Oracle runInstaller ..."

# search in extracted Oracle Home
for ora_search_path in ${tgt_oh_loc}
do
  if [ -n "${ora_search_path}" ]; then
    [ ora_runinstaller_found="${STR_NO}" ] && MSGFREEV "Searching Oracle runInstaller in location ${ora_search_path} ..."
    [ ora_runinstaller_found="${STR_NO}" ] && [ -f ${ora_search_path}/${ora_runinstaller_file} ] && ora_runinstaller_path=${ora_search_path}/${ora_runinstaller_file} && ora_runinstaller_found="${STR_YES}"
    [ ora_runinstaller_found="${STR_NO}" ] || MSGFREEV "Oracle runInstaller found: $ora_runinstaller_path"
    MSGFREEV "Oracle runInstaller path      : $ora_runinstaller_path"
    MSGFREEV "Oracle runInstaller file found: $ora_runinstaller_found"
  fi
done

# #############################################################################
# Checking whether Oracle home is already extracted
# #############################################################################
MSGFREEV "Checking whether Oracle home is already extracted ..."
if [ -n "${tgt_oh_loc}" ] && [ -d "${tgt_oh_loc}" ] && [ -f ${tgt_oh_loc}/bin/oracle ]; then
  flag_ohx="${STR_YES}"
  echo_std "${MSG_OKOK}" "Oracle home image file is already extracted."
fi

# #############################################################################
# Checking version of Oracle runInstaller
# #############################################################################
if [ "${flag_ohx}" = "${STR_YES}" ]; then
  # Oracle home image file is already extracted
  MSGFREEV "Checking version of Oracle runInstaller ..."
  getOUIVersion "$tgt_oh_loc"
  rc_last=$?
  if [ $rc_last -eq 0 ]; then
    OUI_VERSION_REAL_5="$OUI_VERSION_REAL_0"
    OUI_VERSION_REAL_4="`expr substr ${OUI_VERSION_REAL_5} 1 8`"
    OUI_VERSION_RFRC_4="`expr substr ${OUI_VERSION_RFRC_5} 1 8`"
    MSGINFOV "runInstaller version found    : $OUI_VERSION_REAL_4 ($OUI_VERSION_REAL_5)"
    MSGINFOV "runInstaller version reference: $OUI_VERSION_RFRC_4 ($OUI_VERSION_RFRC_5)"
    if [ "${OUI_VERSION_REAL_4}" = "${OUI_VERSION_RFRC_4}" ]; then
      echo_std "${MSG_OKOK}" "Version of Oracle runInstaller is valid (${OUI_VERSION_REAL_5})."
    else
      MSGWARNS "Version of Oracle runInstaller is invalid."
      MSGWARNS "Version found   : ${OUI_VERSION_REAL_5} / ${OUI_VERSION_REAL_4}"
      MSGWARNS "Version expected: ${OUI_VERSION_RFRC_5} / ${OUI_VERSION_RFRC_4}"
      rct_ohp=$RC_WARN
    fi
  else
    MSGWARNS "Version of Oracle runInstaller could not be determined - expecting version ${OUI_VERSION_RFRC_5}."
    rct_ohp=$RC_WARN
  fi
fi

# #############################################################################
# Checking version of <ORACLE_HOME>/bin/oraversion
# #############################################################################
# ./oraversion -help
# This program prints release version information.
# These are its possible arguments:
# -compositeVersion: Print the full version number: a.b.c.d.e.
# -baseVersion: Print the base version number: a.0.0.0.0.
# -majorVersion: Print the major version number: a.
# -buildStamp: Print the date/time associated with the build.
# -buildDescription: Print a description of the build.
# -help: Print this message.

oraversion_compositeversion=""
oraversion_builddescription=""
if [ "${flag_ohx}" = "${STR_YES}" ]; then
  # Oracle home image file is already extracted
  MSGFREEV "Checking version of extracted Oracle home (oraversion) ..."
  oraversion_compositeversion=`$tgt_oh_loc/bin/oraversion -compositeVersion` || oraversion_compositeversion=""
  oraversion_builddescription=`$tgt_oh_loc/bin/oraversion -buildDescription` || oraversion_builddescription=""
fi
MSGINFOV "Oracle home version:          : ${oraversion_compositeversion} (${oraversion_builddescription})"

# #############################################################################
# Checking whether Oracle home is already registered
# #############################################################################
MSGFREEV "Checking whether Oracle home is already registered ..."
#[ -n "${tgt_oh_loc}" ]          && MSGFREEV "${tgt_oh_loc} name is not empty"
#[ -d "${tgt_oh_loc}" ]          && MSGFREEV "${tgt_oh_loc} directory exists"
#[ -f ${tgt_oh_loc}/bin/oracle ] && MSGFREEV "${tgt_oh_loc}/bin/oracle exists"
#[ -x ${tgt_oh_loc}/bin/oracle ] && MSGFREEV "${tgt_oh_loc}/bin/oracle is executable"
#[ -s ${tgt_oh_loc}/bin/oracle ] && MSGFREEV "${tgt_oh_loc}/bin/oracle is not empty"
if [ -n "${tgt_oh_loc}" ] && [ -d "${tgt_oh_loc}" ] && [ -s ${tgt_oh_loc}/bin/oracle ] && [ -x ${tgt_oh_loc}/bin/oracle ]; then
  flag_ohr="${STR_YES}"
  echo_std "${MSG_OKOK}" "Oracle home is already registered."
fi

# #############################################################################
# Checking whether root.sh has already executed or not
# #############################################################################
# $ /oracle/DQ1/18.0.0/root.sh
# Check /oracle/DQ1/18.0.0/install/root_wdflbmd22080_2018-09-25_09-15-49-006344153.log for the output of root script
# $ ls -l /oracle/DQ1/18.0.0/install/root_*
# -rwxr-xr-x 1 oracle oinstall 836 Sep 24 17:03 /oracle/DQ1/18.0.0/install/root_schagent.sh
# -rw------- 1 oracle oinstall 595 Sep 25 09:15 /oracle/DQ1/18.0.0/install/root_wdflbmd22080_2018-09-25_09-15-49-006344153.log
# $ 
# #############################################################################

MSGFREEV "Checking whether root.sh has already executed ..."
MSGFREEV "Searching for root.sh log files in ${tgt_oh_loc}/install named root_<hostname>_YYYY-MM-DD_HH-MM-SS.log"
last_cmd_out=`ls -l ${tgt_oh_loc}/install/root_*.log > /dev/null 2>&1`
rc_os_cmd=$?
MSGFREEV "$last_cmd_out"
if [ $rc_os_cmd -ne 0  ]; then
  flag_ohroot="${STR_NO}"
  MSGINFOV "${tgt_oh_loc}/root.sh was not yet executed."
else
  flag_ohroot="${STR_YES}"
  MSGINFOV "${tgt_oh_loc}/root.sh was already executed."
fi

# #############################################################################
# Checking whether Runtime Oracle home is configured
# #############################################################################
MSGFREEV "Checking whether Oracle home is already configured for SAP ..."
if [ -h ${tgt_oh_link} ]; then
  # Link for runtime Oracle home exists
  flag_ohs="${STR_YES}"
  echo_std "${MSG_OKOK}" "Oracle home is already configured for SAP."
fi

# #############################################################################
# Perform pre-installation clean up tasks
# #############################################################################
MSGFREEV "Performing Pre-Installation clean-up tasks ..."

if [ -n "${oui_log_file}" ] && [ -f "${oui_log_file}" ]; then
  rm ${oui_log_file}
  rm_rc=$?
  if [ -f ${oui_log_file} ]; then
    MSGERRRS "Failed to remove OUI output log file ${oui_log_file} (RC=${rm_rc})."
  else
    echo_std "${MSG_OKOK}" "OUI output log file ${oui_log_file} removed successfully."
  fi
fi

# check whether out_log_file is needed
if [ -z "${tee_cmd}" ]; then 
  # if tee_cmd or tee_pipe are empty, then the output of Oracle installer is not tee'd to the output log file
  MSGINFOS "OUI output log file reset."
  oui_log_file=""
fi

if [ -n "${rspf_file}" ] && [ -f "${rspf_file}" ]; then
  rm ${rspf_file}
  rm_rc=$?
  if [ -f ${rspf_file} ]; then
    MSGERRRS "Failed to remove old OUI response file ${rspf_file} (RC=${rm_rc})."
    install_exit $RC_PREREQ_ERROR
  else
    echo_std "${MSG_OKOK}" "OUI response file ${rspf_file} removed successfully."
  fi
fi

MSGFREEV "Pre-Installation clean-up tasks completed."

# #############################################################################
# Creating response file
# #############################################################################
MSGFREEV "Creating response file ..."

dir_to_check=${rspf_dir}
if CanCreateFileIn ${dir_to_check}; then
	:
else
	echo_std  "${MSG_WARN}" "Write permissions for directory ${dir_to_check} missing."
	rct_ohp=$RC_WARN
fi

cat<<EOF >"${rspf_file}"
#####################################################################
## ${script_bnnr}
## ${script_copy}
##
## Generated by ${script_name} ${script_vers} (${script_plvl}) ${script_date}
##
## SAP note ${script_note}
## Oracle Database Release: ${ORACLE_RELEASE_LONG}
## Platform               : ${platform}
## Date                   : ${run_date} ${run_time}
#####################################################################
#####################################################################
## Response file version
#####################################################################
oracle.install.responseFileVersion=/oracle/install/rspfmt_dbinstall_response_schema_v19.0.0
#####################################################################
## Configuration Option
#####################################################################
oracle.install.option=INSTALL_DB_SWONLY
#####################################################################
## Database Edition
#####################################################################
oracle.install.db.InstallEdition=EE
#####################################################################
## Installation Location
#####################################################################
ORACLE_BASE=${tgt_ob_loc}
#####################################################################
## Operating system groups for Oracle administrative privileges
#####################################################################
oracle.install.db.OSDBA_GROUP=${osgroup_dba}
oracle.install.db.OSOPER_GROUP=${osgroup_oper}
oracle.install.db.OSBACKUPDBA_GROUP=${osgroup_backupdba}
oracle.install.db.OSDGDBA_GROUP=${osgroup_dgdba}
oracle.install.db.OSKMDBA_GROUP=${osgroup_kmdba}
oracle.install.db.OSRACDBA_GROUP=${osgroup_racdba}
oracle.install.db.isRACOneInstall=false
#####################################################################
## Root Script Automation
#####################################################################
oracle.install.db.rootconfig.executeRootScript=${oui_rsa_option}
oracle.install.db.rootconfig.configMethod=${oui_rsa_method}
oracle.install.db.rootconfig.sudoUserName=${oui_rsa_sudoun}
oracle.install.db.rootconfig.sudoPath=${oui_rsa_sudoph}

#####################################################################
## Others
#####################################################################
ORACLE_HOSTNAME=${run_host}
UNIX_GROUP_NAME=${group_inventory}
SELECTED_LANGUAGES=en
${INVENTORY_LOCATION_OPT}
#####################################################################
## My Oracle Support
#####################################################################
SECURITY_UPDATES_VIA_MYORACLESUPPORT=false
DECLINE_SECURITY_UPDATES=true
oracle.installer.autoupdates.option=SKIP_UPDATES
EOF

if [ -f ${rspf_file} ]; then
  echo_std "${MSG_OKOK}" "New response file ${rspf_file} created."
  # Change permissions on response file 
  chmod 664 ${rspf_file}
else 
  MSGERRRS "New response file ${rspf_file} could not be created."
  MSGERRRS "Check permissions."
  install_exit $RC_ERRR # $RC_PREREQ_ERROR
fi

# run with or without responsefile?
if [ "$oui_rsp_use" = "no" ]; then
	oui_rsp_opt=""
  oui_rsp_file=""
else
  oui_rsp_opt="-responseFile"
  oui_rsp_file="${rspf_file}"
fi

# create responsefile only?
if [ "$oui_rsp_create" = "yes" ]; then
  MSGINFOS "OUI response file ${rspf_file} has been created."
  install_exit $RC_SUCC
fi

# #############################################################################
# Pre-installation checks
# #############################################################################
echo_std
echo_std "Pre-Installation Checks completed."
echo_std

###############################################################################
#                                                                             #
#                     END TASK: -ohprepare                                    #
#                                                                             #
###############################################################################
[ $opt_ohp = ${STR_YES} ] && MSGINFOV "rct_ohp=$rct_ohp"

###############################################################################
#                                                                             #
#                     BGN TASK: -ohverify                                     #
#                                                                             #
###############################################################################
dsc_cur="${dsc_ohv}"
[ $opt_ohi = ${STR_NO}  ] && [ $opt_ohm = ${STR_NO} ] && [ $opt_ohs = ${STR_NO} ] && [ $opt_ohr = ${STR_NO} ] && [ $opt_ohc = ${STR_NO} ] && [ $opt_ohx = ${STR_NO} ] && [ $opt_ohv = ${STR_NO} ] && install_exit $RC_SUCC
[ $opt_ohv = ${STR_YES} ] && MSGINFOS "TASK - $dsc_ohv" && run_ohv="${STR_YES}"
[ $opt_ohv = ${STR_YES} ] && MSGDATETIME "${dsc_cur}"
[ $opt_ohv = ${STR_NO}  ] && MSGINFOS "TASK - $dsc_ohv - ${dsc_dnr}"
[ $opt_ohv = ${STR_YES} ] && rct_ohv=$rct_ini

if [ $opt_ohv = $STR_YES ]; then
  # ###########################################################################
  # Verify Installation Settings
  # ###########################################################################
  if [ "${verbose_mode}" = "${STR_DISABLED}" ]; then
    # show these flags only in verbose mode
    tgt_ob_loc_flag=""
    tgt_oh_loc_flag=""
    tgt_oh_link_flag=""
    oratabfile_flag=""
  fi
  
  echo_std
  echo_std "Starting point:"
  echo_std
  # RUNINSTALLER was started from Oracle Software DVD or from inside of an extracted Oracle home
  [ "${flag_dvd}" = "${STR_YES}"  ] && MSGFREES "Started from Oracle Software DVD: ${flag_dvd:-${STR_NOT_SET}}"
  [ "${flag_eoh}" = "${STR_YES}"  ] && MSGFREES "Started from Oracle home     : ${flag_eoh:-${STR_NOT_SET}}"

  # Location of Oracle home image file
  MSGFREES "Oracle home image file       : ${ora_image_file_path:-${STR_NOT_SET}}"
  MSGFREES "Oracle home image name       : ${ora_image_file_name:-${STR_NOT_SET}}"
  MSGFREES "Oracle home image directory  : ${ora_image_file_diry:-${STR_NOT_SET}}"
  MSGFREES "User specified?              : ${ora_image_file_cust:-${STR_NOT_SET}}"  
  
  # Checksum verification of Oracle home image file
  MSGFREES "Checksum has been verified?  : ${ora_chksum_is_checked:-${STR_NOT_SET}}"
  MSGFREES "Checksum is ok?              : ${ora_chksum_is_valid:-${STR_NOT_SET}}"

  # Location of Oracle runinstaller
  [ -n "${ora_runinstaller_path}" ] && echo_std "Oracle runInstaller location : ${ora_runinstaller_path:-${STR_NOT_SET}}"
  
  # Location of Oracle stage
 #[ -n "${ora_image_file_path}"   ] || echo_std "Oracle stage location        : ${ora_stage_loc_0:-${STR_NOT_SET}}"
 #[ -n "${ora_image_file_path}"   ] || echo_std "Oracle stage location        : ${ora_stage_loc_1:-${STR_NOT_SET}}"
 #[ -n "${ora_image_file_path}"   ] || echo_std "Oracle stage location        : ${ora_stage_loc_2:-${STR_NOT_SET}}"
  
  echo_std
  echo_std "Environment Variables:"
  echo_std
  echo_std "DB_SID                       : ${DB_SID:-${STR_NOT_SET}}"
  echo_std "DISPLAY                      : ${DISPLAY:-${STR_NOT_SET}}"
  echo_std "ORACLE_BASE                  : ${ORACLE_BASE:-${STR_NOT_SET}}"
  echo_std "ORACLE_HOME                  : ${ORACLE_HOME:-${STR_NOT_SET}}"
  echo_std "CV_ASSUME_DISTID             : ${CV_ASSUME_DISTID:-${STR_NOT_SET}}"
case $platform in
  aix            )  
  echo_std "SKIP_ROOTPRE                 : ${SKIP_ROOTPRE:-${STR_NOT_SET}}"  
  ;;
esac
  
  echo_std
  echo_std "Installation Task:"
  echo_std
  echo_std "Preparing the Installation   : ${opt_ohp:-${STR_NOT_SET}}" # dsc_ohp
  echo_std "Verifying Install Settings   : ${opt_ohv:-${STR_NOT_SET}}" # dsc_ohv
  echo_std "Extracting Oracle Home       : ${opt_ohx:-${STR_NOT_SET}}" # dsc_ohx
  echo_std "Checking Prerequisites       : ${opt_ohc:-${STR_NOT_SET}}" # dsc_ohc
  echo_std "Registering Oracle Home      : ${opt_ohr:-${STR_NOT_SET}}" # dsc_ohr
  echo_std "Configuring for SAP          : ${opt_ohs:-${STR_NOT_SET}}" # dsc_ohs
 #echo_std "Installing SAP Bundle Patch  : ${opt_ohm:-${STR_NOT_SET}}" # dsc_ohm # commented 2018-12-05 | 18-016
  
  echo_std
  echo_std "Installation Status:"
  echo_std
  echo_std "Oracle Home is extracted     : ${flag_ohx:-${STR_NOT_SET}}"
  echo_std "Oracle Home is registered    : ${flag_ohr:-${STR_NOT_SET}}"
  echo_std "OHRDBMS is configured for SAP: ${flag_ohs:-${STR_NOT_SET}}"
  echo_std
  # if [ "${flag_ohx}" = "${STR_YES}" ]; then
  echo_std "Oracle Home Version          : ${oraversion_compositeversion:-${STR_NOT_SET}} ${oraversion_builddescription:-${STR_NOT_SET}}"
  echo_std "root.sh already executed?    : ${flag_ohroot:-${STR_NOT_SET}}"
  # fi
  echo_std
  echo_std "Installation Settings:"
  echo_std
  echo_std "Image file extraction        : ${OS_UNZIP_CMD} ${OS_UNZIP_OPT} <image file> (${opt_extract_mode_verbose} ${opt_extract_mode_new})"
  echo_std "UnZip tool path              : ${OS_UNZIP_PATH:-${STR_NOT_SET}}"
  echo_std "UnZip tool banner            : ${OS_UNZIP_BANNER:-${STR_NOT_SET}}"
  echo_std "Oracle Database Release      : ${ORACLE_RELEASE_LONG:-${STR_NOT_SET}}"
  echo_std "ORACLE_BASE                  : ${tgt_ob_loc}  ${tgt_ob_loc_flag}"
  echo_std "ORACLE_HOME IHRDBMS (install): ${tgt_oh_loc}  ${tgt_oh_loc_flag}"
  echo_std "ORACLE_HOME OHRDBMS (runtime): ${tgt_oh_link} ${tgt_oh_link_flag}"
  echo_std "ORACLE_HOME_NAME             : ${ORACLE_HOME_NAME:-${STR_NOT_SPECIFIED}}"
  echo_std "oratab                       : ${oratabfile} ${oratabfile_flag}"
  [ -n "${tgt_db_sid}" ] && [ -n "${tgt_oh_link}" ] && echo_std "oratab new entry             : ${tgt_db_sid}:${tgt_oh_link}:N"
  
  echo_std
  echo_std "Oracle Home Administrative OS Groups:"
  echo_std
  echo_std "Inventory group              : ${group_inventory}"
  echo_std "OSDBA group (SYSDBA)         : ${osgroup_dba:-${STR_NOT_SPECIFIED}}"
  echo_std "OSOPER group (SYSOPER)       : ${osgroup_oper:-${STR_NOT_SPECIFIED}}"
  echo_std "OSBACKUPDBA group (SYSBACKUP): ${osgroup_backupdba:-${STR_NOT_SPECIFIED}}"
  echo_std "OSDGDBA group (SYSDG)        : ${osgroup_dgdba:-${STR_NOT_SPECIFIED}}"
  echo_std "OSKMDBA group (SYSKM)        : ${osgroup_kmdba:-${STR_NOT_SPECIFIED}}"
  echo_std "OSRACDBA group (SYSRAC)      : ${osgroup_racdba:-${STR_NOT_SPECIFIED}}"
  
  echo_std
  echo_std "${STR_OUI_NAME_0} Settings:"
  echo_std
  echo_std "Installer location           : ${ora_runinstaller_path:-${STR_NOT_SET}}"
  echo_std "Version (oraparam.ini)       : ${OUI_VERSION_REAL_0}"
  echo_std "Temporary directory          : ${tmp_dir_full}"
  echo_std "Temporary error file         : ${tmp_dir_errfile}"
  echo_std "                               Available disk space: ${tmp_dir_base_free} ${DF_UNIT}"
  echo_std "Response file                : ${rspf_file:-${STR_NOT_SET}}"
  echo_std "Use response file            : ${oui_rsp_use}"
  echo_std "Output log file              : ${oui_log_file:-${STR_NOT_SET}}"
  echo_std "Options                      : ${oui_wait_option} ${oui_nolink_mode} ${silent_mode} ${silent_mode_progress} ${flag_debug_mode_oui} ${oui_ignorePrereq_1} ${oui_ignorePrereq_2} ${oui_executePrereqs} ${ignoreInternalDriverError} ${oui_lang_option}"
  echo_std "invPtrLoc option             : ${oui_invptrloc_option:-${STR_NOT_SET}}"
  echo_std "inventory location           : ${INVENTORY_LOCATION_OPT:-${STR_NOT_SET}}"
  echo_std "Ignore prereq check warnings : ${oui_ignorePrereq_wrn:-${STR_NOT_SET}} ($oui_ignorePrereq_1 / $oui_ignorePrereq_2)"

  echo_std
  echo_std "Root Script Automation Settings:"
  echo_std
                                      echo_std "RSA selected                 : ${oui_rsa_option:-${STR_DASH}}"
  if [ "${oui_rsa_option}" = "true" ]; then
                                      echo_std "RSA Method                   : ${oui_rsa_method:-${STR_DASH}}"
                                      echo_std "RSA password verification    : ${oui_rsa_option_verify:-${STR_DASH}}"
  [ "${oui_rsa_method}" = "ROOT" ] && echo_std "RSA root user                : ${oui_rsa_rootun}/${oui_rsa_rootpx:-${STR_DASH}}"
  [ "${oui_rsa_method}" = "SUDO" ] && echo_std "RSA sudo user                : ${oui_rsa_sudoun}/${oui_rsa_sudopx:-${STR_DASH}}"
  [ "${oui_rsa_method}" = "SUDO" ] && echo_std "RSA sudo path                : ${oui_rsa_sudoph:-${STR_DASH}}"
  fi

  echo_std
  echo_std "Patch Installation Settings:"
  echo_std
  echo_std "Apply OneOffs                : ${opt_applyOO_strg} ${opt_applyOO_path:-${STR_NOT_SET}}"
  echo_std "Apply RU                     : ${opt_applyRU_strg} ${opt_applyRU_path:-${STR_NOT_SET}}"
  if [ "${opt_opatchloc_flag}" = "${STR_YES}" ]; then
  echo_std "Use OPatch from here         : ${opt_opatchloc_strg} ${opt_opatchloc_path:-${STR_NOT_SET}} ${opt_opatch_s_o_v_c_strg}"
  fi
  
  echo_std
  echo_std "Post Installation Settings:"
  echo_std
  echo_std "Create symbolic link         : ${sym_link_create_opt}"
  if [ "${sym_link_create_opt}" = "yes" ]; then
    echo_std "relative/absolute path       : ${sym_link_path}"
    if [ "${sym_link_path}" = "relative" ]; then
      echo_std "OHRDBMS -> IHRDBMS             $tgt_oh_link -> $tgt_oh_dirname"
    else
      echo_std "OHRDBMS -> IHRDBMS             $tgt_oh_link -> $tgt_oh_loc"
    fi
  fi
  [ "${opt_orabasetab}"      = "yes" ] && echo_std "Configure orabasetab         : ${opt_orabasetab}"
  [ "${opt_cleanup_tmp}"     = "yes" ] && echo_std "Clean up temp. files         : ${opt_cleanup_tmp}"
  [ "${opt_opatch_chk}"      = "yes" ] && echo_std "Check installed patches      : ${opt_opatch_chk}"
  
  echo_std
  echo_std "Installation Log File Settings:"
  echo_std
  echo_std "Installation Log Directory   : ${install_base_dir:-${STR_NOT_SET}}"
  echo_std "Installation Log File        : ${sap_log_file_single:-${STR_NOT_SET}}"
  echo_std "Installation Summary Log File: ${sap_log_file_summary:-${STR_NOT_SET}}"
  echo_std
fi

###############################################################################
#                                                                             #
#                     END TASK: -ohverify                                     #
#                                                                             #
###############################################################################
[ $opt_ohv = ${STR_YES} ] && rct_ohv=$RC_SUCC && MSGINFOV "rct_ohv=$rct_ohv"

###############################################################################
#                                                                             #
#                     BGN TASK: -ohextract                                    #
#                                                                             #
###############################################################################
dsc_cur="${dsc_ohx}"
[ $opt_ohi = ${STR_NO}  ] && [ $opt_ohm = ${STR_NO} ] && [ $opt_ohs = ${STR_NO} ] && [ $opt_ohr = ${STR_NO} ] && [ $opt_ohc = ${STR_NO} ] && [ $opt_ohx = ${STR_NO} ] && install_exit $RC_SUCC
[ $opt_ohx = ${STR_YES} ] && MSGINFOS "TASK - $dsc_ohx" && run_ohx="${STR_YES}"
[ $opt_ohx = ${STR_YES} ] && MSGDATETIME "${dsc_cur}"
[ $opt_ohx = ${STR_NO}  ] && MSGINFOS "TASK - $dsc_ohx - ${dsc_dnr}"
[ $opt_ohx = ${STR_YES} ] && rct_ohx=$rct_ini

###############################################################################
# References:
# https://superuser.com/questions/216617/view-list-of-files-in-zip-archive-on-linux
###############################################################################
[ $opt_ohx = $STR_YES ] && [ "${query_mode}" = "${STR_ENABLED}" ] && MSGINFOS "Query mode enabled - nothing to do"
if [ $opt_ohx = $STR_YES ] && [ "${query_mode}" = "${STR_DISABLED}" ] ; then
  # #############################################################################
  # Calculating sha256sum (option '-sha256sum') - File Integrity Check
  # 
  # References: 
  #   Oracle Support Document 549617.1 (How to Verify the Integrity of a Patch)
  #   https://support.oracle.com/epmos/faces/DocumentDisplay?id=549617.1
  # #############################################################################
  if [ "${ora_chksum_check}" = "${STR_YES}" ]; then
    MSGINFOS "Calculating sha256sum for Oracle home image file ..."
    MSGFREEV "This can take a while, please wait ..."
    
    # Way of calculation is platform dependent
    case $platform in
      linux_x86_64   ) 
        # (sha256sum - c96a4fd768787af98272008833fe10b172691cf84e42816b138c12d4de63ab96)
        show_arg_list_1 "sha256sum" "$ora_image_file_path" "| awk '{print \$1}'"
        ora_chksum_value=`sha256sum $ora_image_file_path    | awk '{print $1}'`
        rc_last=$?
        ;;
      aix            ) 
        # (sha256sum - bbd37e23a977aaa7c5cc1d8b50062b92cecd0a8960f79b05b1edaf614d843e1b)
        # References (AIX):
        # http://ibmsystemsmag.com/aix/administrator/systemsmanagement/file-integrity/
        # https://www.unix.com/aix/261344-sha-256-base-64-encryption.html
        # http://www-01.ibm.com/support/docview.wss?uid=swg21496703
        # https://www-01.ibm.com/support/docview.wss?uid=isg1SSRVPOAIX61SECURITY150618-1709
        # Options: 
        #   csum -h SHA1 <complete_path_of_file_name>
        #   openssl dgst -sha256 <complete_path_of_file_name>
        #   shasum -a 256 <complete_path_of_file_name>
        #   sha256sum <complete_path_of_file_name>
        #   fciv -md5 <complete_path_of_file_name>
        #   fciv -sha1 <complete_path_of_file_name>
        MSGINFOS "Not implemented for this platform \"$platform\"."
        rc_last=1
        ;;
      hp_ux_ia64     )
        # (sha256sum - 5ef20634566cf5cfd2c0ff20ca2dc5ff5a28e7e632b68ddaa5722f88f4f0654a)
        # Example:
        #   $ openssl dgst -sha256 /tmp/HPUX.IA64_180000_db_home.zip 
        #   SHA256(/tmp/HPUX.IA64_180000_db_home.zip)= 1749f1137ca9713333214b0c847971ce1ae52c46d13ef3b21f703a37b6100d36
        show_arg_list_1 "openssl dgst -sha256" "$ora_image_file_path" "| awk '{print \$2}'"
        ora_chksum_value=`openssl dgst -sha256 $ora_image_file_path    | awk '{print $2}'`
        rc_last=$?
        ;;
      sunos_sun4u    )
        # (sha256sum - fe9df9484bbd069f3856716ac9f75f8dd1c4b67abf7435fc0ef8604b792ab270)
        show_arg_list_1 "digest -a sha256" "$ora_image_file_path" "| awk '{print \$1}'"
        ora_chksum_value=`digest -a sha256 $ora_image_file_path    | awk '{print $1}'`
        rc_last=$?
        ;;
      sunos_i86pc    )
        # (sha256sum - 743fda2ce4f96c7d6abc1ec600db0adfb516db9be97e1dd8b7ca01d6601a18d5)
        show_arg_list_1 "digest -a sha256" "$ora_image_file_path" "| awk '{print \$1}'"
        ora_chksum_value=`digest -a sha256 $ora_image_file_path    | awk '{print $1}'`
        rc_last=$?
        ;;
      *              )
        # other platforms
        MSGINFOS "Not implemented for this platform \"$platform\"."
        rc_last=1
        ;;
    esac
    
    # Check result
    if [ $rc_last -ne 0 ]; then
      MSGERRRS "Calculating sha256sum for Oracle home image file failed (rc=$rc_last)."
    else
      MSGINFOV "Calculating sha256sum for Oracle home image file finished successfully."
      MSGFREEV "sha256sum (reference) : $ora_chksum_reference"
      MSGFREEV "sha256sum (calculated): $ora_chksum_value"
      ora_chksum_is_checked="${STR_YES}"
      if [ "${ora_chksum_value}" = "${ora_chksum_reference}" ]; then
        ora_chksum_is_valid="${STR_YES}"
        MSGINFOS "Check sum value is valid, Oracle home image file is valid."
      else
        MSGERRRS "Check sum value is different from reference value."
        MSGERRRS "Oracle home image file might be corrupted."
        rct_ohx=$RC_ERRR
        install_exit $RC_ERRR
      fi
    fi
  fi

  #############################################################################
  # Remove Oracle Home Directory
  #############################################################################
  if [ "$opt_extract_mode_new" = "-xnew" ]; then
    if [ -d $tgt_oh_loc ]; then
      # Removing Oracle Home Directory
      MSGWARNS "Removing Oracle home directory ($tgt_oh_loc)."
      show_arg_list_1 rm -rf $tgt_oh_loc
      rm -rf $tgt_oh_loc
      rc_os_cmd=$?
      if [ $rc_os_cmd -ne 0 ]; then
        MSGERRRS "Removing Oracle home directory failed (rc=$rc_os_cmd)."
        rct_ohx=$RC_ERRR
        install_exit $RC_ERRR
      else 
        MSGWARNS "Oracle home directory removed ($tgt_oh_loc)."
      fi
    fi
  fi

  #############################################################################
  # Create Oracle Home Directory
  #############################################################################
  MSGINFOS "Oracle home directory: ${tgt_oh_loc}"
  if [ -d $tgt_oh_loc ]; then
    # Oracle home directory already exists
    echo_std "$MSG_WARN" "Oracle home directory already exists."
  else
    # Create Oracle Home Directory
    MSGINFOS "Creating Oracle home directory $tgt_oh_loc"
    mkdir -p $tgt_oh_loc
    rc_os_cmd=$?
    MSGFREEV "Last Returncode: $rc_os_cmd"
    if [ $rc_os_cmd -ne 0 ]; then
      MSGERRRS "Creating Oracle home directory failed (rc=$rc_os_cmd)."
      rct_ohx=$RC_ERRR
      install_exit $RC_ERRR
    else 
      MSGINFOS "Oracle home directory created."
    fi
  fi
  # Ensure that Oracle home directory is empty
  MSGINFOS "Oracle home directory: ${tgt_oh_loc}"
  if is_empty_dir "${tgt_oh_loc}"; then
    MSGINFOS "Oracle home directory is empty."
  else
    # Oracle home directory is not empty
    MSGINFOS "Oracle home directory is not empty."
    MSGINFOS "Oracle home contains the following files/directories:"
    ls -l ${tgt_oh_loc}
    ls -l ${tgt_oh_loc} >> $sap_log_file_single
    if [ "$flag_empty_dir_check" = "yes" ]; then
      # Oracle home directory is not empty: ERROR
      MSGERRRS "Oracle home directory is not empty - cannot continue."
      MSGERRRS "Cannot extract Oracle home image file into Oracle home directory that is not empty."
      MSGINFOS
      MSGINFOS "Option #1: skip extraction and continue with registration of Oracle home"
      MSGINFOS "  Rerun with option '-ohregister -ohsapcfg' to skip this step and continue the installation."
      MSGINFOS "Option #2: remove Oracle home directory, then rerun."
      MSGINFOS "Option #3: use option '-no_empty_dir_check' to extract Oracle Home Gold Image into non-empty Oracle Home."
      MSGINFOS "  This option can be used if a file system folder 'lost+found' exists in Oracle home."
      MSGINFOS
      rct_ohx=$RC_ERRR
      install_exit $RC_ERRR
    else
      # Oracle home directory is not empty: WARNING
      MSGWARNS "Oracle home directory is not empty - continuing."
      MSGWARNS "Option '-no_empty_dir_check' is enabled."
      MSGWARNS "Extracting Oracle Home Gold Image into non-empty Oracle Home."
    fi
  fi

  #############################################################################
  # Extract Oracle home image file
  #############################################################################
  MSGINFOS "Extracting Oracle home image file"
  MSGINFOS "This step can take a while, please wait ..."
  
  if [ "$opt_extract_mode_verbose" = "-xquiet" ] || [ "$opt_extract_mode_verbose" = "-xverbose" ]; then
    # run extraction in quiet or verbose mode
    next_cmd="${OS_UNZIP_CMD} ${OS_UNZIP_OPT} $ora_image_file_path -d $tgt_oh_loc"
    MSGFREEV "Oracle home image file: $ora_image_file_path -> $tgt_oh_loc"
    echo_std "$next_cmd"
    show_arg_list_1 ${OS_UNZIP_CMD} ${OS_UNZIP_OPT} $ora_image_file_path -d $tgt_oh_loc
                    ${OS_UNZIP_CMD} ${OS_UNZIP_OPT} $ora_image_file_path -d $tgt_oh_loc
    if [ $rc_os_cmd -ne 0 ]; then
      MSGERRRS "Extracting Oracle home image file finished with error(s)."
      echo_std "$next_cmd"
      rct_ohx=$RC_ERRR
      install_exit $RC_ERRR
    else 
      MSGINFOS "Extracting Oracle home image file finished successfully."
    fi
  else
    # run extraction with extraction progress indicator
    next_cmd="${OS_UNZIP_CMD} ${OS_UNZIP_OPT} $ora_image_file_path -d $tgt_oh_loc 2>$tmp_dir_errfile"
    MSGFREEV "Oracle home image file: $ora_image_file_path -> $tgt_oh_loc"
    echo_std "$next_cmd"
    show_arg_list_1 "${OS_UNZIP_CMD}" "${OS_UNZIP_OPT}" "$ora_image_file_path" "-d $tgt_oh_loc" "2>$tmp_dir_errfile"
    
    # number of files in Oracle Home Image File to extract
    echo_std "Number of files to extract: ~ $ORA_GOLD_IMAGE_FILE_CNT (can vary, depending on platform)"

    # awk version #initial#: awk 'BEGIN { ORS = " " } { print "." }'
    # awk version #andy   #: awk 'BEGIN { ORS = ""; } (NR % 10  == 0) { print "."; } (NR % 790  == 0) { print "\n"; } END { print "\n"; }'
    # awk version #andy   #: awk 'BEGIN { ORS = ""; } (NR % 50  == 0) { print "."; } (NR % 3900 == 0) { print "\n"; } END { print "\n"; }'
    # awk version #andy   #: awk 'BEGIN { ORS = ""; } (NR % 50  == 0) { print "."; } (NR % 3900 == 0) { print "\n"; } END { print "\n"; }'
    # awk version #jens   #: awk 'BEGIN { ORS = ""; } (NR % 100 == 0) { print "."; } (NR % 7900 == 0) { print "\n"; } END { print "\n"; }'
    # awk version #andy   #: awk 'BEGIN { ORS = ""; } (NR % 100 == 0) { print "."; } (NR % 3900 == 0) { print " " FNR " files extracted \n"; } END { print " " NR " files (total)\n"; }'
    # awk version #andy   #: awk 'BEGIN { ORS = ""; } (NR % 100 == 0) { print "."; } (NR % 3900 == 0) { print " "  NR " files extracted \n"; } END { print " " NR " files (total)\n"; }'
    # awk version #andy   #: awk 'BEGIN { ORS = ""; } (NR % 100 == 0) { print "."; } (NR % 4000 == 0) { printf(" %5.0f files extracted (%3.0f %) \n", NR, 100 * NR / 45000 ); } END { printf(" %5.0f files extracted (%3.0f %) \n", NR, 100 ); }'
    
    # the following version prints out 78 dots in one line
    # Example: ..............................................................................
    # ${OS_UNZIP_CMD} ${OS_UNZIP_OPT} $ora_image_file_path -d $tgt_oh_loc 2>"$tmp_dir_errfile" | awk 'BEGIN { ORS = ""; } (NR % 50  == 0) { print "."; } (NR % 3900 == 0) { print "\n"; } END { print "\n"; }'
    
    # the following version prints out 39 dots in a line plus the number of extracted files
    # Example: ....................................... 39000 files extracted
    # ${OS_UNZIP_CMD} ${OS_UNZIP_OPT} $ora_image_file_path -d $tgt_oh_loc 2>"$tmp_dir_errfile" | awk 'BEGIN { ORS = ""; } (NR % 100 == 0) { print "."; } (NR % 3900 == 0) { print " " FNR " files extracted \n"; } END { print " " NR " files (total)\n"; }'
    
    # the following version prints out 39 dots in a line plus the number of extracted files plus the estimated percentage
    # Example: ....................................... 39000 files extracted 86.6667 % 
    # ${OS_UNZIP_CMD} ${OS_UNZIP_OPT} $ora_image_file_path -d $tgt_oh_loc 2>"$tmp_dir_errfile" | awk 'BEGIN { ORS = ""; } (NR % 100 == 0) { print "."; } (NR % 3900 == 0) { print " " FNR " files extracted " 100 * FNR / 45000 " % " "\n"; } END { print " " NR " files (total)\n"; }'

    # the following version prints out 50 dots in a line plus the number of extracted files plus the estimated percentage (rounded)
    # Example: ..................................................  5000 files extracted ( 11 %)
    ${OS_UNZIP_CMD} ${OS_UNZIP_OPT} $ora_image_file_path -d $tgt_oh_loc 2>"$tmp_dir_errfile" | awk 'BEGIN { ORS = ""; } (NR % 100 == 0) { print "."; } (NR % 4000 == 0) { printf(" %5.0f files extracted (%3.0f %) \n", NR, 100 * NR / 45000 ); } END { printf(" %5.0f files extracted (%3.0f %) \n", NR, 100 ); }'
                    
    # do not check $? here, but size of "$tmp_dir_errfile" to detect unzip errors. "test -s" is portable.
    if [ -s "$tmp_dir_errfile" ]; then
      echo_std "$MSG_ERRR" "Error during unzip occurred"
      cat "$tmp_dir_errfile"
      install_exit $RC_ERRR
    else 
      MSGINFOS "Extracting Oracle home image file finished successfully."
    fi
  fi

  #############################################################################
  # POST-EXTRACTION TASKS
  #############################################################################
  MSGINFOS "Post-Extraction Tasks"

  #############################################################################
  # POST-EXTRACTION: Cleanup old root.sh log files from <OH>/install/root_<host>_<date>.log
  #############################################################################
  MSGINFOS "Cleanup old root.sh log files from Oracle home gold image."
  MSGINFOS "Checking directory ${tgt_oh_loc}/install for files named root_*.log"
  MSGFREEV "Searching for old root.sh log files in ${tgt_oh_loc}/install ..."
  MSGFREEV "Searching for file names like root_<hostname>_<YYYY-MM-DD_HH-MM-SS>.log"
 #last_cmd_out=`ls -l ${tgt_oh_loc}/install/root_*.log > /dev/null 2>&1`
 #rc_os_cmd=$?
 #MSGFREEV "$last_cmd_out"
 #if [ $rc_os_cmd -ne 0  ]; then
 #  # no log files found
 #  MSGINFOS "No old root.sh log files found."
 #else
 #  MSGINFOS "${tgt_oh_loc}/root.sh was executed."
 #fi
  # https://www.cyberciti.biz/faq/use-a-for-loop-to-remove-file-in-unix/
  # https://unix.stackexchange.com/questions/348230/remove-everything-within-directory-using-for-loop
  for mylogfile in ${tgt_oh_loc}/install/root_*.log
  do
    # if file exists, delete it
    if [ -f "$mylogfile" ]; then
      MSGINFOV "Removing $mylogfile"
      rm -f "$mylogfile"
      rc_os_cmd=$?
      if [ $rc_os_cmd -ne 0  ]; then
        MSGERRRS "$mylogfile not deleted."
      else
        MSGINFOS "$mylogfile deleted."
      fi
    fi
  done

  #############################################################################
  # POST-EXTRACTION: copy SAP RUNINSTALLER scripts: RUNINSTALLER and Installation Script
  #############################################################################
  MSGINFOS "Copying SAP RUNINSTALLER into Oracle home directory $tgt_oh_loc"
  MSGFREEV "Wrapper script: ${PROGDIR}/RUNINSTALLER"
  MSGFREEV "Install script: ${PROGDIR}/${PROGNAME}"
  next_cmd="  cp -p ${PROGDIR}/RUNINSTALLER ${PROGDIR}/${PROGNAME} $tgt_oh_loc"
  cp -p ${PROGDIR}/RUNINSTALLER ${PROGDIR}/${PROGNAME} $tgt_oh_loc
  rc_os_cmd=$?
  MSGFREEV "Last Returncode: $rc_os_cmd"
  if [ $rc_os_cmd -ne 0 ]; then
    MSGWARNS "Copying SAP RUNINSTALLER into Oracle home directory $tgt_oh_loc failed (rc=$rc_os_cmd)."
    echo_std "$next_cmd"
    rct_ohx=$RC_WARN
    #install_exit $RC_ERRR
  else 
    MSGINFOS "Copying SAP RUNINSTALLER finished successfully."
  fi
fi

# #############################################################################
# Searching Oracle runInstaller (after extraction runInstaller is there)
# #############################################################################
MSGFREEV "Searching Oracle runInstaller ..."

# search in extracted Oracle Home
for ora_search_path in ${tgt_oh_loc}
do
  if [ -n "${ora_search_path}" ]; then
    [ ora_runinstaller_found="${STR_NO}" ] && MSGFREEV "Searching Oracle runInstaller in location ${ora_search_path} ..."
    [ ora_runinstaller_found="${STR_NO}" ] && [ -f ${ora_search_path}/${ora_runinstaller_file} ] && ora_runinstaller_path=${ora_search_path}/${ora_runinstaller_file} && ora_runinstaller_found="${STR_YES}"
    [ ora_runinstaller_found="${STR_NO}" ] || MSGFREEV "Oracle runInstaller found: $ora_runinstaller_path"
    MSGFREEV "Oracle runInstaller path      : $ora_runinstaller_path"
    MSGFREEV "Oracle runInstaller file found: $ora_runinstaller_found"
  fi
done

###############################################################################
#                                                                             #
#                     END TASK: -ohextract                                    #
#                                                                             #
###############################################################################
[ $opt_ohx = ${STR_YES} ] && rct_ohx=$RC_SUCC && MSGINFOV "rct_ohx=$rct_ohx"

###############################################################################
#                                                                             #
#                     BGN TASK: -ohcheck                                      #
#                                                                             #
###############################################################################
dsc_cur="${dsc_ohc}"
[ $opt_ohi = ${STR_NO}  ] && [ $opt_ohm = ${STR_NO} ] && [ $opt_ohs = ${STR_NO} ] && [ $opt_ohr = ${STR_NO} ] && [ $opt_ohc = ${STR_NO} ] && install_exit $RC_SUCC
[ $opt_ohc = ${STR_YES} ] && MSGINFOS "TASK - $dsc_ohc" && run_ohc="${STR_YES}"
[ $opt_ohc = ${STR_YES} ] && MSGDATETIME "${dsc_cur}"
[ $opt_ohc = ${STR_NO}  ] && MSGINFOS "TASK - $dsc_ohc - ${dsc_dnr}"
[ $opt_ohc = ${STR_YES} ] && rct_ohc=$rct_ini

###############################################################################
# Example: 
# sh-4.3$ /oracle/DQ1/18.0.0/runInstaller -executePrereqs
# Launching Oracle Database Setup Wizard...
# 
# sh-4.3$ echo $?
# 253
# sh-4.3$ /oracle/DQ1/18.0.0/runInstaller -executePrereqs -silent
# Launching Oracle Database Setup Wizard...
# 
# [FATAL] [INS-13013] Target environment does not meet some mandatory requirements.
#    CAUSE: Some of the mandatory prerequisites are not met. See logs for details. /oracle/oraInventory/logs/InstallActions2018-09-13_12-14-51PM/installActions2018-09-13_12-14-51PM.log
#    ACTION: Identify the list of failed prerequisite checks from the log: /oracle/oraInventory/logs/InstallActions2018-09-13_12-14-51PM/installActions2018-09-13_12-14-51PM.log. Then either from the log file or from installation manual find the appropriate configuration to meet the prerequisites and fix it manually.
# sh-4.3$ echo $?
# 253
# sh-4.3$
###############################################################################
[ $opt_ohc = $STR_YES ] && [ "${query_mode}" = "${STR_ENABLED}" ] && MSGINFOS "Query mode enabled - nothing to do"
if [ $opt_ohc = $STR_YES ] && [ "${query_mode}" = "${STR_DISABLED}" ]; then
  if [ ${ora_runinstaller_found} = ${STR_YES} ]; then
    # Installation Session Start
    inst_session_start

    # Check Prerequisites: set this option
    oui_executePrereqs="-executePrereqs"

    # Display OUI command line
    MSGINFOS "${STR_OUI_NAME_0} command line:"
    echo_cmd        LANG=C TMP="$tmp_dir_full" TMPDIR="$tmp_dir_full" "${ora_runinstaller_path}" ${oui_invptrloc_option} ${silent_mode} ${flag_debug_mode_oui} ${oui_ignorePrereq_1} ${oui_ignorePrereq_2} ${oui_executePrereqs} ${ignoreInternalDriverError} ${oui_lang_option}
    show_arg_list_1 LANG=C TMP="$tmp_dir_full" TMPDIR="$tmp_dir_full" "${ora_runinstaller_path}" ${oui_invptrloc_option} ${silent_mode} ${flag_debug_mode_oui} ${oui_ignorePrereq_1} ${oui_ignorePrereq_2} ${oui_executePrereqs} ${ignoreInternalDriverError} ${oui_lang_option}
    show_arg_list_2 LANG=C TMP="$tmp_dir_full" TMPDIR="$tmp_dir_full" "${ora_runinstaller_path}" ${oui_invptrloc_option} ${silent_mode} ${flag_debug_mode_oui} ${oui_ignorePrereq_1} ${oui_ignorePrereq_2} ${oui_executePrereqs} ${ignoreInternalDriverError} ${oui_lang_option}
    
    MSGINFOS "Starting ${STR_OUI_NAME_0} ..."
    MSGINFOS "########################################"
    MSGINFOS "${STR_OUI_NAME_0} started ..."
    MSGINFOS "########################################"
                    LANG=C TMP="$tmp_dir_full" TMPDIR="$tmp_dir_full" "${ora_runinstaller_path}" ${oui_invptrloc_option} ${silent_mode} ${flag_debug_mode_oui} ${oui_ignorePrereq_1} ${oui_ignorePrereq_2} ${oui_executePrereqs} ${ignoreInternalDriverError} ${oui_lang_option}

    # Get Return Code
    rc_oui_cmd=$?; rc_oui_real=${rc_oui_cmd}; [ ${rc_oui_real} -gt 127 ] && rc_oui_real=`expr $rc_oui_cmd - 256`

    # OUI finished
    echo_nln
    MSGINFOS "########################################"
    MSGINFOS "${STR_OUI_NAME_0} finished."
    MSGINFOS "########################################"
    MSGINFOS "${STR_OUI_NAME_0} (runInstaller) finished with return code ${rc_oui_real}."
    
    # Check Prerequisites: reset this option
    oui_executePrereqs=""
    
    # Check Return code
    [ $rc_oui_real -eq 0 ] && rct_ohc=$RC_SUCC && MSGINFOS "${STR_OUI_NAME_0} (runInstaller) finished successfully."
    [ $rc_oui_real -ne 0 ] && rct_ohc=$RC_WARN && MSGWARNS "${STR_OUI_NAME_0} (runInstaller) finished with warnings or errors. " \
                                               && MSGWARNS "Check log file for more information and search for term 'VERIFICATION_FAILED'."
    
    # Check logfile and search for messages like
    # Severity:CRITICAL
    # OverallStatus:VERIFICATION_FAILED
    # 
    # Example:
    # INFO:  [Sep 14, 2018 10:49:17 AM] Users With Same UID: 0: This test checks that multiple users do not exist with user id as "0".
    # INFO:  [Sep 14, 2018 10:49:17 AM] Severity:CRITICAL
    # INFO:  [Sep 14, 2018 10:49:17 AM] OverallStatus:VERIFICATION_FAILED

    # Installation Session Cleanup
    # inst_session_cleanup # Do not clean up here, you would remove the response file
  else
    MSGERRRS "${STR_OUI_NAME_0} (runInstaller) not found."
    rct_ohc=$RC_ERRR && install_exit $RC_ERRR
  fi
fi

###############################################################################
#                                                                             #
#                     END TASK: -ohcheck                                      #
#                                                                             #
###############################################################################
[ $opt_ohc = ${STR_YES} ] && MSGINFOV "rct_ohc=$rct_ohc"

###############################################################################
#                                                                             #
#                     BGN TASK: -ohregister                                   #
#                                                                             #
###############################################################################
dsc_cur="${dsc_ohr}"
[ $opt_ohi = ${STR_NO}  ] && [ $opt_ohm = ${STR_NO} ] && [ $opt_ohs = ${STR_NO} ] && [ $opt_ohr = ${STR_NO} ] && install_exit $RC_SUCC
[ $opt_ohr = ${STR_YES} ] && MSGINFOS "TASK - $dsc_ohr" && run_ohr="${STR_YES}"
[ $opt_ohr = ${STR_YES} ] && MSGDATETIME "${dsc_cur}"
[ $opt_ohr = ${STR_NO}  ] && MSGINFOS "TASK - $dsc_ohr - ${dsc_dnr}"
[ $opt_ohr = ${STR_YES} ] && rct_ohr=$RC_SUCC

[ $opt_ohr = $STR_YES ] && [ "${query_mode}" = "${STR_ENABLED}" ] && MSGINFOS "Query mode enabled - nothing to do"
if [ $opt_ohr = $STR_YES ] && [ "${query_mode}" = "${STR_DISABLED}" ]; then
  #############################################################################
  # Installation Session Start
  #############################################################################
  inst_session_start

  #############################################################################
  # Display OUI command line
  #############################################################################
  MSGINFOS "${STR_OUI_NAME_0} command line:"
  if [ -n "${oui_rsa_userpw}" ]; then
    MSGINFOS "Piping password to ${STR_OUI_NAME_0}"
   #echo_cmd "echo ${oui_rsa_userpw}" "${tee_pipe}" # do not show transparent password
    echo_cmd "echo ${oui_rsa_userpx}" "${tee_pipe}"
  fi
  echo_cmd "LANG=C" "TMP=$tmp_dir_full" "TMPDIR=$tmp_dir_full" "${ora_runinstaller_path}" "${oui_invptrloc_option}" "${oui_rsp_opt}" "${oui_rsp_file}" "${oui_wait_option}" "${oui_nolink_mode}" "${silent_mode}" "${silent_mode_progress}" "${flag_debug_mode_oui}" "${oui_ignorePrereq_1}" "${oui_ignorePrereq_2}" "${oui_executePrereqs}" "${ignoreInternalDriverError}" "${ORACLE_HOME_NAME_VAR}" "${oui_lang_option}" "${opt_applyOO_strg}" "${opt_applyOO_path}" "${opt_applyRU_strg}" "${opt_applyRU_path}" "${opt_opatchloc_strg}" "${opt_opatchloc_path}" "${opt_opatch_s_o_v_c_strg}" "${tee_pipe}" "${tee_cmd}" "${oui_log_file}"

  #############################################################################
  # Display OUI response file
  #############################################################################
  if [ -f ${rspf_file} ] && [ -n "${flag_debug_mode_rsp}" ]; then
    echo_std
    echo_std "${STR_OUI_NAME_0} Response File:"
    echo_std "File name ${rspf_file}"
    echo_std "File Content"
    echo_std
    cat ${rspf_file}
    echo_std
  fi

  #############################################################################
  # Append OUI response file to log file
  #############################################################################
  if [ -f ${rspf_file} ] && [ -f ${sap_log_file_single} ]; then 
    echo "$LEAD_CHAR"                          >> ${sap_log_file_single}
    echo "$LEAD_CHAR ${STR_OUI_NAME_0} response file:"       >> ${sap_log_file_single}
    echo "$LEAD_CHAR File name ${rspf_file} "  >> ${sap_log_file_single}
    echo "$LEAD_CHAR File Content"             >> ${sap_log_file_single}
    cat ${rspf_file}                           >> ${sap_log_file_single}
    echo "$LEAD_CHAR"                          >> ${sap_log_file_single}
  fi

  #############################################################################
  # Check whether to start OUI
  #############################################################################
  if [ "${flag_start_oui}" = "${STR_TRUE}" ] && [ "${query_mode}" = "${STR_ENABLED}" ]; then
    # Do not start OUI if -query option is used
    MSGINFOS "'-query' option: ${STR_OUI_NAME_0} (runInstaller) is not started. "
    flag_start_oui="${STR_FALSE}"
  fi
  
  #############################################################################
  # Check whether root script automation password is required for OUI
  #############################################################################
	case $oui_rsa_method in
    ROOT) 
      if [ -z "${oui_rsa_rootpw}" ]; then
        MSGFREES "Root Script Automation: Password required (ROOT)"
        MSGFREES "${STR_OUI_NAME_0}: Password required"
        MSGFREES "Please enter the password for '${oui_rsa_userun}':"
      fi
      ;;
    SUDO)
      if [ -z "${oui_rsa_sudopw}" ]; then
        MSGFREES "Root Script Automation: Password required (SUDO)"
        MSGFREES "${STR_OUI_NAME_0}: Password required"
        MSGFREES "Please enter the password for '${oui_rsa_userun}':"
      fi
      ;;
  esac
  

  #############################################################################
  # Starting OUI/runInstaller for Installation
  #############################################################################
  if [ "${flag_start_oui}" = "${STR_TRUE}" ]; then
    flag_oui_was_started="${STR_TRUE}"
    [ "${silent_mode}" = "-silent" ] && MSGINFOS "Starting ${STR_OUI_NAME_0} (runInstaller) in silent mode - please wait ..."
    [ "${silent_mode}" = "-silent" ] || MSGINFOS "Starting ${STR_OUI_NAME_0} (runInstaller) in interactive mode - please wait ..."
    MSGINFOS "########################################"
    MSGINFOS "${STR_OUI_NAME_0} started ..."
    MSGINFOS "########################################"
    # OUI STARTTIME
    MSGDATETIME
  
    if [ -z "${tee_opt}" ]; then
      #########################################################################
      # Start Oracle Installer and get return code
      #########################################################################
  	  # Do not pipe OUI standard output to file, but get OUI return code
  	  if [ -z "${oui_rsa_userpw}" ]; then 
                                   LANG=C TMP="$tmp_dir_full" TMPDIR="$tmp_dir_full" "${ora_runinstaller_path}" ${oui_invptrloc_option} ${oui_rsp_opt} ${oui_rsp_file} ${oui_wait_option} ${oui_nolink_mode} ${silent_mode} ${silent_mode_progress} ${flag_debug_mode_oui} ${oui_ignorePrereq_1} ${oui_ignorePrereq_2} ${oui_executePrereqs} ${ignoreInternalDriverError} ${ORACLE_HOME_NAME_VAR} ${oui_lang_option} ${opt_applyOO_strg} ${opt_applyOO_path} ${opt_applyRU_strg} ${opt_applyRU_path} ${opt_opatchloc_strg} ${opt_opatchloc_path} ${opt_opatch_s_o_v_c_strg}
      else
        echo "${oui_rsa_userpw}" | LANG=C TMP="$tmp_dir_full" TMPDIR="$tmp_dir_full" "${ora_runinstaller_path}" ${oui_invptrloc_option} ${oui_rsp_opt} ${oui_rsp_file} ${oui_wait_option} ${oui_nolink_mode} ${silent_mode} ${silent_mode_progress} ${flag_debug_mode_oui} ${oui_ignorePrereq_1} ${oui_ignorePrereq_2} ${oui_executePrereqs} ${ignoreInternalDriverError} ${ORACLE_HOME_NAME_VAR} ${oui_lang_option} ${opt_applyOO_strg} ${opt_applyOO_path} ${opt_applyRU_strg} ${opt_applyRU_path} ${opt_opatchloc_strg} ${opt_opatchloc_path} ${opt_opatch_s_o_v_c_strg}
      fi
      
      #########################################################################
      # Get Return Code
      #########################################################################
      rc_oui_cmd=$?
      if [ ${rc_oui_cmd} -gt 127 ]; then
        # return code is negative (255 -> -1, 254 -> -2, ...)
        rc_oui_real=`expr $rc_oui_cmd - 256`
        # echo $rc_oui_cmd $rc_oui_real
      else
        rc_oui_real=${rc_oui_cmd}
      fi

      # OUI finished
      echo_nln
      MSGINFOS "########################################"
      MSGINFOS "${STR_OUI_NAME_0} finished."
      MSGINFOS "########################################"
      MSGINFOS "${STR_OUI_NAME_0} (runInstaller) finished with return code ${rc_oui_real}."
      # OUI ENDTIME
      MSGDATETIME
    else
      #########################################################################
      # Start Oracle Installer and pipe output to file
      #########################################################################

      # 2018-12-03: internal incident 1870497010 (BEGIN)
      case $platform in
        aix            ) 
          #Your platform requires the root user to perform certain pre-installation
          #OS preparation.  The root user should run the shell script 'rootpre.sh' before
          #you proceed with Oracle installation. The rootpre.sh script can be found at:
          #${tgt_oh_loc}/clone/rootpre.sh
          #Answer 'y' if root has run 'rootpre.sh' so you can proceed with Oracle
          #installation.
          #Answer 'n' to abort installation and then ask root to run 'rootpre.sh'.
          MSGFREES "****************************************************************************"
          MSGFREES "Your platform requires the root user to perform certain pre-installation    "
          MSGFREES "OS preparation.  The root user should run the shell script 'rootpre.sh'     "
          MSGFREES "before you proceed with Oracle installation.                                "
          MSGFREES " The rootpre.sh script can be found at:                                     "
          MSGFREES "${tgt_oh_loc}/clone/rootpre.sh                                              "
          MSGFREES "Answer 'y'                                                                  "
          MSGFREES "    if root has run 'rootpre.sh' so you can proceed with installation.      "
          MSGFREES "Answer 'n'                                                                  "
          MSGFREES "    to abort installation and then ask root to run 'rootpre.sh'.            "
          MSGFREES "****************************************************************************"
          MSGFREES "Has 'rootpre.sh' been run by root in this machine? [y/n] (n)"
          ;;
        *              ) 
          # Do nothing
          :
          ;;
      esac
      # 2018-12-03: internal incident 1870497010 (END)
      
    	# Pipe OUI standard output to file, but do not get return code
  	  if [ -z "${oui_rsa_userpw}" ]; then 
                                   LANG=C TMP="$tmp_dir_full" TMPDIR="$tmp_dir_full" "${ora_runinstaller_path}" ${oui_invptrloc_option} ${oui_rsp_opt} ${oui_rsp_file} ${oui_wait_option} ${oui_nolink_mode} ${silent_mode} ${silent_mode_progress} ${flag_debug_mode_oui} ${oui_ignorePrereq_1} ${oui_ignorePrereq_2} ${oui_executePrereqs} ${ignoreInternalDriverError} ${ORACLE_HOME_NAME_VAR} ${oui_lang_option} ${opt_applyOO_strg} ${opt_applyOO_path} ${opt_applyRU_strg} ${opt_applyRU_path} ${opt_opatchloc_strg} ${opt_opatchloc_path} ${opt_opatch_s_o_v_c_strg} | ${tee_cmd} ${oui_log_file}
      else
        echo "${oui_rsa_userpw}" | LANG=C TMP="$tmp_dir_full" TMPDIR="$tmp_dir_full" "${ora_runinstaller_path}" ${oui_invptrloc_option} ${oui_rsp_opt} ${oui_rsp_file} ${oui_wait_option} ${oui_nolink_mode} ${silent_mode} ${silent_mode_progress} ${flag_debug_mode_oui} ${oui_ignorePrereq_1} ${oui_ignorePrereq_2} ${oui_executePrereqs} ${ignoreInternalDriverError} ${ORACLE_HOME_NAME_VAR} ${oui_lang_option} ${opt_applyOO_strg} ${opt_applyOO_path} ${opt_applyRU_strg} ${opt_applyRU_path} ${opt_opatchloc_strg} ${opt_opatchloc_path} ${opt_opatch_s_o_v_c_strg} | ${tee_cmd} ${oui_log_file}
      fi

      # No OUI return code handling here
      
      # OUI finished
      echo_nln
      MSGINFOS "########################################"
      MSGINFOS "${STR_OUI_NAME_0} finished."
      MSGINFOS "########################################"
      MSGINFOS "${STR_OUI_NAME_0} (runInstaller) finished."
      # OUI ENDTIME
      MSGDATETIME

      # Append OUI output log file
      if [ "${flag_oui_was_started}" = "${STR_TRUE}" ] && [ -n "${oui_log_file}" ] && [ -f "${oui_log_file}" ] && [ -f ${sap_log_file_single} ]; then 
        echo "."                             >> ${sap_log_file_single}
        echo ". OUI output:"                 >> ${sap_log_file_single}
        cat ${oui_log_file}                  >> ${sap_log_file_single}
        echo "."                             >> ${sap_log_file_single}
      fi
      
      # analyze oui session log file
      # Get OUI session log file name from OUI output
      # Get OUI session exit code from OUI session log file
      if [ "${flag_oui_was_started}" = "${STR_TRUE}" ] && [ -n "${oui_log_file}" ] && [ -f "${oui_log_file}" ]; then 
        # Analyze OUI output for errors and warnings
        ins_13013=`${OS_GREP} "\[FATAL\] \[INS-13013\] Target environment do not meet some mandatory requirements."  ${oui_log_file} | head -1 | sed -e 's/^.*\[FATAL\]/\[FATAL\]/'`
        ins_13014=`${OS_GREP} "\[WARNING\] \[INS-13014\] Target environment do not meet some optional requirements." ${oui_log_file} | head -1 | sed -e 's/^.*\[WARNING\]/\[WARNING\]/'`
        ins_32018=`${OS_GREP} "\[WARNING\] \[INS-32018\] The selected Oracle home is outside of Oracle base."        ${oui_log_file} | head -1 | sed -e 's/^.*\[WARNING\]/\[WARNING\]/'`
        ins_fatal=`${OS_GREP} "\[FATAL\] \[INS-"                                                                     ${oui_log_file} | head -1 | sed -e 's/^.*\[FATAL\]/\[FATAL\]/'`
        ins_warning=`${OS_GREP} "\[WARNING\] \[INS-"                                                                 ${oui_log_file} | head -1 | sed -e 's/^.*\[WARNING\]/\[WARNING\]/'`

        # Find name of OUI session log file in OUI output
        oui_session_log=`${OS_GREP} "installActions[0-9][0-9][0-9][0-9]-[0-1][0-9]-[0-3][0-9]_[0-2][0-9]-[0-5][0-9]-[0-5][0-9][AP]M\.log" ${oui_log_file} | head -1 `
        oui_session_log=`echo $oui_session_log | sed -e 's/CAUSE: Some of the mandatory prerequisites are not met. See logs for details. //' `
        oui_session_log=`echo $oui_session_log | sed -e 's/CAUSE: Some of the optional prerequisites are not met. See logs for details. //' `
        oui_session_log=`echo $oui_session_log | sed -e 's/Exiting Oracle Universal Installer, log for this session can be found at //' `
        
        # remove leading and trailing blanks
        oui_session_log=`echo $oui_session_log | sed -e 's/^[ ]*//' | sed -e 's/[ ]*\$//' `
        #MSGINFOT " OUI session log is $oui_session_log"
        
        # remove blanks in the middle
        oui_session_log=`echo ${oui_session_log} | sed -e 's/[ ]*//'`
        #MSGINFOT " OUI session log is $oui_session_log"
        
        # Check file name
        if [ -n "${oui_session_log}" ]; then
          # File name found
          # MSGINFOT "Name of OUI session log file: " "'${oui_session_log}'"
          if [ -f ${oui_session_log} ]; then
            # file exists
            MSGINFOS "OUI install session log file is ${oui_session_log}"
            # get OUI session exit code
           #oui_session_rc=`${OS_GREP} "INFO: Exit Status is " ${oui_session_log} | ${OS_AWK} -F\( '{print $1}' | sed -e 's/INFO: Exit Status is //'`
            oui_session_rc=`${OS_GREP} "] Exit Status is " ${oui_session_log} | ${OS_AWK} -F\( '{print $1}' | sed -e 's/^.*] Exit Status is //'`
            oui_session_rc=`echo $oui_session_rc | sed -e 's/^[ 	]*//' | sed -e 's/[ 	]*\$//' ` # remove blanks - if any
            if  [ -n "$oui_session_rc" ]; then
              MSGINFOS "${STR_OUI_NAME_0} (runInstaller) finished with exit code '${oui_session_rc}'"
            else
              MSGINFOS "${STR_OUI_NAME_0} (runInstaller) exit code not found in OUI install session log file."
            fi
          else
            # file does not exist
            MSGINFOS "OUI install session log file is ${oui_session_log}"
            MSGINFOS "OUI install session log file does not exist any more - can not determine OUI exit code."
            oui_session_log=""
            oui_session_rc=""
          fi
        else
          # File name not found
          MSGINFOS "Name of OUI session log file not found."
        fi
      fi
    fi
  fi
  
  #############################################################################
  # Check result of installation
  #############################################################################
  if [ "${flag_oui_was_started}" = "${STR_TRUE}" ]; then 
    if [ -x $tgt_oh_loc/bin/oracle ] && [ -s $tgt_oh_loc/bin/oracle ]; then
      # oracle executable exists with size > 0 -> SUCCESS
      MSGINFOS "Installation was successful: $tgt_oh_loc/bin/oracle > 0"
      rct_ohr=$RC_SUCC
     #oui_result="SUCCESS"     # 2018-09-25: this var. is not used any more
     #oracle_exe="NOT MISSING" # 2018-09-25: this var. is not used any more
      [ -n "${ins_warning}" ] && rct_ohr=$RC_WARN
      [ -n "${ins_fatal}"   ] && rct_ohr=$RC_ERRR && oui_result="FAILURE"
    else
      # oracle executable does not exist or size is 0 -> ERROR
      MSGERRRS "Installation was not successful: $tgt_oh_loc/bin/oracle missing or empty"
      rct_ohr=$RC_ERRR
      install_exit $RC_ERRR
     #oui_result="FAILURE" # 2018-09-25: this var. is not used any more
     #oracle_exe="MISSING" # 2018-09-25: this var. is not used any more
    fi
  fi

  #############################################################################
  # Checking whether root.sh has already run
  #############################################################################
  MSGFREEV "Checking whether root.sh has already run ..."
  MSGFREEV "Searching for root.sh log files in ${tgt_oh_loc}/install named root_<hostname>_YYYY-MM-DD_HH-MM-SS.log"
  last_cmd_out=`ls -l ${tgt_oh_loc}/install/root_*.log > /dev/null 2>&1`
  rc_os_cmd=$?
  MSGFREEV "$last_cmd_out"
  if [ $rc_os_cmd -ne 0  ]; then
    flag_ohroot="${STR_NO}"
    MSGWARNS "${tgt_oh_loc}/root.sh was not executed."
  else
    flag_ohroot="${STR_YES}"
    MSGINFOS "${tgt_oh_loc}/root.sh was executed."
  fi

  #############################################################################
  # Installation Session Cleanup
  #############################################################################
  # inst_session_cleanup # Do not clean up here, cleanup only in install_exit function
fi

###############################################################################
#                                                                             #
#                     END TASK: -ohregister                                   #
#                                                                             #
###############################################################################
[ $opt_ohr = ${STR_YES} ] && MSGINFOV "rct_ohr=$rct_ohr"
[ $opt_ohr = ${STR_YES} ] && case $rct_ohr in
	$RC_SUCC ) MSGINFOS "Registration of Oracle Home finished successfully."    ;;
	$RC_WARN ) MSGWARNS "Registration of Oracle Home finished with warning(s)." ;;
	$RC_ERRR ) MSGERRRS "Registration of Oracle Home finished with error(s)."   ;;
  *        ) MSGFREES "Registration of Oracle Home finished with undefined result." ;;
esac

###############################################################################
#                                                                             #
#                     BGN TASK: -ohsapcfg                                     #
#                                                                             #
###############################################################################
dsc_cur="${dsc_ohs}"
[ $opt_ohi = ${STR_NO}  ] && [ $opt_ohm = ${STR_NO} ] && [ $opt_ohs = ${STR_NO} ] && install_exit $RC_SUCC
[ $opt_ohs = ${STR_YES} ] && MSGINFOS "TASK - $dsc_ohs" && run_ohs="${STR_YES}"
[ $opt_ohs = ${STR_YES} ] && MSGDATETIME "${dsc_cur}"
[ $opt_ohs = ${STR_NO}  ] && MSGINFOS "TASK - $dsc_ohs - ${dsc_dnr}"
[ $opt_ohs = ${STR_YES} ] && rct_ohs=$RC_SUCC

[ $opt_ohs = $STR_YES ] && [ "${query_mode}" = "${STR_ENABLED}" ] && MSGINFOS "Query mode enabled - nothing to do"
if [ $opt_ohs = $STR_YES ] && [ "${query_mode}" = "${STR_DISABLED}" ]; then

  # Post-installation tasks
  if PostInstTasksRun; then
    echo_std "Performing post-installation tasks ..."
  else
    echo_std "Post-installation tasks are not executed."
    echo_std "Reason: ${post_install_skip_reason}"
  fi

  # ###########################################################################
  # Post-Installation Task #1: Configure Runtime Oracle Home OHRDBMS
  # ###########################################################################
  # tgt_oh_dirname :                  <ORACLE_RELEASE_KURZ>
  # tgt_oh_loc     : /oracle/<DB_SID>/<ORACLE_RELEASE_KURZ>
  # tgt_oh_linkname:                  <tgt_oh_linkname>
  # tgt_oh_linkloc : /oracle/<DB_SID>
  # tgt_oh_link    : /oracle/<DB_SID>/<tgt_oh_linkname>
  # ###########################################################################
  
  if PostInstTasksRun || PostSharedOhInstall; then
  	if [ "${sym_link_create_opt}" = "yes" ]; then
  	  #########################################################################
      # Part #1: Check whether location for symbolic link needs to be created
      #   This needs to be executed in the following situations:
      #     1. as part of the post installation steps
      #     2. in case of a shared Oracle home installation
  	  #########################################################################
      if [ -d $tgt_oh_linkloc ]; then
      	MSGINFOV "Link location where to create symbolic link exists."
      else
        MSGINFOV "Link location where to create symbolic link does not exist."
        MSGINFOV "Trying to create directory $tgt_oh_linkloc"
        mkdir -p $tgt_oh_linkloc
        rc_cmd=$?
        if [ $rc_cmd -eq 0 ]; then
          MSGINFOS "Link location directory $tgt_oh_linkloc created succesfully."
          chmod 755 $tgt_oh_linkloc
          rc_cmd1=$?
          chown $user_group $tgt_oh_linkloc
          rc_cmd2=$?
          if [ $rc_cmd1 -ne 0 ] || [ $rc_cmd2 -ne 0 ]; then
            MSGWARNS "Failed to set permissions for link location directory $tgt_oh_linkloc"
            rct_ohs=$RC_WARN
          fi
        else
          MSGERRRS "Failed to create link location directory $tgt_oh_linkloc"
          rct_ohs=$RC_ERRR
        fi
      fi
  	  #########################################################################
      # Part #2: Create symbolic link
 	    #########################################################################
    	MSGINFOV "Creating symbolic link $tgt_oh_link ..."
      if [ -d $tgt_oh_loc ]; then
        # Link target exists
        if [ -f ${tgt_oh_link} ] || [ -h ${tgt_oh_link} ] || [ -d ${tgt_oh_link} ]; then
          # Link can not be created because file/directory/link already exists
          MSGWARNS "Symbolic link $tgt_oh_link can not be created because file or directory with this name already exists."
          rct_ohs=$RC_WARN
        else
          # Creating symbolic link
          if [ "${sym_link_path}" = "relative" ]; then
            ###echo_std "Creating symbolic link $tgt_oh_link -> $tgt_oh_dirname (relative path)"
            ${OS_CREATELINK} $tgt_oh_dirname $tgt_oh_link
            ln_rc=$?
            if [ ${ln_rc} -eq 0 ]; then
              echo_std "${MSG_OKOK}" "Symbolic link $tgt_oh_link -> $tgt_oh_dirname successfully created."
              sym_link_created="yes"
            else
              MSGERRRS "Failed to create symbolic link $tgt_oh_link -> $tgt_oh_dirname."
              rct_ohs=$RC_ERRR
            fi
          else
            ###echo_std "Creating symbolic link $tgt_oh_link -> $tgt_oh_loc (absolute path)"
            ${OS_CREATELINK} $tgt_oh_loc     $tgt_oh_link
            ln_rc=$?
            if [ ${ln_rc} -eq 0 ]; then
              MSGINFOS "Symbolic link $tgt_oh_link -> $tgt_oh_loc successfully created."
              sym_link_created="yes"
            else
              MSGERRRS "Failed to create symbolic link $tgt_oh_link -> $tgt_oh_loc."
              rct_ohs=$RC_ERRR
            fi
          fi
        fi
      else
        # Link target does not exist
        MSGWARNS "Symbolic link $tgt_oh_link is not created because link target $tgt_oh_loc does not exist."
        rct_ohs=$RC_WARN
      fi
    fi
  fi
  
  # #############################################################################
  # Post-Installation Task #2: configure oratab / add <DBSID> entry
  # #############################################################################
  # Add the following entry as a comment to oratab
  # '# <DBSID>:<OHRDBMS>:N # added by SAP RUNINSTALLER
  # Requirements:
  #  1. OHRDBMS does exist
  #  2. DB_SID is specified
  # #############################################################################
  
  if PostInstTasksRun; then
  	if SharedOhInstall; then
      MSGINFOV "oratab: no entry added to oratab because Oracle home is shared."
  	else
    	oratabfile=${ORATAB_LOCATION}
    	if [ -f "${oratabfile}" ]; then
        #######################################################
        # oratab file exists
        #######################################################
      	if [ -n "${tgt_db_sid}" ]; then
      	  if [ -d "${tgt_oh_link}" ]; then    	  
            #######################################################
            # modify oratab: add entry to oratab
            #######################################################
            # Leo Dictionary
            # to comment   = to disable code line 
            # to uncomment = to enable code line
            # https://dict.leo.org/forum/viewUnsolvedquery.php?idThread=155417&idForum=1&lang=en&lp=ende
            # https://dict.leo.org/forum/viewUnsolvedquery.php?idThread=273948&idForum=2&lang=en&lp=ende
            #######################################################
           #oratabfile_entry_ohrdbms="# ${tgt_db_sid}:${tgt_oh_link}:N # added by SAP RUNINSTALLER $log_time"	
           #oratabfile_entry_ohrdbms="# ${tgt_db_sid}:${tgt_oh_link}:N # remove this comment after upgrade - added by SAP RUNINSTALLER $log_time)"
           #oratabfile_entry_ohrdbms="# ${tgt_db_sid}:${tgt_oh_link}:N # enable this line after upgrade - added by SAP RUNINSTALLER $log_time)"
            oratabfile_entry_ohrdbms="# ${tgt_db_sid}:${tgt_oh_link}:N # uncomment this line after upgrade - added by SAP RUNINSTALLER $log_time"
            echo "${oratabfile_entry_ohrdbms}" >> ${oratabfile}
            rc_cmd=$?
            if [ $rc_cmd -ne 0 ]; then
              MSGERRRS "oratab: failed to add entry to $oratabfile"
              echo_std "${MSG_CONT}" "${oratabfile_entry_ohrdbms}"
              rct_ohs=$RC_ERRR
            else
              MSGINFOS "oratab: entry for database ${tgt_db_sid} added to $oratabfile."
            fi
          else
            MSGWARNS "oratab: no entry added to oratab because Oracle home runtime location does not exist (OHRDBMS=${tgt_oh_link})"
            rct_ohs=$RC_WARN
          fi
        else
          MSGWARNS "oratab: no entry added to oratab because DB_SID is empty"
          rct_ohs=$RC_WARN
        fi
      else
        #######################################################
        # oratab file does not exist
        #######################################################
        MSGWARNS "oratab: no entry added to oratab because file was not found: $oratabfile"
        rct_ohs=$RC_WARN
      fi
    fi
  fi
  
  # #############################################################################
  # Post-Installation Task #3: configure orabasetab - add OHRDBMS
  # #############################################################################
  # IHRDBMS     = $tgt_oh_loc  = Installation Oracle Home
  # OHRDBMS     = $tgt_oh_link = Runtime      Oracle Home
  # ORACLE_BASE = $tgt_ob_loc  = Oracle Base
  # #############################################################################

  if PostInstTasksRun; then
  	if [ "$opt_orabasetab" = "yes" ]; then
  	  # get orabasetab path
  	  obtt_orabasetab=${tgt_oh_loc}/install/orabasetab # original orabasetab
  	  # read orabasetab
      if [ -f $obtt_orabasetab ]; then
        # grep first line that is not a comment line
        obtt_entry_std=`cat $obtt_orabasetab | grep "^/" | head -1 `
        obtt_entry_std_col_1=`cat $obtt_orabasetab | grep "^/" | head -1 | cut -d ":" -f1 `
        obtt_entry_std_col_2=`cat $obtt_orabasetab | grep "^/" | head -1 | cut -d ":" -f2 `
        obtt_entry_std_col_3=`cat $obtt_orabasetab | grep "^/" | head -1 | cut -d ":" -f3 `
        obtt_entry_std_col_4=`cat $obtt_orabasetab | grep "^/" | head -1 | cut -d ":" -f4 `
      else
      	echo_std "$MSG_ERRR" "File not found. $obtt_orabasetab does not exist."
      fi
  	  # build new orabasetab entry
  	  obtt_entry_ihrdbms="$tgt_oh_loc:$obtt_entry_std_col_2:$obtt_entry_std_col_3:$obtt_entry_std_col_4:"
  	  obtt_entry_ohrdbms="$tgt_oh_link:$obtt_entry_std_col_2:$obtt_entry_std_col_3:$obtt_entry_std_col_4:"
  	  # verbose info
  	  MSGFREEV "Adding the following entry to ${obtt_orabasetab}"
  	  MSGFREEV "$obtt_entry_ohrdbms"
  	  # verbose info - show orabasetab before
  	  [ "${verbose_mode}" = "${STR_ENABLED}" ] && MSGINFOV "Before modification" && cat ${obtt_orabasetab}
	  	# modify orabasetab
      echo "${obtt_entry_ohrdbms}" >> ${obtt_orabasetab}
  	  # verbose info - show orabasetab before
  	  [ "${verbose_mode}" = "${STR_ENABLED}" ] && MSGINFOV "After modification"  && cat ${obtt_orabasetab}
      if [ $rc_cmd -ne 0 ]; then
        MSGERRRS "Failed to modify ${obtt_orabasetab}"
        rct_ohs=$RC_ERRR
      else
        MSGINFOS "orabasetab: added new entry ${obtt_entry_ohrdbms}"
        MSGINFOS "orabasetab: file ${obtt_orabasetab} modified successfully."
      fi
    fi
  fi
  
  # #############################################################################
  # Post-Installation Task #4a: opatch version (Verifying OPatch version)
  # #############################################################################
  if PostInstTasksRun; then
  	if [ "$opt_opatch_chk" = "yes" ]; then
      OPATCH_FILE="${tgt_oh_loc}/OPatch/opatch"
      OPATCH_OPT="version"
      if [ -f ${OPATCH_FILE} ]; then
      	echo_std
        MSGINFOS "OPatch: Checking OPatch version ..."
        echo_std "Command: 'ORACLE_HOME=$tgt_oh_loc $OPATCH_FILE ${OPATCH_OPT} ${oui_invptrloc_option}'"
        MSGFREEV "ORACLE_HOME=${tgt_oh_loc} ${OPATCH_FILE} ${OPATCH_OPT} ${oui_invptrloc_option}"
        ORACLE_HOME=${tgt_oh_loc} ${OPATCH_FILE} ${OPATCH_OPT} ${oui_invptrloc_option}
        opatch_rc=$?
        [ $opatch_rc -ne 0 ] && MSGINFOS "OPatch finished with return code '${opatch_rc}'."
      	echo_std
      fi
    fi
  fi

  # #############################################################################
  # Post-Installation Task #4b: opatch lsinventory (get installed patches)
  # #############################################################################
  if PostInstTasksRun; then
  	if [ "$opt_opatch_chk" = "yes" ]; then
      OPATCH_FILE="${tgt_oh_loc}/OPatch/opatch"
      OPATCH_OPT="lsinventory"
      if [ -f ${OPATCH_FILE} ]; then
      	echo_std
        MSGINFOS "OPatch: Checking installed patches ..."
        echo_std "Command: 'ORACLE_HOME=$tgt_oh_loc $OPATCH_FILE ${OPATCH_OPT} ${oui_invptrloc_option}'"
        MSGFREEV "ORACLE_HOME=${tgt_oh_loc} ${OPATCH_FILE} ${OPATCH_OPT} ${oui_invptrloc_option}"
        ORACLE_HOME=${tgt_oh_loc} ${OPATCH_FILE} ${OPATCH_OPT} ${oui_invptrloc_option}
        opatch_rc=$?
        [ $opatch_rc -ne 0 ] && MSGINFOS "OPatch finished with return code '${opatch_rc}'."
      	echo_std
      fi
    fi
  fi

  # #############################################################################
  # Post-Installation Task #5: Check file permissions of Oracle home
  # #############################################################################
  if PostInstTasksRun; then
    MSGINFOS "Checking file permissions of Oracle base and Oracle home..."
    oh_usr=""
    oh_grp=""
    ob_usr=""
    ob_grp=""
    if [ -d "$tgt_ob_loc" ]; then
      if ob_usr=`ls -ld ${tgt_ob_loc} | awk '{print $3}'`; then : ; else MSGWARNS "${tgt_ob_loc}: failed to check ownership owner" ; fi
      if ob_grp=`ls -ld ${tgt_ob_loc} | awk '{print $4}'`; then : ; else MSGWARNS "${tgt_ob_loc}: failed to check ownership group" ; fi
      MSGINFOS "${tgt_ob_loc} (ORACLE_BASE): owned by $ob_usr:$ob_grp"
    fi
    if [ -d "$tgt_oh_loc" ]; then
      if oh_usr=`ls -ld ${tgt_oh_loc} | awk '{print $3}'`; then : ; else MSGWARNS "${tgt_oh_loc}: failed to check ownership owner" ; fi
      if oh_grp=`ls -ld ${tgt_oh_loc} | awk '{print $4}'`; then : ; else MSGWARNS "${tgt_oh_loc}: failed to check ownership group" ; fi
      MSGINFOS "${tgt_oh_loc} (ORACLE_HOME): owned by $oh_usr:$oh_grp"
    fi
  fi

  # #############################################################################
  # Post-Installation Task #6: Run root.sh?
  # #############################################################################
 #last_cmd_out=`ls -l ${tgt_oh_loc}/install/root_*.log > /dev/null 2>&1`
 #rc_os_cmd=$?
 #[ $rc_os_cmd -ne 0  ] && MSGWARNS "${tgt_oh_loc}/root.sh was not executed." && MSGINFOS "Next step: Run ${tgt_oh_loc}/root.sh as root."
  if PostInstTasksRun; then
    [ "${flag_ohroot}" = "${STR_NO}" ] && MSGINFOS "Next step: Run ${tgt_oh_loc}/root.sh as root."
  fi

  # #############################################################################
  # Post-Installation Task #7: install SBP (inform user to do this)
  # #############################################################################
  if PostInstTasksRun; then
    MSGINFOS "Next step: Install SAP Bundle Patch (SBP) into the new installed Oracle home."
  fi
  
  # #############################################################################
  # Post-installation tasks
  # #############################################################################
  if PostInstTasksRun; then
    # Display result of post installation tasks
    case $rct_ohs in
    	$RC_SUCC ) MSGINFOS "Post-installation steps finished successfully."          ;;
    	$RC_WARN ) MSGWARNS "Post-installation steps finished with warning(s)."       ;;
    	$RC_ERRR ) MSGERRRS "Post-installation steps finished with error(s)."         ;;
      *        ) MSGERRRS "Post-installation steps finished with undefined result." ;;
    esac
    echo_std "Post-installation tasks completed."
  else
    echo_std "Post-installation tasks have been skipped."
  fi

fi

###############################################################################
#                                                                             #
#                     END TASK: -ohsapcfg                                     #
#                                                                             #
###############################################################################
[ $opt_ohs = ${STR_YES} ] && MSGINFOV "rct_ohs=$rct_ohs"

###############################################################################
#                                                                             #
#                     BGN TASK: -ohmopatch                                    #
#                                                                             #
###############################################################################
dsc_cur="${dsc_ohm}"
#[ $opt_ohi = ${STR_NO}  ] && [ $opt_ohm = ${STR_NO} ] && install_exit $RC_SUCC # commented 2018-12-05 | 18-016
[ $opt_ohm = ${STR_YES} ] && MSGINFOS "TASK - $dsc_ohm" && run_ohm="${STR_YES}"
[ $opt_ohm = ${STR_YES} ] && MSGDATETIME "${dsc_cur}"
#[ $opt_ohm = ${STR_NO}  ] &&  MSGINFOS "TASK - $dsc_ohm - ${dsc_dnr}"          # commented 2018-12-05 | 18-016
[ $opt_ohm = ${STR_YES} ] && rct_ohm=$RC_SUCC

[ $opt_ohm = $STR_YES ] && [ "${query_mode}" = "${STR_ENABLED}"  ] && MSGINFOS "Query mode enabled - nothing to do"
[ $opt_ohm = $STR_YES ] && [ "${query_mode}" = "${STR_DISABLED}" ] && MSGINFOS "Remember to install the latest SAP Bundle Patch (SBP) with MOPatch before you use the new Oracle home."

###############################################################################
#                                                                             #
#                     END TASK: -ohmopatch                                    #
#                                                                             #
###############################################################################
[ $opt_ohm = ${STR_YES} ] && MSGINFOV "rct_ohm=$rct_ohm"

###############################################################################
#                                                                             #
#                     END TASK: -ohinstall                                    #
#                                                                             #
###############################################################################
#GET OVERALL RETURN CODE
MSGINFOV "Getting overall return code"
rct_ohi=$RC_SUCC
[ $rct_ohp -eq $RC_SUCC ] && [ $rct_ohv -eq $RC_SUCC ] && [ $rct_ohx -eq $RC_SUCC ] && [ $rct_ohc -eq $RC_SUCC ] && [ $rct_ohr -eq $RC_SUCC ] && [ $rct_ohs -eq $RC_SUCC ] && rct_ohi=$RC_SUCC # all tasks finished successfully
[ $rct_ohp -eq $RC_WARN ] || [ $rct_ohv -eq $RC_WARN ] || [ $rct_ohx -eq $RC_WARN ] || [ $rct_ohc -eq $RC_WARN ] || [ $rct_ohr -eq $RC_WARN ] || [ $rct_ohs -eq $RC_WARN ] && rct_ohi=$RC_WARN # one or more warnings occurred
[ $rct_ohp -eq $RC_ERRR ] || [ $rct_ohv -eq $RC_ERRR ] || [ $rct_ohx -eq $RC_ERRR ] || [ $rct_ohc -eq $RC_ERRR ] || [ $rct_ohr -eq $RC_ERRR ] || [ $rct_ohs -eq $RC_ERRR ] && rct_ohi=$RC_ERRR # one or more errors occurred
MSGINFOV "rct_ohi=$rct_ohi"

# ignore warnings (-ignoreWarnings option)
[ "${nowarn_mode}" = "${STR_ENABLED}" ] && [ $rct_ohi -eq $RC_WARN ] && rct_ohi=$RC_SUCC
MSGINFOV "rct_ohi=$rct_ohi"

###############################################################################
#                                                                             #
#                         SHOW LOG FILES                                      #
#                                                                             #
###############################################################################
# AB: moved into function install_exit

###############################################################################
#                                                                             #
#                                                                             #
#                                                                             #
#                         EXIT                                                #
#                                                                             #
#                                                                             #
#                                                                             #
###############################################################################
install_exit $rct_ohi
